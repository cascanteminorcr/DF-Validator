<?php

declare(strict_types=1);

/**
 * HTML shell for the single-page application.
 *
 * All dynamic data is fetched from /api/* with the Fetch API. The shell only
 * injects the CSRF token and the current user, both JSON-escaped for a
 * <script> context (JSON_HEX_TAG etc.) so no user data can break out.
 */

use App\Core\Auth;
use App\Core\Config;
use App\Core\Csrf;
use App\Core\Security;

require_once __DIR__ . '/../app/bootstrap.php';

$user = Auth::publicUser();
$csrf = Csrf::token();

$appName = (string) Config::get('app.name', 'Donation Form QA Validator');
$version = (string) Config::get('app.version', '1.0.0');

$bootstrap = [
    'user' => $user,
    'csrf' => $csrf,
    'meta' => [
        'appName' => $appName,
        'version' => $version,
    ],
];

$jsBase = '/assets/js';
?><!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <title><?= Security::e($appName) ?></title>
    <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><rect width='100' height='100' rx='22' fill='%236366f1'/><path d='M32 30h36v10H44v10h20v10H44v20H32z' fill='white'/></svg>">
    <link rel="stylesheet" href="/assets/css/theme.css?v=<?= Security::e($version) ?>">
</head>
<body>
    <a class="skip-link" href="#main-content">Skip to main content</a>

    <div id="app-loading" class="boot-loader" role="status" aria-live="polite">
        <div class="spinner spinner-lg" aria-hidden="true"></div>
        <p>Loading workspace…</p>
    </div>

    <div id="app" class="app-shell" hidden>
        <!-- Sidebar -->
        <aside id="sidebar" class="sidebar" aria-label="Primary navigation">
            <header class="sidebar-brand">
                <span class="brand-mark" aria-hidden="true">QA</span>
                <span class="brand-text">
                    <strong>Donation QA</strong>
                    <small>Form Validator</small>
                </span>
            </header>

            <nav class="sidebar-nav" id="sidebar-nav">
                <a href="#/dashboard" class="nav-link" data-nav="dashboard">
                    <span class="nav-icon" aria-hidden="true">▤</span>
                    <span>Dashboard</span>
                </a>
                <a href="#/executions" class="nav-link" data-nav="executions">
                    <span class="nav-icon" aria-hidden="true">☰</span>
                    <span>Executions</span>
                </a>
                <a href="#/executions/new" class="nav-link" data-nav="new">
                    <span class="nav-icon" aria-hidden="true">＋</span>
                    <span>New QA Run</span>
                </a>
                <a href="#/catalog" class="nav-link" data-nav="catalog">
                    <span class="nav-icon" aria-hidden="true">◫</span>
                    <span>Client Catalogue</span>
                </a>
                <a href="#/users" class="nav-link" data-nav="users" id="nav-users" hidden>
                    <span class="nav-icon" aria-hidden="true">◉</span>
                    <span>Users</span>
                </a>
            </nav>

            <footer class="sidebar-footer">
                <div class="sidebar-user" id="sidebar-user"></div>
                <button type="button" class="btn btn-ghost btn-block" id="logout-btn">Sign out</button>
            </footer>
        </aside>

        <!-- Main -->
        <div class="main-column">
            <header class="topbar">
                <button type="button" class="icon-btn" id="sidebar-toggle" aria-label="Toggle navigation" aria-expanded="true">☰</button>
                <div class="topbar-title" id="topbar-title">Dashboard</div>
                <div class="topbar-actions">
                    <span class="env-pill" id="topbar-env">QA Workspace</span>
                    <button type="button" class="btn btn-primary btn-sm" id="topbar-new">New QA Run</button>
                </div>
            </header>

            <main id="main-content" class="content" tabindex="-1"></main>
        </div>
    </div>

    <!-- Toasts -->
    <div id="toast-stack" class="toast-stack" aria-live="polite" aria-atomic="false"></div>

    <!-- Modal host -->
    <div id="modal-root"></div>

    <!-- Global overlay spinner for long actions -->
    <div id="overlay" class="overlay" hidden>
        <div class="overlay-card">
            <div class="spinner spinner-lg" aria-hidden="true"></div>
            <p id="overlay-text">Working…</p>
        </div>
    </div>

    <script>window.__QA_BOOTSTRAP__ = <?= Security::json($bootstrap) ?>;</script>
    <script src="<?= Security::e($jsBase) ?>/api.js?v=<?= Security::e($version) ?>"></script>
    <script src="<?= Security::e($jsBase) ?>/ui.js?v=<?= Security::e($version) ?>"></script>
    <script src="<?= Security::e($jsBase) ?>/views/auth.js?v=<?= Security::e($version) ?>"></script>
    <script src="<?= Security::e($jsBase) ?>/views/dashboard.js?v=<?= Security::e($version) ?>"></script>
    <script src="<?= Security::e($jsBase) ?>/views/executions.js?v=<?= Security::e($version) ?>"></script>
    <script src="<?= Security::e($jsBase) ?>/views/execution-detail.js?v=<?= Security::e($version) ?>"></script>
    <script src="<?= Security::e($jsBase) ?>/views/catalog.js?v=<?= Security::e($version) ?>"></script>
    <script src="<?= Security::e($jsBase) ?>/views/users.js?v=<?= Security::e($version) ?>"></script>
    <script src="<?= Security::e($jsBase) ?>/views/print.js?v=<?= Security::e($version) ?>"></script>
    <script src="<?= Security::e($jsBase) ?>/app.js?v=<?= Security::e($version) ?>"></script>
</body>
</html>
