/* =====================================================================
   views/print.js — print-friendly report view (uses browser print → PDF)
   ===================================================================== */
(function (global) {
    'use strict';

    const QA = global.QA;
    const html = QA.html;
    const ui = QA.ui;

    async function render(main, params) {
        const id = Number(params.id);

        main.innerHTML = html`<div class="card"><div class="card-body"><div class="skeleton" style="height:300px"></div></div></div>`;

        let data;
        try {
            data = await Promise.all([QA.api.execution(id), QA.api.meta()]);
        } catch (error) {
            main.innerHTML = html`<div class="card"><div class="empty"><h3>Report unavailable</h3><p>${error.message}</p></div></div>`;
            return;
        }

        const exec = data[0];
        const meta = data[1];
        const e = exec.execution;
        const evidence = exec.evidence || [];
        const auto = e.auto_results;

        const allItems = (exec.checklist.sections || []).reduce(function (acc, section) {
            return acc.concat(section.items.map(function (item) {
                return Object.assign({ section: section.label }, item);
            }));
        }, []);

        const failed = allItems.filter(function (item) { return item.status === 'fail'; });

        document.title = 'QA Report — ' + e.form_name;

        main.innerHTML = html`
            <div class="page-head no-print">
                <div class="titles">
                    <div class="eyebrow">Print preview</div>
                    <h1>${e.form_name}</h1>
                    <div class="subtitle">Use your browser's print dialog to save as PDF, or download the generated PDF.</div>
                </div>
                <div class="actions">
                    <button type="button" class="btn btn-primary" id="print-now">Print / Save as PDF</button>
                    <a class="btn" href="${QA.api.pdfUrl(e.id)}">Server PDF</a>
                    <a class="btn" href="${QA.api.csvUrl(e.id)}">CSV</a>
                    <a class="btn btn-ghost" href="#/executions/${e.id}">Back</a>
                </div>
            </div>

            <article class="card" style="padding:26px">
                <header style="border-bottom:2px solid #6366f1;padding-bottom:14px;margin-bottom:18px">
                    <div class="row between wrap">
                        <div>
                            <div class="eyebrow">Donation Form QA Validator</div>
                            <h1 style="font-size:1.45rem;margin-bottom:4px">QA Execution Report</h1>
                            <div class="soft">${e.client_name} · ${e.campaign_name}</div>
                        </div>
                        <div class="text-right">
                            <div><span class="badge ${e.approval_status === 'approved' ? 'badge-pass' : e.approval_status === 'rejected' ? 'badge-fail' : 'badge-warn'}">${ui.titleCase(e.approval_status)}</span></div>
                            <div class="muted mt-1" style="font-size:.78rem">Execution #${e.id} · ${ui.titleCase(e.environment)}</div>
                        </div>
                    </div>
                </header>

                <section class="mb-3">
                    <h2 style="font-size:.95rem;margin-bottom:10px">Execution Summary</h2>
                    <div class="grid grid-4" style="gap:10px">
                        <div class="stat-card is-pass" style="padding:11px 13px"><div class="stat-label">Passed</div><div class="stat-value" style="font-size:1.35rem">${e.pass_count}</div></div>
                        <div class="stat-card is-fail" style="padding:11px 13px"><div class="stat-label">Failed</div><div class="stat-value" style="font-size:1.35rem">${e.fail_count}</div></div>
                        <div class="stat-card" style="padding:11px 13px"><div class="stat-label">N/A</div><div class="stat-value" style="font-size:1.35rem">${e.na_count}</div></div>
                        <div class="stat-card is-warn" style="padding:11px 13px"><div class="stat-label">Open</div><div class="stat-value" style="font-size:1.35rem">${e.untested_count}</div></div>
                    </div>
                    <div class="mt-2">${ui.progressBar(e.pass_count, e.fail_count, e.na_count, e.total_items)}</div>
                    <p class="muted mt-2" style="font-size:.8rem">
                        Pass rate <strong>${ui.pct(e.pass_rate)}</strong> over ${e.pass_count + e.fail_count} decided items
                        (${e.total_items} total). N/A and open items are excluded from the score.
                    </p>
                </section>

                <section class="mb-3">
                    <h2 style="font-size:.95rem;margin-bottom:10px">General Information</h2>
                    <dl style="margin:0">
                        <div class="kv"><span class="k">Donation Form</span><span class="v">${e.form_name}</span></div>
                        <div class="kv"><span class="k">Form URL</span><span class="v mono">${e.form_url}</span></div>
                        <div class="kv"><span class="k">Template URL</span><span class="v mono">${e.template_url || 'not supplied'}</span></div>
                        <div class="kv"><span class="k">QA Analyst</span><span class="v">${e.qa_analyst_name}</span></div>
                        <div class="kv"><span class="k">Test Date</span><span class="v">${ui.fmtDate(e.test_date)}</span></div>
                        <div class="kv"><span class="k">Browser</span><span class="v">${e.browser_used || '—'}</span></div>
                        <div class="kv"><span class="k">Build Timestamp</span><span class="v">${e.build_timestamp ? ui.fmtDate(e.build_timestamp, true) : '—'}</span></div>
                        <div class="kv"><span class="k">Workflow Status</span><span class="v">${ui.titleCase(e.status)}</span></div>
                    </dl>
                </section>

                ${auto && auto.groups ? html`
                    <section class="mb-3">
                        <h2 style="font-size:.95rem;margin-bottom:10px">Automated Validation</h2>
                        <p class="muted" style="font-size:.8rem">
                            ${auto.summary.pass || 0} passed · ${auto.summary.fail || 0} failed ·
                            ${auto.summary.warn || 0} warnings — HTTP ${auto.http_status}, ${auto.elapsed_ms} ms
                        </p>
                        ${Object.keys(auto.groups).map(function (key) {
                            const group = auto.groups[key];
                            return html`
                                <h4 style="font-size:.83rem;margin:9px 0 5px;color:#9aa5bb">${group.label}</h4>
                                <table class="table" style="font-size:.78rem">
                                    <tbody>
                                        ${group.results.map(function (r) {
                                            return html`<tr>
                                                <td style="width:62px;padding:5px 8px">
                                                    <span class="badge ${r.status === 'pass' ? 'badge-pass' : r.status === 'fail' ? 'badge-fail' : r.status === 'warn' ? 'badge-warn' : 'badge-info'}">${r.status.toUpperCase()}</span>
                                                </td>
                                                <td style="padding:5px 8px">
                                                    <strong>${r.label}</strong>
                                                    <div class="muted">${r.detail}</div>
                                                </td>
                                            </tr>`;
                                        })}
                                    </tbody>
                                </table>
                            `;
                        })}
                    </section>
                ` : ''}

                ${(exec.checklist.sections || []).map(function (section) {
                    return html`
                        <section class="mb-3">
                            <h2 style="font-size:.95rem;margin-bottom:10px">${section.label}</h2>
                            <table class="table" style="font-size:.78rem">
                                <thead><tr><th style="width:34px">#</th><th>Checklist item</th><th style="width:74px">Result</th><th style="width:46%">Comment</th></tr></thead>
                                <tbody>
                                    ${section.items.map(function (item, index) {
                                        return html`<tr>
                                            <td class="muted" style="padding:5px 8px">${index + 1}</td>
                                            <td style="padding:5px 8px">${item.label}</td>
                                            <td style="padding:5px 8px">${ui.statusBadge(item.status)}</td>
                                            <td class="muted" style="padding:5px 8px">${item.comment || '—'}</td>
                                        </tr>`;
                                    })}
                                </tbody>
                            </table>
                        </section>
                    `;
                })}

                ${failed.length ? html`
                    <section class="mb-3">
                        <h2 style="font-size:.95rem;margin-bottom:10px">Failed Items</h2>
                        ${failed.map(function (item) {
                            return html`<div style="border-left:3px solid #f43f5e;padding:6px 0 6px 11px;margin-bottom:9px">
                                <strong style="font-size:.83rem">${item.label}</strong>
                                <div class="muted" style="font-size:.77rem">${item.section}</div>
                                <div style="font-size:.8rem;margin-top:3px">${item.comment || 'no comment recorded'}</div>
                            </div>`;
                        })}
                    </section>
                ` : ''}

                <section class="mb-3">
                    <h2 style="font-size:.95rem;margin-bottom:10px">Evidence References (${evidence.length})</h2>
                    ${evidence.length ? html`
                        <ul style="margin:0;padding-left:17px;font-size:.78rem">
                            ${evidence.map(function (file) {
                                return html`<li style="margin-bottom:3px">
                                    <span class="mono">${String(file.extension).toUpperCase()}</span> —
                                    ${file.original_name} <span class="muted">(${file.file_size_human}, ${ui.titleCase(file.category)}${file.result_label ? ' · ' + file.result_label : ''})</span>
                                </li>`;
                            })}
                        </ul>
                    ` : html`<p class="muted" style="font-size:.8rem">No evidence files attached.</p>`}
                </section>

                <section>
                    <h2 style="font-size:.95rem;margin-bottom:10px">QA Approval</h2>
                    <dl style="margin:0">
                        <div class="kv"><span class="k">Account Manager</span><span class="v">${e.am_name || 'not recorded'}</span></div>
                        <div class="kv"><span class="k">Approval Status</span><span class="v">${ui.titleCase(e.approval_status)}</span></div>
                        <div class="kv"><span class="k">Approval Message</span><span class="v">${e.approval_message || '—'}</span></div>
                        <div class="kv"><span class="k">QA Notes</span><span class="v">${e.qa_notes || '—'}</span></div>
                    </dl>
                    <div class="row between mt-3" style="gap:24px;padding-top:18px">
                        <div style="flex:1;border-top:1px solid #313b4f;padding-top:6px" class="muted">QA Analyst: ${e.qa_analyst_name}</div>
                        <div style="flex:1;border-top:1px solid #313b4f;padding-top:6px" class="muted">Approved by: ${e.am_name || 'pending'}</div>
                    </div>
                </section>

                <footer class="mt-3 muted" style="border-top:1px solid #252d3d;padding-top:10px;font-size:.72rem">
                    Generated by Donation Form QA Validator · ${new Date().toLocaleString('en-GB')} · CONFIDENTIAL — Internal QA
                </footer>
            </article>
        `;

        const printBtn = main.querySelector('#print-now');
        if (printBtn) printBtn.addEventListener('click', function () { window.print(); });
    }

    QA.views = QA.views || {};
    QA.views.print = { render: render };
})(window);
