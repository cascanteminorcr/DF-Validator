/* =====================================================================
   views/dashboard.js — statistics, common issues, recent executions
   ===================================================================== */
(function (global) {
    'use strict';

    const QA = global.QA;
    const html = QA.html;
    const ui = QA.ui;

    async function render(main) {
        main.innerHTML = html`
            <div class="page-head">
                <div class="titles">
                    <div class="eyebrow">Overview</div>
                    <h1>QA Dashboard</h1>
                    <div class="subtitle">Validation health across every donation form execution.</div>
                </div>
                <div class="actions">
                    <button type="button" class="btn" data-refresh>Refresh</button>
                    <a class="btn btn-primary" href="#/executions/new">+ New QA Run</a>
                </div>
            </div>
            <div id="dashboard-body">
                <div class="stat-grid">
                    ${[1, 2, 3, 4].map(function () {
                        return html`<div class="stat-card"><div class="skeleton" style="height:52px"></div></div>`;
                    })}
                </div>
                <div class="card"><div class="card-body"><div class="skeleton" style="height:180px"></div></div></div>
            </div>
        `;

        main.querySelector('[data-refresh]').addEventListener('click', function () { load(main); });
        await load(main);
    }

    async function load(main) {
        const body = main.querySelector('#dashboard-body');
        if (!body) return;

        let data;
        try {
            data = await QA.api.dashboard();
        } catch (error) {
            body.innerHTML = html`<div class="card"><div class="empty">
                <div class="empty-icon">⚠</div>
                <h3>Could not load dashboard</h3>
                <p>${error.message}</p>
            </div></div>`;
            return;
        }

        const s = data.stats || {};

        body.innerHTML = html`
            <section class="stat-grid" aria-label="Key metrics">
                <article class="stat-card is-accent">
                    <div class="stat-label">Total Forms Tested</div>
                    <div class="stat-value">${s.totalTests || 0}</div>
                    <div class="stat-sub">${s.inProgress || 0} in progress · ${s.approved || 0} approved</div>
                </article>
                <article class="stat-card is-pass">
                    <div class="stat-label">Pass Rate</div>
                    <div class="stat-value">${ui.pct(s.passRate)}</div>
                    <div class="stat-sub">${s.itemsPassed || 0} checklist items passed</div>
                </article>
                <article class="stat-card is-fail">
                    <div class="stat-label">Fail Rate</div>
                    <div class="stat-value">${ui.pct(s.failRate)}</div>
                    <div class="stat-sub">${s.itemsFailed || 0} items failed · ${s.withFailures || 0} runs affected</div>
                </article>
                <article class="stat-card is-warn">
                    <div class="stat-label">Pending Reviews</div>
                    <div class="stat-value">${s.pendingReviews || 0}</div>
                    <div class="stat-sub">${s.submitted || 0} awaiting QA approval</div>
                </article>
            </section>

            <div class="grid grid-2 mb-3">
                <section class="card">
                    <header class="card-header">
                        <h2>Most Common Issues</h2>
                        <span class="badge badge-mute">Last 90 days</span>
                        <div class="spacer"></div>
                        <a class="btn btn-ghost btn-sm" href="#/executions?status=rejected">View failures</a>
                    </header>
                    <div class="card-body">
                        ${renderIssues(s.commonIssues || [])}
                    </div>
                </section>

                <section class="card">
                    <header class="card-header">
                        <h2>Execution Trend</h2>
                        <span class="badge badge-mute">8 weeks</span>
                    </header>
                    <div class="card-body">
                        ${renderTrend(s.trend || [])}
                        <div class="row wrap mt-3" style="gap:16px">
                            ${(s.byEnvironment || []).map(function (env) {
                                return html`<div>
                                    <div class="muted" style="font-size:.7rem;text-transform:uppercase;letter-spacing:.06em">${ui.titleCase(env.environment)}</div>
                                    <div style="font-weight:650">${env.n} runs</div>
                                    <div class="muted" style="font-size:.75rem">${ui.pct(env.avg_pass_rate)} avg pass</div>
                                </div>`;
                            })}
                        </div>
                    </div>
                </section>
            </div>

            <section class="card">
                <header class="card-header">
                    <h2>Recent Executions</h2>
                    <div class="spacer"></div>
                    <a class="btn btn-ghost btn-sm" href="#/executions">All executions →</a>
                </header>
                <div class="card-body tight">
                    ${renderRecent(s.recent || [])}
                </div>
            </section>
        `;
    }

    function renderIssues(issues) {
        if (!issues.length) {
            return html`<div class="empty" style="padding:26px">
                <div class="empty-icon">✓</div>
                <h3>No failed items recorded</h3>
                <p>Every checklist item in the last 90 days passed or was marked N/A.</p>
            </div>`;
        }

        return html`<div>
            ${issues.map(function (issue, index) {
                return html`<div class="issue-row">
                    <span class="issue-rank">${index + 1}</span>
                    <div class="issue-body">
                        <div class="issue-label" title="${issue.item_label}">${issue.item_label}</div>
                        <div class="issue-sub">${ui.titleCase(issue.section)} section</div>
                    </div>
                    <span class="issue-count">${issue.occurrences}×</span>
                </div>`;
            })}
        </div>`;
    }

    function renderTrend(trend) {
        if (!trend.length) {
            return html`<div class="empty" style="padding:20px">
                <p class="mb-0">Not enough history yet — the trend appears after your first executions.</p>
            </div>`;
        }

        const max = Math.max.apply(null, trend.map(function (t) { return Number(t.executions) || 0; }).concat([1]));

        return html`<div class="bar-chart" role="img" aria-label="Executions per week">
            ${trend.map(function (t) {
                const height = Math.max(6, Math.round((Number(t.executions) / max) * 62));
                return html`<div class="bar-wrap" title="${t.executions} executions · ${ui.pct(t.avg_pass_rate)} avg pass">
                    <div class="bar" style="height:${height}px"></div>
                    <div class="bar-label">${t.executions}</div>
                </div>`;
            })}
        </div>`;
    }

    function renderRecent(rows) {
        if (!rows.length) {
            return html`<div class="empty">
                <div class="empty-icon">▤</div>
                <h3>No executions yet</h3>
                <p>Start your first QA run to populate the dashboard.</p>
                <a class="btn btn-primary btn-sm" href="#/executions/new">Create a QA run</a>
            </div>`;
        }

        return html`<div class="table-wrap">
            <table class="table">
                <thead>
                    <tr>
                        <th>Form</th>
                        <th>Environment</th>
                        <th>Status</th>
                        <th>Score</th>
                        <th>Analyst</th>
                        <th>Updated</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    ${rows.map(function (row) {
                        return html`<tr>
                            <td>
                                <div class="cell-main">${row.form_name}</div>
                                <div class="cell-sub">${row.client_name} · ${row.campaign_name}</div>
                            </td>
                            <td>${ui.envBadge(row.environment)}</td>
                            <td>${ui.execBadge(row.status)}</td>
                            <td>
                                <div class="row" style="gap:8px">
                                    <div class="mini-bar ${ui.rateClass(Number(row.pass_rate))}">
                                        <span style="width:${Number(row.pass_rate) || 0}%"></span>
                                    </div>
                                    <span class="mono" style="font-size:.78rem">${ui.pct(row.pass_rate)}</span>
                                </div>
                            </td>
                            <td class="muted">${row.qa_analyst_name || '—'}</td>
                            <td class="muted nowrap">${ui.relTime(row.updated_at)}</td>
                            <td class="actions-cell">
                                <a class="btn btn-xs" href="#/executions/${row.id}">Open</a>
                            </td>
                        </tr>`;
                    })}
                </tbody>
            </table>
        </div>`;
    }

    QA.views = QA.views || {};
    QA.views.dashboard = { render: render };
})(window);
