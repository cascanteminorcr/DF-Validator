/* =====================================================================
   views/execution-detail.js — the QA workspace
   Tabs: Checklist · Automated checks · Evidence · Approval & Report
   ===================================================================== */
(function (global) {
    'use strict';

    const QA = global.QA;
    const html = QA.html;
    const ui = QA.ui;

    let ctx = null;     // { id, execution, checklist, evidence, reports, can_edit, can_approve, meta }
    let autoSaveTimer = null;
    let pendingDraft = {};
    let activeTab = 'checklist';

    /* =================================================================
       Entry
       ================================================================= */

    async function render(main, params) {
        const id = Number(params.id);
        activeTab = (params.tab || 'checklist').replace(/[^a-z]/g, '') || 'checklist';

        main.innerHTML = html`
            <div class="page-head">
                <div class="titles">
                    <div class="eyebrow">Execution #${id}</div>
                    <h1><span class="skeleton" style="display:inline-block;width:280px;height:26px"></span></h1>
                </div>
            </div>
            <div class="card"><div class="card-body"><div class="skeleton" style="height:320px"></div></div></div>
        `;

        try {
            await load(id);
        } catch (error) {
            main.innerHTML = html`<div class="card"><div class="empty">
                <div class="empty-icon">⚠</div>
                <h3>Could not open this execution</h3>
                <p>${error.message}</p>
                <a class="btn btn-sm" href="#/executions">Back to executions</a>
            </div></div>`;
            return;
        }

        paint(main);
    }

    async function load(id) {
        const [data, meta] = await Promise.all([QA.api.execution(id), QA.api.meta()]);
        ctx = Object.assign({ id: id, meta: meta }, data);
        ctx.local = {};
        (ctx.checklist.sections || []).forEach(function (section) {
            section.items.forEach(function (item) {
                ctx.local[item.key] = { status: item.status, comment: item.comment || '' };
            });
        });
        return ctx;
    }

    /* =================================================================
       Paint
       ================================================================= */

    function paint(main) {
        const e = ctx.execution;
        const locked = !ctx.can_edit || e.status === 'approved' && !ctx.can_approve;

        main.innerHTML = html`
            <div class="page-head">
                <div class="titles">
                    <div class="eyebrow">Execution #${e.id} · ${ui.titleCase(e.environment)}</div>
                    <h1>${e.form_name}</h1>
                    <div class="subtitle">
                        ${e.client_name} · ${e.campaign_name}
                        <span class="muted"> — </span>
                        <a href="${e.form_url}" target="_blank" rel="noopener noreferrer">${shortUrl(e.form_url)}</a>
                    </div>
                </div>
                <div class="actions">
                    <span id="autosave-slot"></span>
                    ${ui.execBadge(e.status)}
                    <button type="button" class="btn btn-sm" data-action="edit-info">Edit info</button>
                    <button type="button" class="btn btn-sm" data-action="duplicate">Duplicate</button>
                    <button type="button" class="btn btn-primary btn-sm" data-action="report">Generate report</button>
                </div>
            </div>

            <div class="detail-layout">
                <div>
                    <div class="tabs" role="tablist">
                        ${tabButton('checklist', 'Checklist', (ctx.checklist.sections || []).reduce(function (n, s) { return n + s.items.length; }, 0))}
                        ${tabButton('automation', 'Automated checks', ctx.execution.auto_results ? countAuto(ctx.execution.auto_results) : null)}
                        ${tabButton('evidence', 'Evidence', ctx.evidence.length)}
                        ${tabButton('approval', 'Approval & Report', null)}
                    </div>
                    <div id="tab-body"></div>
                </div>

                <aside class="summary-panel" aria-label="Execution summary">
                    <section class="card">
                        <header class="card-header"><h3>Progress</h3></header>
                        <div class="card-body" id="summary-body">
                            ${summaryBody()}
                        </div>
                    </section>

                    <section class="card">
                        <header class="card-header"><h3>Execution facts</h3></header>
                        <div class="card-body">
                            <div class="kv"><span class="k">Analyst</span><span class="v">${e.qa_analyst_name}</span></div>
                            <div class="kv"><span class="k">Test date</span><span class="v">${ui.fmtDate(e.test_date)}</span></div>
                            <div class="kv"><span class="k">Browser</span><span class="v">${e.browser_used || '—'}</span></div>
                            <div class="kv"><span class="k">Build</span><span class="v">${e.build_timestamp ? ui.fmtDate(e.build_timestamp, true) : '—'}</span></div>
                            <div class="kv"><span class="k">Created</span><span class="v">${ui.fmtDate(e.created_at, true)}</span></div>
                            <div class="kv"><span class="k">Approval</span><span class="v">${ui.titleCase(e.approval_status)}</span></div>
                        </div>
                    </section>

                    <section class="card">
                        <header class="card-header"><h3>Actions</h3></header>
                        <div class="card-body" style="display:flex;flex-direction:column;gap:8px">
                            <button type="button" class="btn btn-block btn-sm" data-action="run-auto">
                                Run automated checks
                            </button>
                            <button type="button" class="btn btn-block btn-sm" data-action="submit" ${locked || e.status === 'submitted' ? ui.raw('disabled') : ''}>
                                Submit for review
                            </button>
                            <a class="btn btn-block btn-sm" href="${QA.api.csvUrl(e.id)}">Export CSV</a>
                            <a class="btn btn-block btn-sm" href="${QA.api.pdfUrl(e.id)}" target="_blank" rel="noopener">Download PDF</a>
                            <a class="btn btn-block btn-sm" href="#/executions/${e.id}/print">Print report</a>
                            <button type="button" class="btn btn-block btn-sm btn-danger" data-action="delete">Delete execution</button>
                        </div>
                    </section>
                </aside>
            </div>
        `;

        main.querySelectorAll('.tab').forEach(function (btn) {
            btn.addEventListener('click', function () {
                activeTab = btn.dataset.tab;
                paintTabs(main);
            });
        });

        main.querySelectorAll('[data-action]').forEach(function (btn) {
            btn.addEventListener('click', function () { handleAction(btn.dataset.action, main); });
        });

        if (locked) {
            ui.toast('This execution is read-only for your role or because it is approved.', 'info', 'Read-only');
        }

        paintTabs(main);
        renderAutosaveSlot();
    }

    function tabButton(key, label, count) {
        return html`<button type="button" class="tab ${activeTab === key ? 'is-active' : ''}" data-tab="${key}" role="tab"
            aria-selected="${activeTab === key ? 'true' : 'false'}">
            ${label}${count !== null && count !== undefined ? html`<span class="count">${count}</span>` : ''}
        </button>`;
    }

    function countAuto(auto) {
        if (!auto || !auto.groups) return null;
        let n = 0;
        Object.keys(auto.groups).forEach(function (g) { n += (auto.groups[g].results || []).length; });
        return n;
    }

    function paintTabs(main) {
        const body = main.querySelector('#tab-body');
        if (!body) return;

        main.querySelectorAll('.tab').forEach(function (btn) {
            const on = btn.dataset.tab === activeTab;
            btn.classList.toggle('is-active', on);
            btn.setAttribute('aria-selected', on ? 'true' : 'false');
        });

        if (activeTab === 'automation') return paintAutomation(body);
        if (activeTab === 'evidence') return paintEvidence(body);
        if (activeTab === 'approval') return paintApproval(body);
        return paintChecklist(body);
    }

    /* =================================================================
       Summary panel
       ================================================================= */

    function summaryBody() {
        const e = ctx.execution;
        const total = e.total_items || 1;
        const decided = e.pass_count + e.fail_count + e.na_count;
        const coverage = Math.round((decided / total) * 100);

        return html`
            <div class="metric-row">
                <div class="metric-pill pass"><span class="n">${e.pass_count}</span><span class="l">Pass</span></div>
                <div class="metric-pill fail"><span class="n">${e.fail_count}</span><span class="l">Fail</span></div>
                <div class="metric-pill na"><span class="n">${e.na_count}</span><span class="l">N/A</span></div>
                <div class="metric-pill open"><span class="n">${e.untested_count}</span><span class="l">Open</span></div>
            </div>
            <div class="mb-2">${ui.progressBar(e.pass_count, e.fail_count, e.na_count, total)}</div>
            <div class="kv"><span class="k">Pass rate</span><span class="v"><strong>${ui.pct(e.pass_rate)}</strong></span></div>
            <div class="kv"><span class="k">Coverage</span><span class="v">${coverage}% of ${total}</span></div>
            <div class="kv"><span class="k">Evidence files</span><span class="v">${ctx.evidence.length}</span></div>
        `;
    }

    function refreshSummary() {
        const slot = document.querySelector('#summary-body');
        if (slot) slot.innerHTML = summaryBody();
    }

    /* =================================================================
       Tab 1 — checklist
       ================================================================= */

    function paintChecklist(body) {
        const sections = ctx.checklist.sections || [];
        const e = ctx.execution;
        const readOnly = !ctx.can_edit || (e.status === 'approved' && !ctx.can_approve);

        body.innerHTML = html`
            ${readOnly ? html`<div class="card mb-2"><div class="card-body" style="padding:12px 15px">
                <span class="badge badge-warn">Read-only</span>
                <span class="soft" style="margin-left:8px;font-size:.82rem">
                    ${e.status === 'approved' ? 'This execution is approved and locked.' : 'You do not own this execution.'}
                </span>
            </div></div>` : ''}

            ${sections.map(function (section) {
                const counts = section.items.reduce(function (acc, item) {
                    acc[ctx.local[item.key].status] = (acc[ctx.local[item.key].status] || 0) + 1;
                    return acc;
                }, {});

                return html`
                    <section class="checklist-section" data-section="${section.key}">
                        <header class="section-head">
                            <h3>${section.label}</h3>
                            <span class="section-meta">${section.items.length} items</span>
                            <div class="spacer"></div>
                            <span class="badge badge-pass">${counts.pass || 0} pass</span>
                            <span class="badge badge-fail">${counts.fail || 0} fail</span>
                            <span class="badge badge-na">${counts.na || 0} n/a</span>
                            <span class="badge badge-mute">${counts.untested || 0} open</span>
                        </header>
                        <div class="section-body">
                            ${section.items.map(function (item, index) { return checkRow(item, index, readOnly); })}
                        </div>
                    </section>
                `;
            })}
        `;

        bindChecklist(body, readOnly);
    }

    function checkRow(item, index, readOnly) {
        const local = ctx.local[item.key];
        const status = local.status;
        const files = ctx.evidence.filter(function (f) { return f.result_id === item.id; });

        return html`
            <article class="check-item ${status === 'fail' ? 'is-fail' : status === 'pass' ? 'is-pass' : ''}"
                     data-item="${item.key}" id="item-${item.key}">
                <div class="check-index">${String(index + 1).padStart(2, '0')}</div>

                <div class="check-main">
                    <div class="check-label">${item.label}</div>
                    <div class="check-hint">${item.hint}</div>
                </div>

                <div class="check-controls">
                    <div class="status-select" role="group" aria-label="Result for ${item.label}">
                        <button type="button" data-status="pass" class="${status === 'pass' ? 'is-active' : ''}"
                            aria-pressed="${status === 'pass' ? 'true' : 'false'}" ${readOnly ? ui.raw('disabled') : ''}>Pass</button>
                        <button type="button" data-status="fail" class="${status === 'fail' ? 'is-active' : ''}"
                            aria-pressed="${status === 'fail' ? 'true' : 'false'}" ${readOnly ? ui.raw('disabled') : ''}>Fail</button>
                        <button type="button" data-status="na" class="${status === 'na' ? 'is-active' : ''}"
                            aria-pressed="${status === 'na' ? 'true' : 'false'}" ${readOnly ? ui.raw('disabled') : ''}>N/A</button>
                    </div>
                    <button type="button" class="btn btn-xs btn-icon" data-toggle-detail
                        aria-expanded="false" title="Comment &amp; evidence">⋯</button>
                </div>

                <div class="check-detail" hidden>
                    <label class="sr-only" for="comment-${item.key}">Comment for ${item.label}</label>
                    <textarea class="check-comment" id="comment-${item.key}" data-comment
                        placeholder="${status === 'fail' ? 'Describe the defect (required for a Fail)…' : 'Optional notes for this item…'}"
                        ${readOnly ? ui.raw('disabled') : ''}>${local.comment}</textarea>

                    <div class="check-evidence-row">
                        <div class="evidence-chips" data-chips>
                            ${files.map(function (file) { return evidenceChip(file); })}
                        </div>
                        ${readOnly ? '' : html`
                            <button type="button" class="btn btn-xs" data-upload>
                                + Attach screenshot
                            </button>
                            <input type="file" hidden multiple accept=".png,.jpg,.jpeg,.pdf,.eml,.msg" data-file-input>
                        `}
                        ${item.evidence_count > 0 && files.length === 0
                            ? html`<span class="muted" style="font-size:.74rem">${item.evidence_count} file(s) attached</span>`
                            : ''}
                    </div>
                </div>
            </article>
        `;
    }

    function evidenceChip(file) {
        const thumb = file.is_image
            ? html`<img class="thumb" src="${file.preview_url}" alt="" loading="lazy">`
            : html`<span class="thumb" style="display:grid;place-items:center;font-size:.55rem;font-weight:700">${String(file.extension).toUpperCase()}</span>`;

        return html`<a class="evidence-chip" href="${file.download_url}" title="${file.original_name}">
            ${thumb}
            <span class="chip-name">${file.original_name}</span>
            <button type="button" class="chip-x" data-remove-file="${file.id}" aria-label="Remove ${file.original_name}">×</button>
        </a>`;
    }

    function bindChecklist(body, readOnly) {
        body.querySelectorAll('.check-item').forEach(function (row) {
            const key = row.dataset.item;
            const detail = row.querySelector('.check-detail');
            const toggle = row.querySelector('[data-toggle-detail]');
            const comment = row.querySelector('[data-comment]');

            toggle.addEventListener('click', function () {
                const open = detail.hidden;
                detail.hidden = !open;
                toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
                toggle.textContent = open ? '×' : '⋯';
            });

            if (readOnly) return;

            row.querySelectorAll('.status-select button').forEach(function (btn) {
                btn.addEventListener('click', async function () {
                    const status = btn.dataset.status;
                    const previous = ctx.local[key].status;

                    // A Fail requires a comment: open the detail panel first.
                    if (status === 'fail' && !comment.value.trim()) {
                        detail.hidden = false;
                        toggle.setAttribute('aria-expanded', 'true');
                        toggle.textContent = '×';
                        ctx.local[key].status = 'fail';
                        applyRowState(row, 'fail');
                        comment.focus();
                        ui.toast('Add a comment describing the defect before leaving this item.', 'warn');
                        return;
                    }

                    ctx.local[key].status = status;
                    applyRowState(row, status);

                    if (previous === status) return;

                    try {
                        const result = await QA.api.saveResult(ctx.id, key, status, comment.value);
                        applyMetrics(result.metrics);
                        if (result.evidence) syncRowChips(row, result.evidence);
                        flashSaved();
                    } catch (error) {
                        ctx.local[key].status = previous;
                        applyRowState(row, previous);
                        ui.toast(error.message, 'error');
                    }
                });
            });

            const queueComment = ui.debounce(async function () {
                const value = comment.value.trim();
                const status = ctx.local[key].status;

                if (status === 'untested' && !value) return;

                pendingDraft[key] = { status: status === 'untested' ? 'untested' : status, comment: value };

                if (status === 'fail' && !value) {
                    setAutosave('dirty', 'Comment required');
                    return;
                }

                setAutosave('saving', 'Saving…');

                try {
                    await QA.api.autosave(ctx.id, pendingDraft);
                    pendingDraft = {};
                    setAutosave('saved', 'Saved');
                    flashSaved();
                } catch (error) {
                    setAutosave('dirty', 'Not saved');
                }
            }, 900);

            comment.addEventListener('input', queueComment);
            comment.addEventListener('blur', async function () {
                const value = comment.value.trim();
                const status = ctx.local[key].status;

                if (status === 'untested' && !value) return;

                if (status === 'fail' && !value) {
                    ui.toast('A failed item needs a comment.', 'error');
                    comment.setAttribute('aria-invalid', 'true');
                    return;
                }

                comment.removeAttribute('aria-invalid');

                try {
                    const result = await QA.api.saveResult(ctx.id, key, status, value);
                    applyMetrics(result.metrics);
                    flashSaved();
                } catch (error) {
                    ui.toast(error.message, 'error');
                }
            });

            const uploadBtn = row.querySelector('[data-upload]');
            const fileInput = row.querySelector('[data-file-input]');

            if (uploadBtn && fileInput) {
                uploadBtn.addEventListener('click', function () { fileInput.click(); });
                fileInput.addEventListener('change', function () {
                    if (fileInput.files && fileInput.files.length) {
                        uploadFiles(ctx.id, fileInput.files, key, row);
                    }
                    fileInput.value = '';
                });
            }

            row.querySelectorAll('[data-remove-file]').forEach(function (btn) {
                btn.addEventListener('click', async function (event) {
                    event.preventDefault();
                    event.stopPropagation();

                    if (!await ui.confirm({ title: 'Remove file', message: 'Delete this evidence file permanently?', confirmLabel: 'Delete', danger: true })) return;

                    try {
                        await QA.api.deleteEvidence(btn.dataset.removeFile);
                        btn.closest('.evidence-chip').remove();
                        ctx.evidence = ctx.evidence.filter(function (f) { return String(f.id) !== String(btn.dataset.removeFile); });
                        refreshSummary();
                        ui.toast('Evidence removed.', 'success');
                    } catch (error) {
                        ui.toast(error.message, 'error');
                    }
                });
            });
        });
    }

    function applyRowState(row, status) {
        row.classList.toggle('is-fail', status === 'fail');
        row.classList.toggle('is-pass', status === 'pass');

        row.querySelectorAll('.status-select button').forEach(function (btn) {
            const on = btn.dataset.status === status;
            btn.classList.toggle('is-active', on);
            btn.setAttribute('aria-pressed', on ? 'true' : 'false');
        });

        const comment = row.querySelector('[data-comment]');
        if (comment) {
            comment.placeholder = status === 'fail'
                ? 'Describe the defect (required for a Fail)…'
                : 'Optional notes for this item…';
            if (status === 'fail') comment.setAttribute('aria-invalid', 'false');
        }
    }

    function syncRowChips(row, files) {
        const chips = row.querySelector('[data-chips]');
        if (!chips) return;
        chips.innerHTML = files.map(evidenceChip).join('');
    }

    function applyMetrics(metrics) {
        if (!metrics) return;

        ctx.execution.pass_count = metrics.pass;
        ctx.execution.fail_count = metrics.fail;
        ctx.execution.na_count = metrics.na;
        ctx.execution.untested_count = metrics.untested;
        ctx.execution.total_items = metrics.total;
        ctx.execution.pass_rate = metrics.pass_rate;

        refreshSummary();

        const statusSlot = document.querySelector('.page-head .actions .badge');
        if (statusSlot && ctx.execution.status === 'draft' && (metrics.pass + metrics.fail + metrics.na) > 0) {
            ctx.execution.status = 'in_progress';
            statusSlot.outerHTML = ui.execBadge('in_progress');
        }
    }

    /* =================================================================
       Autosave indicator
       ================================================================= */

    function renderAutosaveSlot() {
        const slot = document.querySelector('#autosave-slot');
        if (!slot) return;
        slot.innerHTML = html`<span class="autosave-indicator" id="autosave-indicator" title="Drafts save automatically">
            <span class="dot"></span><span id="autosave-text">Autosave on</span>
        </span>`;
    }

    function setAutosave(state, label) {
        const indicator = document.getElementById('autosave-indicator');
        const text = document.getElementById('autosave-text');
        if (!indicator || !text) return;

        indicator.classList.toggle('is-saving', state === 'saving');
        indicator.classList.toggle('is-dirty', state === 'dirty');
        text.textContent = label;

        if (state === 'saved') {
            clearTimeout(autoSaveTimer);
            autoSaveTimer = setTimeout(function () {
                text.textContent = 'All changes saved';
                indicator.classList.remove('is-saving', 'is-dirty');
            }, 1600);
        }
    }

    function flashSaved() {
        setAutosave('saved', 'Saved');
    }

    /* =================================================================
       Tab 2 — automated checks
       ================================================================= */

    function paintAutomation(body) {
        const auto = ctx.execution.auto_results;

        if (!auto || !auto.groups) {
            body.innerHTML = html`
                <div class="card"><div class="empty">
                    <div class="empty-icon">⚙</div>
                    <h3>No automated validation yet</h3>
                    <p>Run the automated pass to check HTTP status, HTTPS, mixed content, Open Graph tags,
                       analytics, accessibility and broken links against <span class="mono">${ctx.execution.form_url}</span>.</p>
                    <button type="button" class="btn btn-primary btn-sm" data-run-now>Run automated checks</button>
                </div></div>
            `;
            const btn = body.querySelector('[data-run-now]');
            if (btn) btn.addEventListener('click', function () { runAutomation(document); });
            return;
        }

        const summary = auto.summary || {};

        body.innerHTML = html`
            <div class="card mb-3">
                <header class="card-header">
                    <h2>Automated validation snapshot</h2>
                    <div class="spacer"></div>
                    <button type="button" class="btn btn-sm" data-rerun>Re-run checks</button>
                </header>
                <div class="card-body">
                    <div class="grid grid-4 mb-2" style="gap:10px">
                        <div class="stat-card is-pass" style="padding:12px 14px">
                            <div class="stat-label">Passed</div>
                            <div class="stat-value" style="font-size:1.4rem">${summary.pass || 0}</div>
                        </div>
                        <div class="stat-card is-fail" style="padding:12px 14px">
                            <div class="stat-label">Failed</div>
                            <div class="stat-value" style="font-size:1.4rem">${summary.fail || 0}</div>
                        </div>
                        <div class="stat-card is-warn" style="padding:12px 14px">
                            <div class="stat-label">Warnings</div>
                            <div class="stat-value" style="font-size:1.4rem">${summary.warn || 0}</div>
                        </div>
                        <div class="stat-card is-info" style="padding:12px 14px">
                            <div class="stat-label">Info</div>
                            <div class="stat-value" style="font-size:1.4rem">${summary.info || 0}</div>
                        </div>
                    </div>

                    <div class="kv"><span class="k">Checked URL</span><span class="v mono">${auto.final_url || auto.url}</span></div>
                    <div class="kv"><span class="k">HTTP status</span><span class="v">${auto.http_status || 'no response'}</span></div>
                    <div class="kv"><span class="k">Response time</span><span class="v">${auto.elapsed_ms} ms</span></div>
                    <div class="kv"><span class="k">Checked at</span><span class="v">${ui.fmtDate(auto.checked_at, true)}</span></div>
                    ${auto.error ? html`<div class="kv"><span class="k">Error</span><span class="v" style="color:#fda4af">${auto.error}</span></div>` : ''}
                </div>
            </div>

            ${Object.keys(auto.groups).map(function (key) {
                const group = auto.groups[key];
                const counts = (group.results || []).reduce(function (acc, r) {
                    acc[r.status] = (acc[r.status] || 0) + 1;
                    return acc;
                }, {});

                return html`
                    <section class="auto-group">
                        <header class="auto-group-head">
                            <h4>${group.label}</h4>
                            <div class="auto-counts">
                                ${counts.fail ? html`<span class="badge badge-fail">${counts.fail} fail</span>` : ''}
                                ${counts.warn ? html`<span class="badge badge-warn">${counts.warn} warn</span>` : ''}
                                ${counts.pass ? html`<span class="badge badge-pass">${counts.pass} pass</span>` : ''}
                                ${counts.info ? html`<span class="badge badge-info">${counts.info} info</span>` : ''}
                            </div>
                        </header>
                        ${group.results.map(function (result) {
                            return html`
                                <div class="auto-row">
                                    <div>${autoBadge(result.status)}</div>
                                    <div>
                                        <div style="font-weight:560">${result.label}</div>
                                        <div class="auto-detail">${result.detail}</div>
                                    </div>
                                </div>
                            `;
                        })}
                    </section>
                `;
            })}
        `;

        const rerun = body.querySelector('[data-rerun]');
        if (rerun) {
            rerun.addEventListener('click', function () { runAutomation(document); });
        }
    }

    function autoBadge(status) {
        const map = {
            pass: ['badge-pass', 'PASS'],
            fail: ['badge-fail', 'FAIL'],
            warn: ['badge-warn', 'WARN'],
            info: ['badge-info', 'INFO']
        };
        const entry = map[status] || ['badge-mute', String(status).toUpperCase()];
        return html`<span class="badge ${entry[0]}">${entry[1]}</span>`;
    }

    async function runAutomation(root) {
        ui.busy('Running automated checks…');
        try {
            const result = await QA.api.runAutomation(ctx.id, ctx.execution.form_url);
            ctx.execution.auto_results = result.automation;
            ui.toast('Automated validation completed.', 'success');
            const main = document.querySelector('#main-content');
            paintTabs(main);
            activeTab = 'automation';
            paintTabs(main);
        } catch (error) {
            ui.toast(error.message, 'error');
        } finally {
            ui.idle();
        }
    }

    /* =================================================================
       Tab 3 — evidence
       ================================================================= */

    function paintEvidence(body) {
        const canUpload = ctx.can_edit;

        body.innerHTML = html`
            <div class="card mb-3">
                <header class="card-header">
                    <h2>Evidence files</h2>
                    <span class="badge badge-mute">${ctx.evidence.length}</span>
                    <div class="spacer"></div>
                    <span class="muted" style="font-size:.76rem">PNG · JPG · PDF · EML · MSG — max 10 MB each</span>
                </header>
                <div class="card-body">
                    ${canUpload ? html`
                        <div class="dropzone" id="evidence-dropzone" tabindex="0" role="button"
                             aria-label="Upload evidence files">
                            <strong>Drop files here or click to browse</strong>
                            <small>Screenshots, PDFs and approval e-mails are stored against this execution.</small>
                            <input type="file" id="evidence-input" hidden multiple accept=".png,.jpg,.jpeg,.pdf,.eml,.msg">
                        </div>
                    ` : ''}

                    <div class="evidence-grid mt-3" id="evidence-grid">
                        ${ctx.evidence.length ? ctx.evidence.map(evidenceCard).join('') : html`
                            <div class="empty" style="grid-column:1/-1;padding:22px">
                                <div class="empty-icon">▧</div>
                                <h3>No evidence attached</h3>
                                <p>Attach screenshots from the checklist or upload files here.</p>
                            </div>
                        `}
                    </div>
                </div>
            </div>
        `;

        const dropzone = body.querySelector('#evidence-dropzone');
        const input = body.querySelector('#evidence-input');

        if (dropzone && input) {
            dropzone.addEventListener('click', function () { input.click(); });
            dropzone.addEventListener('keydown', function (event) {
                if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); input.click(); }
            });
            input.addEventListener('change', function () {
                if (input.files.length) uploadFiles(ctx.id, input.files, null, null);
                input.value = '';
            });

            ['dragenter', 'dragover'].forEach(function (type) {
                dropzone.addEventListener(type, function (event) {
                    event.preventDefault();
                    dropzone.classList.add('is-drag');
                });
            });
            ['dragleave', 'drop'].forEach(function (type) {
                dropzone.addEventListener(type, function (event) {
                    event.preventDefault();
                    dropzone.classList.remove('is-drag');
                });
            });
            dropzone.addEventListener('drop', function (event) {
                if (event.dataTransfer.files.length) uploadFiles(ctx.id, event.dataTransfer.files, null, null);
            });
        }

        body.querySelectorAll('[data-remove-file]').forEach(function (btn) {
            btn.addEventListener('click', async function (event) {
                event.preventDefault();
                if (!await ui.confirm({ title: 'Remove file', message: 'Delete this evidence file permanently?', confirmLabel: 'Delete', danger: true })) return;
                try {
                    await QA.api.deleteEvidence(btn.dataset.removeFile);
                    ctx.evidence = ctx.evidence.filter(function (f) { return String(f.id) !== String(btn.dataset.removeFile); });
                    paintTabs(document.querySelector('#main-content'));
                    refreshSummary();
                    ui.toast('Evidence removed.', 'success');
                } catch (error) {
                    ui.toast(error.message, 'error');
                }
            });
        });
    }

    function evidenceCard(file) {
        const preview = file.is_image
            ? html`<a href="${file.preview_url}" target="_blank" rel="noopener"><img src="${file.preview_url}" alt="${file.original_name}" loading="lazy"></a>`
            : html`<span class="ev-ext">${String(file.extension).toUpperCase()}</span>`;

        return html`
            <article class="evidence-card">
                <div class="ev-thumb">${preview}</div>
                <div class="ev-body">
                    <div class="ev-name" title="${file.original_name}">${file.original_name}</div>
                    <div class="ev-meta">${file.file_size_human} · ${ui.titleCase(file.category)}</div>
                    ${file.result_label ? html`<div class="ev-meta truncate" title="${file.result_label}">↳ ${file.result_label}</div>` : ''}
                </div>
                <div class="ev-actions">
                    <a class="btn btn-xs" href="${file.download_url}">Download</a>
                    <button type="button" class="btn btn-xs btn-danger" data-remove-file="${file.id}">Delete</button>
                </div>
            </article>
        `;
    }

    async function uploadFiles(executionId, fileList, itemKey, row) {
        const files = Array.prototype.slice.call(fileList);
        if (!files.length) return;

        let resultId = null;
        if (itemKey) {
            const keyItems = (ctx.checklist.sections || [])
                .reduce(function (all, s) { return all.concat(s.items); }, [])
                .filter(function (i) { return i.key === itemKey; });
            resultId = keyItems.length ? keyItems[0].id : null;
        }

        ui.busy('Uploading ' + files.length + ' file' + (files.length > 1 ? 's' : '') + '…');

        const formData = new FormData();
        files.forEach(function (file) { formData.append('files[]', file); });
        formData.append('category', itemKey ? 'screenshot' : 'attachment');
        if (resultId) formData.append('result_id', String(resultId));

        try {
            const data = await QA.api.uploadEvidence(executionId, formData);
            (data.files || []).forEach(function (file) {
                ctx.evidence.unshift(file);
            });

            if (row) {
                const chipHost = row.querySelector('[data-chips]');
                if (chipHost) chipHost.innerHTML = (data.files || []).map(evidenceChip).join('');
            }

            refreshSummary();
            ui.toast((data.files || []).length + ' file(s) uploaded.', 'success');

            if (activeTab === 'evidence') {
                paintTabs(document.querySelector('#main-content'));
            }

            if (data.errors && data.errors.length) {
                ui.toast(data.errors.join(' '), 'warn', 'Some files were rejected');
            }
        } catch (error) {
            ui.toast(error.message, 'error');
        } finally {
            ui.idle();
        }
    }

    /* =================================================================
       Tab 4 — approval & report
       ================================================================= */

    function paintApproval(body) {
        const e = ctx.execution;
        const canApprove = ctx.can_approve;
        const reports = ctx.reports || [];

        body.innerHTML = html`
            <div class="card mb-3">
                <header class="card-header">
                    <h2>QA Approval</h2>
                    ${e.approval_status === 'approved'
                        ? html`<span class="badge badge-pass">Approved</span>`
                        : e.approval_status === 'rejected'
                            ? html`<span class="badge badge-fail">Rejected</span>`
                            : html`<span class="badge badge-warn">Pending</span>`}
                </header>
                <div class="card-body">
                    <div class="field">
                        <label for="ap-am">Account Manager Name <span class="req">*</span></label>
                        <input type="text" id="ap-am" value="${e.am_name || ''}" maxlength="120"
                               placeholder="Alex Bennett" ${canApprove ? '' : ui.raw('disabled')}>
                    </div>

                    <div class="field">
                        <label for="ap-message">QA Approval Message</label>
                        <textarea id="ap-message" placeholder="Summary of the validation outcome shared with the account team…"
                                  ${canApprove ? '' : ui.raw('disabled')}>${e.approval_message || ''}</textarea>
                    </div>

                    <div class="field">
                        <label for="ap-notes">QA Notes</label>
                        <textarea id="ap-notes" placeholder="Internal notes, follow-ups or known limitations…">${e.qa_notes || ''}</textarea>
                    </div>

                    <div class="field">
                        <label>Approval file (EML / MSG)</label>
                        <div class="dropzone" id="approval-dropzone" tabindex="0" role="button">
                            <strong>Drop the approval e-mail here or click to browse</strong>
                            <small>Accepts .eml and .msg — attached as approval evidence.</small>
                            <input type="file" id="approval-input" hidden accept=".eml,.msg">
                        </div>
                        <div class="evidence-chips mt-2" id="approval-chips">
                            ${ctx.evidence.filter(function (f) { return f.category === 'approval'; })
                                .map(evidenceChip).join('')}
                        </div>
                    </div>

                    ${canApprove ? html`
                        <div class="row wrap mt-3">
                            <button type="button" class="btn btn-success" data-decide="approved">Approve execution</button>
                            <button type="button" class="btn btn-danger" data-decide="rejected">Reject build</button>
                            <button type="button" class="btn" data-save-approval>Save notes</button>
                        </div>
                    ` : html`
                        <p class="hint mb-0">Only a QA Lead or Admin can approve or reject an execution.</p>
                    `}
                </div>
            </div>

            <div class="card">
                <header class="card-header">
                    <h2>Reports &amp; Exports</h2>
                </header>
                <div class="card-body">
                    <div class="row wrap mb-3">
                        <button type="button" class="btn btn-primary btn-sm" data-gen-report>Generate PDF report</button>
                        <a class="btn btn-sm" href="${QA.api.pdfUrl(e.id)}" target="_blank" rel="noopener">Download PDF now</a>
                        <a class="btn btn-sm" href="${QA.api.csvUrl(e.id)}">Export CSV</a>
                        <a class="btn btn-sm" href="#/executions/${e.id}/print">Print view</a>
                    </div>

                    ${reports.length ? html`
                        <div class="table-wrap">
                            <table class="table">
                                <thead><tr><th>File</th><th>Type</th><th>Size</th><th>Generated</th><th></th></tr></thead>
                                <tbody>
                                    ${reports.map(function (r) {
                                        return html`<tr>
                                            <td class="cell-main">${r.file_name}</td>
                                            <td><span class="badge badge-mute">${String(r.report_type).toUpperCase()}</span></td>
                                            <td class="num muted">${ui.bytes(r.file_size)}</td>
                                            <td class="muted nowrap">${ui.fmtDate(r.created_at, true)}</td>
                                            <td class="actions-cell">
                                                <a class="btn btn-xs" href="/api/reports/${r.id}/download">Download</a>
                                            </td>
                                        </tr>`;
                                    })}
                                </tbody>
                            </table>
                        </div>
                    ` : html`<p class="muted mb-0" style="font-size:.82rem">No reports generated yet.</p>`}
                </div>
            </div>
        `;

        const dropzone = body.querySelector('#approval-dropzone');
        const input = body.querySelector('#approval-input');

        if (dropzone && input) {
            dropzone.addEventListener('click', function () { input.click(); });
            dropzone.addEventListener('keydown', function (event) {
                if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); input.click(); }
            });
            input.addEventListener('change', async function () {
                if (input.files && input.files.length) {
                    await uploadApproval(input.files[0]);
                }
                input.value = '';
            });
        }

        body.querySelectorAll('[data-decide]').forEach(function (btn) {
            btn.addEventListener('click', function () { decide(btn.dataset.decide, body); });
        });

        const saveBtn = body.querySelector('[data-save-approval]');
        if (saveBtn) saveBtn.addEventListener('click', function () { decide(null, body); });

        const genBtn = body.querySelector('[data-gen-report]');
        if (genBtn) {
            genBtn.addEventListener('click', async function () {
                genBtn.disabled = true;
                genBtn.innerHTML = '<span class="spinner"></span> Generating…';
                try {
                    const data = await QA.api.generateReport(ctx.id);
                    ui.toast('PDF report generated.', 'success');
                    window.open(data.report.download_url, '_blank', 'noopener');
                    await load(ctx.id);
                    paintTabs(document.querySelector('#main-content'));
                } catch (error) {
                    ui.toast(error.message, 'error');
                    genBtn.disabled = false;
                    genBtn.textContent = 'Generate PDF report';
                }
            });
        }
    }

    async function uploadApproval(file) {
        const formData = new FormData();
        formData.append('files[]', file);
        formData.append('category', 'approval');

        ui.busy('Uploading approval file…');
        try {
            const data = await QA.api.uploadEvidence(ctx.id, formData);
            (data.files || []).forEach(function (f) { ctx.evidence.unshift(f); });
            const chips = document.querySelector('#approval-chips');
            if (chips) {
                chips.innerHTML = ctx.evidence.filter(function (f) { return f.category === 'approval'; })
                    .map(evidenceChip).join('');
            }
            refreshSummary();
            ui.toast('Approval file attached.', 'success');
        } catch (error) {
            ui.toast(error.message, 'error');
        } finally {
            ui.idle();
        }
    }

    async function decide(decision, body) {
        const amName = body.querySelector('#ap-am').value.trim();
        const message = body.querySelector('#ap-message').value.trim();
        const notes = body.querySelector('#ap-notes').value.trim();

        if (decision === 'approved' && !amName) {
            ui.toast('The Account Manager name is required to approve.', 'error');
            body.querySelector('#ap-am').focus();
            return;
        }

        ui.busy(decision === 'approved' ? 'Approving…' : decision === 'rejected' ? 'Rejecting…' : 'Saving…');

        try {
            const result = await QA.api.setApproval(ctx.id, {
                decision: decision || ctx.execution.approval_status || 'pending',
                am_name: amName,
                approval_message: message,
                qa_notes: notes
            });

            ctx.execution = Object.assign(ctx.execution, result.execution);
            ui.toast(decision === 'approved' ? 'Execution approved.' : decision === 'rejected' ? 'Build rejected.' : 'Notes saved.',
                decision === 'rejected' ? 'warn' : 'success');
            paintTabs(document.querySelector('#main-content'));
        } catch (error) {
            ui.toast(error.message, 'error');
        } finally {
            ui.idle();
        }
    }

    /* =================================================================
       Header actions
       ================================================================= */

    async function handleAction(action, main) {
        if (action === 'run-auto') return runAutomation(main);
        if (action === 'report') {
            ui.busy('Generating report…');
            try {
                const data = await QA.api.generateReport(ctx.id);
                ui.toast('Report generated.', 'success');
                window.open(data.report.download_url, '_blank', 'noopener');
            } catch (error) {
                ui.toast(error.message, 'error');
            } finally {
                ui.idle();
            }
            return;
        }

        if (action === 'duplicate') {
            try {
                const result = await QA.api.duplicateExecution(ctx.id);
                ui.toast('Duplicated as a new draft.', 'success');
                global.location.hash = '#/executions/' + result.execution.id;
            } catch (error) {
                ui.toast(error.message, 'error');
            }
            return;
        }

        if (action === 'edit-info') return openEditInfo();
        if (action === 'delete') return deleteExecution();

        if (action === 'submit') {
            if (!await ui.confirm({
                title: 'Submit for review',
                message: 'Submit this execution for QA approval? All ' + (ctx.meta.total_items || 41) + ' items must be decided first.',
                confirmLabel: 'Submit'
            })) return;

            ui.busy('Submitting…');
            try {
                await QA.api.submitExecution(ctx.id);
                ui.toast('Execution submitted for review.', 'success');
                await load(ctx.id);
                paint(main);
            } catch (error) {
                ui.toast(error.message, 'error');
            } finally {
                ui.idle();
            }
        }
    }

    function openEditInfo() {
        const e = ctx.execution;

        ui.modal({
            title: 'Edit general information',
            subtitle: 'Execution #' + e.id,
            size: 'wide',
            body: html`
                <form id="edit-info-form">
                    <div class="field-row">
                        <div class="field">
                            <label for="ei-client">Client Name</label>
                            <input type="text" id="ei-client" value="${e.client_name}" required maxlength="160">
                        </div>
                        <div class="field">
                            <label for="ei-campaign">Campaign Name</label>
                            <input type="text" id="ei-campaign" value="${e.campaign_name}" required maxlength="160">
                        </div>
                    </div>
                    <div class="field-row">
                        <div class="field">
                            <label for="ei-form">Donation Form Name</label>
                            <input type="text" id="ei-form" value="${e.form_name}" required maxlength="180">
                        </div>
                        <div class="field">
                            <label for="ei-env">Environment</label>
                            <select id="ei-env">
                                ${Object.keys(ctx.meta.environments || {}).map(function (key) {
                                    return html`<option value="${key}" ${key === e.environment ? ui.raw('selected') : ''}>${ctx.meta.environments[key]}</option>`;
                                })}
                            </select>
                        </div>
                    </div>
                    <div class="field">
                        <label for="ei-url">Donation Form URL</label>
                        <input type="url" id="ei-url" value="${e.form_url}" required maxlength="500">
                    </div>
                    <div class="field">
                        <label for="ei-template">Template URL</label>
                        <input type="url" id="ei-template" value="${e.template_url || ''}" maxlength="500">
                    </div>
                    <div class="field-row-3">
                        <div class="field">
                            <label for="ei-analyst">QA Analyst</label>
                            <input type="text" id="ei-analyst" value="${e.qa_analyst_name}" required maxlength="120">
                        </div>
                        <div class="field">
                            <label for="ei-build">Build Timestamp</label>
                            <input type="datetime-local" id="ei-build" value="${(e.build_timestamp || '').replace(' ', 'T').slice(0, 16)}">
                        </div>
                        <div class="field">
                            <label for="ei-browser">Browser</label>
                            <input type="text" id="ei-browser" value="${e.browser_used || ''}" maxlength="80">
                        </div>
                    </div>
                    <div class="field" style="max-width:220px">
                        <label for="ei-date">Test Date</label>
                        <input type="date" id="ei-date" value="${e.test_date || ''}">
                    </div>
                </form>
            `,
            footer: html`
                <button type="button" class="btn" data-modal-close>Cancel</button>
                <button type="button" class="btn btn-primary" id="ei-save">Save changes</button>
            `,
            onMount: function (root) {
                root.querySelector('#ei-save').addEventListener('click', async function (event) {
                    const btn = event.currentTarget;
                    const payload = {
                        client_name: root.querySelector('#ei-client').value.trim(),
                        campaign_name: root.querySelector('#ei-campaign').value.trim(),
                        form_name: root.querySelector('#ei-form').value.trim(),
                        environment: root.querySelector('#ei-env').value,
                        form_url: root.querySelector('#ei-url').value.trim(),
                        template_url: root.querySelector('#ei-template').value.trim(),
                        qa_analyst_name: root.querySelector('#ei-analyst').value.trim(),
                        build_timestamp: root.querySelector('#ei-build').value,
                        browser_used: root.querySelector('#ei-browser').value.trim(),
                        test_date: root.querySelector('#ei-date').value,
                        form_id: e.form_id
                    };

                    btn.disabled = true;
                    btn.innerHTML = '<span class="spinner"></span> Saving…';

                    try {
                        const result = await QA.api.updateExecution(ctx.id, payload);
                        ctx.execution = Object.assign(ctx.execution, result.execution);
                        ui.closeModal();
                        ui.toast('General information updated.', 'success');
                        paint(document.querySelector('#main-content'));
                    } catch (error) {
                        ui.toast(error.message, 'error');
                        btn.disabled = false;
                        btn.textContent = 'Save changes';
                    }
                });
            }
        });
    }

    async function deleteExecution() {
        if (!await ui.confirm({
            title: 'Delete execution',
            message: 'This permanently deletes the execution, its checklist results, evidence files and reports.',
            confirmLabel: 'Delete permanently',
            danger: true
        })) return;

        try {
            await QA.api.deleteExecution(ctx.id);
            ui.toast('Execution deleted.', 'success');
            global.location.hash = '#/executions';
        } catch (error) {
            ui.toast(error.message, 'error');
        }
    }

    function shortUrl(url) {
        try {
            const parsed = new URL(url);
            const path = parsed.pathname.length > 42 ? parsed.pathname.slice(0, 42) + '…' : parsed.pathname;
            return parsed.host + path;
        } catch (error) {
            return url;
        }
    }

    QA.views = QA.views || {};
    QA.views.executionDetail = { render: render, load: load, ctx: function () { return ctx; } };
})(window);
