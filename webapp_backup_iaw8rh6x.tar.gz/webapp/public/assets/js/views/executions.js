/* =====================================================================
   views/executions.js — execution list, filters, new-run wizard
   ===================================================================== */
(function (global) {
    'use strict';

    const QA = global.QA;
    const html = QA.html;
    const ui = QA.ui;

    const state = {
        filters: { search: '', status: '', environment: '', client: '', page: 1, scope: '' },
        meta: null
    };

    /* =================== LIST =================== */

    async function render(main) {
        main.innerHTML = html`
            <div class="page-head">
                <div class="titles">
                    <div class="eyebrow">History</div>
                    <h1>QA Executions</h1>
                    <div class="subtitle">Every validation run with filters, history and re-open support.</div>
                </div>
                <div class="actions">
                    <a class="btn btn-primary" href="#/executions/new">+ New QA Run</a>
                </div>
            </div>

            <form class="filters" id="exec-filters" role="search">
                <div class="field grow">
                    <label for="f-search">Search</label>
                    <input type="search" id="f-search" name="search" placeholder="Client, campaign, form or URL…" value="">
                </div>
                <div class="field">
                    <label for="f-status">Status</label>
                    <select id="f-status" name="status">
                        <option value="">All statuses</option>
                    </select>
                </div>
                <div class="field">
                    <label for="f-env">Environment</label>
                    <select id="f-env" name="environment">
                        <option value="">All environments</option>
                    </select>
                </div>
                <div class="field">
                    <label for="f-client">Client</label>
                    <select id="f-client" name="client">
                        <option value="">All clients</option>
                    </select>
                </div>
                <div class="field">
                    <label for="f-scope">Scope</label>
                    <select id="f-scope" name="scope">
                        <option value="">My executions</option>
                        <option value="all">Everyone's</option>
                    </select>
                </div>
                <div class="filters-actions">
                    <button type="submit" class="btn btn-primary btn-sm">Apply</button>
                    <button type="reset" class="btn btn-sm" id="f-reset">Reset</button>
                </div>
            </form>

            <div class="card">
                <div class="card-body tight" id="exec-table">
                    <div class="card-body"><div class="skeleton" style="height:190px"></div></div>
                </div>
            </div>
        `;

        const form = main.querySelector('#exec-filters');

        // Populate selects from the list response itself.
        form.addEventListener('submit', function (event) {
            event.preventDefault();
            state.filters.search = form.search.value.trim();
            state.filters.status = form.status.value;
            state.filters.environment = form.environment.value;
            state.filters.client = form.client.value;
            state.filters.scope = form.scope.value;
            state.filters.page = 1;
            loadList(main);
        });

        main.querySelector('#f-reset').addEventListener('click', function () {
            state.filters = { search: '', status: '', environment: '', client: '', page: 1, scope: '' };
            setTimeout(function () { loadList(main); }, 0);
        });

        await loadList(main);
    }

    async function loadList(main) {
        const container = main.querySelector('#exec-table');
        if (!container) return;

        let data;
        try {
            data = await QA.api.executions({
                search: state.filters.search,
                status: state.filters.status,
                environment: state.filters.environment,
                client: state.filters.client,
                scope: state.filters.scope,
                page: state.filters.page,
                per_page: 15
            });
        } catch (error) {
            container.innerHTML = html`<div class="empty">
                <div class="empty-icon">⚠</div><h3>Could not load executions</h3><p>${error.message}</p>
            </div>`;
            return;
        }

        // Fill filter dropdowns once.
        const form = main.querySelector('#exec-filters');
        const statusSelect = form.querySelector('#f-status');
        const envSelect = form.querySelector('#f-env');
        const clientSelect = form.querySelector('#f-client');

        if (!statusSelect.dataset.filled) {
            Object.keys(data.statuses || {}).forEach(function (key) {
                const opt = document.createElement('option');
                opt.value = key;
                opt.textContent = data.statuses[key];
                statusSelect.appendChild(opt);
            });
            Object.keys(data.environments || {}).forEach(function (key) {
                const opt = document.createElement('option');
                opt.value = key;
                opt.textContent = data.environments[key];
                envSelect.appendChild(opt);
            });
            (data.clients || []).forEach(function (name) {
                const opt = document.createElement('option');
                opt.value = name;
                opt.textContent = name;
                clientSelect.appendChild(opt);
            });
            statusSelect.dataset.filled = '1';
        }

        statusSelect.value = state.filters.status;
        envSelect.value = state.filters.environment;
        clientSelect.value = state.filters.client;
        form.querySelector('#f-scope').value = state.filters.scope;
        form.querySelector('#f-search').value = state.filters.search;

        const rows = data.executions || [];
        const pagination = data.pagination || {};

        if (!rows.length) {
            container.innerHTML = html`<div class="empty">
                <div class="empty-icon">▤</div>
                <h3>No executions found</h3>
                <p>Adjust your filters, or start a new QA run to create the first execution.</p>
                <a class="btn btn-primary btn-sm" href="#/executions/new">New QA run</a>
            </div>`;
            return;
        }

        container.innerHTML = html`
            <div class="table-wrap">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Form</th>
                            <th>Environment</th>
                            <th>Status</th>
                            <th>Items</th>
                            <th>Score</th>
                            <th>Analyst</th>
                            <th>Updated</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        ${rows.map(function (row) {
                            return html`<tr data-id="${row.id}">
                                <td>
                                    <div class="cell-main">${row.form_name}</div>
                                    <div class="cell-sub">${row.client_name} · ${row.campaign_name}</div>
                                </td>
                                <td>${ui.envBadge(row.environment)}</td>
                                <td>${ui.execBadge(row.status)}</td>
                                <td class="num muted">${row.total_items - row.untested_count}/${row.total_items}</td>
                                <td>
                                    <div class="row" style="gap:8px">
                                        <div class="mini-bar ${ui.rateClass(Number(row.pass_rate))}">
                                            <span style="width:${Number(row.pass_rate) || 0}%"></span>
                                        </div>
                                        <span class="mono" style="font-size:.78rem">${ui.pct(row.pass_rate)}</span>
                                    </div>
                                </td>
                                <td class="muted">${row.qa_analyst_name || '—'}</td>
                                <td class="muted nowrap" title="${row.updated_at}">${ui.relTime(row.updated_at)}</td>
                                <td class="actions-cell">
                                    <button type="button" class="btn btn-xs" data-open="${row.id}">Open</button>
                                    <button type="button" class="btn btn-xs" data-duplicate="${row.id}" title="Duplicate this execution">Copy</button>
                                </td>
                            </tr>`;
                        })}
                    </tbody>
                </table>
            </div>
            ${renderPagination(pagination)}
        `;

        container.querySelectorAll('[data-open]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                global.location.hash = '#/executions/' + btn.dataset.open;
            });
        });

        container.querySelectorAll('[data-duplicate]').forEach(function (btn) {
            btn.addEventListener('click', async function () {
                btn.disabled = true;
                try {
                    const result = await QA.api.duplicateExecution(btn.dataset.duplicate);
                    ui.toast('Execution duplicated — opening the new draft.', 'success');
                    global.location.hash = '#/executions/' + result.execution.id;
                } catch (error) {
                    ui.toast(error.message, 'error');
                    btn.disabled = false;
                }
            });
        });

        container.querySelectorAll('[data-page]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                state.filters.page = Number(btn.dataset.page);
                loadList(main);
            });
        });
    }

    function renderPagination(p) {
        if (!p || !p.pages || p.pages <= 1) {
            return '';
        }

        const buttons = [];
        const current = p.page;
        const pages = p.pages;
        const windowStart = Math.max(1, current - 2);
        const windowEnd = Math.min(pages, windowStart + 4);

        buttons.push(html`<button type="button" class="page-btn" data-page="${current - 1}" ${current === 1 ? raw2('disabled') : ''}>‹</button>`);

        if (windowStart > 1) {
            buttons.push(html`<button type="button" class="page-btn" data-page="1">1</button>`);
            if (windowStart > 2) buttons.push(html`<span class="muted">…</span>`);
        }

        for (let i = windowStart; i <= windowEnd; i++) {
            buttons.push(html`<button type="button" class="page-btn ${i === current ? 'is-active' : ''}" data-page="${i}">${i}</button>`);
        }

        if (windowEnd < pages) {
            if (windowEnd < pages - 1) buttons.push(html`<span class="muted">…</span>`);
            buttons.push(html`<button type="button" class="page-btn" data-page="${pages}">${pages}</button>`);
        }

        buttons.push(html`<button type="button" class="page-btn" data-page="${current + 1}" ${current === pages ? raw2('disabled') : ''}>›</button>`);

        return html`<div class="pagination">
            <span class="page-info">${p.total} execution${p.total === 1 ? '' : 's'} · page ${p.page} of ${p.pages}</span>
            ${buttons}
        </div>`;
    }

    // tiny disabled-attribute helper (avoid raw() name clash)
    function raw2(value) {
        return ui.raw(value);
    }

    /* =================== NEW RUN WIZARD =================== */

    async function renderNew(main) {
        main.innerHTML = html`
            <div class="page-head">
                <div class="titles">
                    <div class="eyebrow">New validation</div>
                    <h1>Start a QA Execution</h1>
                    <div class="subtitle">Capture the general information, then run automated checks before the manual checklist.</div>
                </div>
                <div class="actions">
                    <a class="btn btn-ghost" href="#/executions">Cancel</a>
                </div>
            </div>
            <div id="wizard-body"><div class="card"><div class="card-body"><div class="skeleton" style="height:260px"></div></div></div></div>
        `;

        let catalog;
        try {
            catalog = await QA.api.catalog();
        } catch (error) {
            main.querySelector('#wizard-body').innerHTML = html`<div class="card"><div class="empty">
                <h3>Could not load the catalogue</h3><p>${error.message}</p></div></div>`;
            return;
        }

        const body = main.querySelector('#wizard-body');
        const me = QA.api.state.user || {};

        body.innerHTML = html`
            <form id="new-run-form" novalidate>
                <div class="card mb-3">
                    <header class="card-header">
                        <h2>General Information</h2>
                        <span class="badge badge-accent">Required</span>
                    </header>
                    <div class="card-body">
                        <div class="field">
                            <label for="nr-form">Existing donation form (optional)</label>
                            <select id="nr-form" name="form_id">
                                <option value="">— Enter details manually —</option>
                                ${(catalog.forms || []).map(function (f) {
                                    return html`<option value="${f.id}"
                                        data-client="${f.client_name}"
                                        data-campaign="${f.campaign_name}"
                                        data-name="${f.name}"
                                        data-env="${f.environment}"
                                        data-url="${f.url || ''}"
                                        data-template="${f.template_url || ''}">${f.client_name} · ${f.campaign_name} · ${f.name}</option>`;
                                })}
                            </select>
                            <span class="hint">Selecting a saved form pre-fills the fields below.</span>
                        </div>

                        <div class="field-row">
                            <div class="field">
                                <label for="nr-client">Client Name <span class="req">*</span></label>
                                <input type="text" id="nr-client" name="client_name" required maxlength="160"
                                       list="client-suggestions" placeholder="Northwind Relief">
                                <datalist id="client-suggestions">
                                    ${(catalog.clients || []).map(function (c) {
                                        return html`<option value="${c.name}"></option>`;
                                    })}
                                </datalist>
                            </div>
                            <div class="field">
                                <label for="nr-campaign">Campaign Name <span class="req">*</span></label>
                                <input type="text" id="nr-campaign" name="campaign_name" required maxlength="160"
                                       placeholder="Winter Emergency Appeal">
                            </div>
                        </div>

                        <div class="field-row">
                            <div class="field">
                                <label for="nr-name">Donation Form Name <span class="req">*</span></label>
                                <input type="text" id="nr-name" name="form_name" required maxlength="180"
                                       placeholder="WEA24 - Single Step Donation">
                            </div>
                            <div class="field">
                                <label for="nr-env">Environment <span class="req">*</span></label>
                                <select id="nr-env" name="environment" required>
                                    ${Object.keys(catalog.environments || {}).map(function (key) {
                                        return html`<option value="${key}" ${key === 'staging' ? ui.raw('selected') : ''}>${catalog.environments[key]}</option>`;
                                    })}
                                </select>
                            </div>
                        </div>

                        <div class="field">
                            <label for="nr-url">Donation Form URL <span class="req">*</span></label>
                            <input type="url" id="nr-url" name="form_url" required maxlength="500"
                                   placeholder="https://www.example.org/donate/winter-emergency">
                            <span class="hint">Automated validation will fetch this URL.</span>
                        </div>

                        <div class="field">
                            <label for="nr-template">Template URL <span class="muted">(optional)</span></label>
                            <input type="url" id="nr-template" name="template_url" maxlength="500"
                                   placeholder="https://templates.example.org/df-single-step.html">
                            <span class="hint">Enables a copy/heading similarity comparison against the approved template.</span>
                        </div>

                        <div class="field-row-3 mt-2">
                            <div class="field">
                                <label for="nr-analyst">QA Analyst <span class="req">*</span></label>
                                <input type="text" id="nr-analyst" name="qa_analyst_name" required maxlength="120"
                                       value="${me.name || ''}">
                            </div>
                            <div class="field">
                                <label for="nr-build">Build Timestamp</label>
                                <input type="datetime-local" id="nr-build" name="build_timestamp">
                            </div>
                            <div class="field">
                                <label for="nr-browser">Browser Used</label>
                                <input type="text" id="nr-browser" name="browser_used" list="browser-suggestions"
                                       maxlength="80" placeholder="Chrome 127">
                                <datalist id="browser-suggestions">
                                    ${(catalog.browsers || []).map(function (b) {
                                        return html`<option value="${b}"></option>`;
                                    })}
                                </datalist>
                            </div>
                        </div>

                        <div class="field-row mt-2">
                            <div class="field">
                                <label for="nr-date">Test Date</label>
                                <input type="date" id="nr-date" name="test_date" value="${new Date().toISOString().slice(0, 10)}">
                            </div>
                        </div>
                    </div>
                    <footer class="card-footer">
                        <button type="submit" class="btn btn-primary" id="nr-submit">Create execution &amp; run automation</button>
                        <label class="checkbox-row mb-0" style="margin-left:8px">
                            <input type="checkbox" id="nr-skip-auto" checked>
                            <label for="nr-skip-auto" style="font-size:.8rem">Skip automated URL checks for now</label>
                        </label>
                    </footer>
                </div>
            </form>
        `;

        const form = body.querySelector('#new-run-form');

        // Prefill from a saved form.
        form.form_id.addEventListener('change', function () {
            const opt = form.form_id.selectedOptions[0];
            if (!opt || !opt.dataset.client) return;
            form.client_name.value = opt.dataset.client || '';
            form.campaign_name.value = opt.dataset.campaign || '';
            form.form_name.value = opt.dataset.name || '';
            form.environment.value = opt.dataset.env || 'staging';
            form.form_url.value = opt.dataset.url || '';
            form.template_url.value = opt.dataset.template || '';
        });

        form.addEventListener('submit', async function (event) {
            event.preventDefault();

            const payload = {
                form_id: form.form_id.value || null,
                client_name: form.client_name.value.trim(),
                campaign_name: form.campaign_name.value.trim(),
                form_name: form.form_name.value.trim(),
                environment: form.environment.value,
                form_url: form.form_url.value.trim(),
                template_url: form.template_url.value.trim(),
                qa_analyst_name: form.qa_analyst_name.value.trim(),
                build_timestamp: form.build_timestamp.value,
                browser_used: form.browser_used.value.trim(),
                test_date: form.test_date.value
            };

            const missing = ['client_name', 'campaign_name', 'form_name', 'form_url', 'qa_analyst_name']
                .filter(function (key) { return !payload[key]; });

            if (missing.length) {
                ui.toast('Complete the required fields: ' + missing.map(ui.titleCase).join(', '), 'error');
                const first = form[missing[0]];
                if (first) { first.focus(); first.setAttribute('aria-invalid', 'true'); }
                return;
            }

            const submitBtn = body.querySelector('#nr-submit');
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<span class="spinner"></span> Creating…';

            let created;
            try {
                created = await QA.api.createExecution(payload);
            } catch (error) {
                ui.toast(error.message, 'error');
                submitBtn.disabled = false;
                submitBtn.textContent = 'Create execution & run automation';
                return;
            }

            const id = created.execution.id;

            if (!form.querySelector('#nr-skip-auto').checked) {
                submitBtn.innerHTML = '<span class="spinner"></span> Running automated checks…';
                try {
                    await QA.api.runAutomation(id, payload.form_url);
                    ui.toast('Automated validation completed.', 'success');
                } catch (error) {
                    ui.toast('Execution created, but automation failed: ' + error.message, 'warn');
                }
            } else {
                ui.toast('Execution created as a draft.', 'success');
            }

            global.location.hash = '#/executions/' + id;
        });
    }

    QA.views = QA.views || {};
    QA.views.executions = { render: render, renderNew: renderNew };
})(window);
