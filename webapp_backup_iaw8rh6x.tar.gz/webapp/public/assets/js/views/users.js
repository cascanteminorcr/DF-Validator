/* =====================================================================
   views/users.js — user administration (admin only)
   ===================================================================== */
(function (global) {
    'use strict';

    const QA = global.QA;
    const html = QA.html;
    const ui = QA.ui;

    let roles = {};

    async function render(main) {
        main.innerHTML = html`
            <div class="page-head">
                <div class="titles">
                    <div class="eyebrow">Administration</div>
                    <h1>Users &amp; Roles</h1>
                    <div class="subtitle">Admins manage accounts. QA Leads approve executions. QA Analysts run validations.</div>
                </div>
                <div class="actions">
                    <button type="button" class="btn btn-primary" data-add-user>+ New user</button>
                </div>
            </div>
            <div id="users-body"><div class="card"><div class="card-body"><div class="skeleton" style="height:200px"></div></div></div></div>
        `;

        main.querySelector('[data-add-user]').addEventListener('click', function () { openUser(main, null); });
        await load(main);
    }

    async function load(main) {
        const body = main.querySelector('#users-body');
        if (!body) return;

        let data;
        try {
            data = await QA.api.users();
        } catch (error) {
            body.innerHTML = html`<div class="card"><div class="empty">
                <div class="empty-icon">⚠</div><h3>Access denied</h3><p>${error.message}</p>
            </div></div>`;
            return;
        }

        roles = data.roles || {};
        const rows = data.users || [];

        body.innerHTML = html`
            <div class="card">
                <div class="card-body tight">
                    <div class="table-wrap">
                        <table class="table">
                            <thead>
                                <tr><th>User</th><th>Role</th><th>Status</th><th>Last sign-in</th><th>Created</th><th></th></tr>
                            </thead>
                            <tbody>
                                ${rows.map(function (row) {
                                    return html`<tr>
                                        <td>
                                            <div class="row" style="gap:9px">
                                                <span class="avatar">${ui.initials(row.name)}</span>
                                                <div>
                                                    <div class="cell-main">${row.name}</div>
                                                    <div class="cell-sub">${row.email}</div>
                                                </div>
                                            </div>
                                        </td>
                                        <td><span class="badge badge-accent">${roles[row.role] || row.role}</span></td>
                                        <td>${Number(row.is_active)
                                            ? html`<span class="badge badge-pass">Active</span>`
                                            : html`<span class="badge badge-mute">Disabled</span>`}</td>
                                        <td class="muted nowrap">${row.last_login_at ? ui.relTime(row.last_login_at) : 'never'}</td>
                                        <td class="muted nowrap">${ui.fmtDate(row.created_at)}</td>
                                        <td class="actions-cell">
                                            <button type="button" class="btn btn-xs" data-edit-user="${row.id}">Edit</button>
                                            <button type="button" class="btn btn-xs btn-danger" data-del-user="${row.id}">Delete</button>
                                        </td>
                                    </tr>`;
                                })}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;

        body.querySelectorAll('[data-edit-user]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                const user = rows.filter(function (u) { return String(u.id) === btn.dataset.editUser; })[0];
                openUser(main, user);
            });
        });

        body.querySelectorAll('[data-del-user]').forEach(function (btn) {
            btn.addEventListener('click', async function () {
                const user = rows.filter(function (u) { return String(u.id) === btn.dataset.delUser; })[0];

                if (!await ui.confirm({
                    title: 'Delete user',
                    message: 'Delete ' + (user ? user.name : 'this user') + '? Their executions are preserved but unassigned.',
                    confirmLabel: 'Delete',
                    danger: true
                })) return;

                try {
                    await QA.api.deleteUser(btn.dataset.delUser);
                    ui.toast('User deleted.', 'success');
                    await load(main);
                } catch (error) {
                    ui.toast(error.message, 'error');
                }
            });
        });
    }

    function openUser(main, user) {
        const isEdit = !!user;

        ui.modal({
            title: isEdit ? 'Edit user' : 'New user',
            size: 'narrow',
            body: html`
                <div class="field">
                    <label for="uf-name">Full name <span class="req">*</span></label>
                    <input type="text" id="uf-name" value="${isEdit ? user.name : ''}" maxlength="120" required>
                </div>
                <div class="field">
                    <label for="uf-email">E-mail <span class="req">*</span></label>
                    <input type="email" id="uf-email" value="${isEdit ? user.email : ''}" maxlength="190" required>
                </div>
                <div class="field">
                    <label for="uf-role">Role <span class="req">*</span></label>
                    <select id="uf-role">
                        ${Object.keys(roles).map(function (key) {
                            const selected = isEdit ? user.role === key : key === 'qa_analyst';
                            return html`<option value="${key}" ${selected ? ui.raw('selected') : ''}>${roles[key]}</option>`;
                        })}
                    </select>
                </div>
                <div class="field">
                    <label for="uf-password">${isEdit ? 'New password (leave blank to keep)' : 'Password'} ${isEdit ? '' : html`<span class="req">*</span>`}</label>
                    <input type="password" id="uf-password" autocomplete="new-password" minlength="10"
                           placeholder="At least 10 characters">
                </div>
                ${isEdit ? html`<label class="checkbox-row">
                    <input type="checkbox" id="uf-active" ${Number(user.is_active) ? ui.raw('checked') : ''}>
                    <span class="soft">Account active</span>
                </label>` : ''}
            `,
            footer: html`
                <button type="button" class="btn" data-modal-close>Cancel</button>
                <button type="button" class="btn btn-primary" id="uf-save">${isEdit ? 'Save changes' : 'Create user'}</button>
            `,
            onMount: function (root) {
                root.querySelector('#uf-save').addEventListener('click', async function (event) {
                    const btn = event.currentTarget;
                    const payload = {
                        name: root.querySelector('#uf-name').value.trim(),
                        email: root.querySelector('#uf-email').value.trim(),
                        role: root.querySelector('#uf-role').value,
                        password: root.querySelector('#uf-password').value
                    };

                    if (isEdit) payload.is_active = root.querySelector('#uf-active').checked;

                    if (!payload.name || !payload.email) {
                        ui.toast('Name and e-mail are required.', 'error');
                        return;
                    }
                    if (!isEdit && payload.password.length < 10) {
                        ui.toast('Password must be at least 10 characters.', 'error');
                        return;
                    }
                    if (isEdit && payload.password && payload.password.length < 10) {
                        ui.toast('Password must be at least 10 characters.', 'error');
                        return;
                    }

                    btn.disabled = true;
                    btn.innerHTML = '<span class="spinner"></span> Saving…';

                    try {
                        if (isEdit) await QA.api.updateUser(user.id, payload);
                        else await QA.api.createUser(payload);

                        ui.closeModal();
                        ui.toast('User saved.', 'success');
                        await load(main);
                    } catch (error) {
                        ui.toast(error.message, 'error');
                        btn.disabled = false;
                        btn.textContent = isEdit ? 'Save changes' : 'Create user';
                    }
                });
            }
        });
    }

    QA.views = QA.views || {};
    QA.views.users = { render: render };
})(window);
