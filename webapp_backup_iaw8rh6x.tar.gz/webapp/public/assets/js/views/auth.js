/* =====================================================================
   views/auth.js — sign-in screen
   ===================================================================== */
(function (global) {
    'use strict';

    const QA = global.QA;
    const html = QA.html;

    const DEMO = [
        { email: 'admin@qa.local', password: 'QaValidator!2024', role: 'Admin' },
        { email: 'lead@qa.local', password: 'QaValidator!2024', role: 'QA Lead' },
        { email: 'analyst@qa.local', password: 'QaValidator!2024', role: 'QA Analyst' }
    ];

    function render(main) {
        main.innerHTML = html`
            <div class="auth-screen">
                <aside class="auth-aside">
                    <div class="row" style="gap:11px">
                        <span class="brand-mark" aria-hidden="true">QA</span>
                        <div class="brand-text">
                            <strong>Donation Form QA Validator</strong>
                            <small>Pre-approval validation suite</small>
                        </div>
                    </div>

                    <h1>Ship donation forms with evidence, not guesswork.</h1>
                    <p class="lede">
                        Run the structured QA process end to end: automated URL, Open Graph,
                        analytics, accessibility and link checks, a 43-point manual checklist,
                        timestamped evidence capture and an approval-ready PDF report.
                    </p>

                    <div class="auth-features">
                        <div class="auth-feature">
                            <span class="tick" aria-hidden="true">✓</span>
                            <div>
                                <strong>Automated first pass</strong>
                                <span>HTTP status, HTTPS, mixed content, OG tags, GTM / GA / Pixel and broken links in one run.</span>
                            </div>
                        </div>
                        <div class="auth-feature">
                            <span class="tick" aria-hidden="true">✓</span>
                            <div>
                                <strong>Creative + Functional checklist</strong>
                                <span>41 controlled items with Pass / Fail / N/A, mandatory fail comments and screenshot evidence.</span>
                            </div>
                        </div>
                        <div class="auth-feature">
                            <span class="tick" aria-hidden="true">✓</span>
                            <div>
                                <strong>Audit trail &amp; approvals</strong>
                                <span>Autosaved drafts, re-openable history, duplication and role-gated QA sign-off.</span>
                            </div>
                        </div>
                    </div>
                </aside>

                <section class="auth-panel">
                    <div class="auth-form">
                        <div class="auth-card">
                            <h2>Sign in</h2>
                            <p class="auth-sub">Use your QA workspace credentials.</p>

                            <form id="login-form" novalidate>
                                <div class="field">
                                    <label for="login-email">E-mail address</label>
                                    <input type="email" id="login-email" name="email" autocomplete="username"
                                           placeholder="you@agency.com" required autofocus>
                                </div>
                                <div class="field">
                                    <label for="login-password">Password</label>
                                    <input type="password" id="login-password" name="password"
                                           autocomplete="current-password" placeholder="••••••••••" required>
                                </div>
                                <div id="login-error" class="field-error mb-2" role="alert" hidden></div>
                                <button type="submit" class="btn btn-primary btn-block" id="login-submit">
                                    Sign in
                                </button>
                            </form>

                            <div class="demo-accounts" id="demo-accounts">
                                <div class="demo-title">Demo accounts (password: QaValidator!2024)</div>
                                ${DEMO.map(function (account) {
                                    return html`<div class="demo-row" data-email="${account.email}" data-password="${account.password}" role="button" tabindex="0">
                                        <span>${account.email}</span>
                                        <span class="demo-role">${account.role}</span>
                                    </div>`;
                                })}
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        `;

        const form = main.querySelector('#login-form');
        const errorBox = main.querySelector('#login-error');
        const submitBtn = main.querySelector('#login-submit');

        form.addEventListener('submit', async function (event) {
            event.preventDefault();

            const email = form.email.value.trim();
            const password = form.password.value;
            errorBox.hidden = true;

            if (!email || !password) {
                errorBox.textContent = 'Enter both your e-mail and password.';
                errorBox.hidden = false;
                return;
            }

            submitBtn.disabled = true;
            submitBtn.innerHTML = '<span class="spinner"></span> Signing in…';

            try {
                const result = await QA.api.login(email, password);
                QA.api.setCsrf(result.csrf_token);
                QA.api.setUser(result.user);
                if (global.QA.app) global.QA.app.onSignedIn(result.user);
            } catch (error) {
                errorBox.textContent = error.message;
                errorBox.hidden = false;
                submitBtn.disabled = false;
                submitBtn.textContent = 'Sign in';
            }
        });

        main.querySelectorAll('.demo-row').forEach(function (row) {
            const fill = function () {
                form.email.value = row.dataset.email;
                form.password.value = row.dataset.password;
                form.password.focus();
            };
            row.addEventListener('click', fill);
            row.addEventListener('keydown', function (event) {
                if (event.key === 'Enter' || event.key === ' ') {
                    event.preventDefault();
                    fill();
                }
            });
        });
    }

    QA.views = QA.views || {};
    QA.views.auth = { render: render };
})(window);
