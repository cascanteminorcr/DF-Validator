/* =====================================================================
   views/catalog.js — clients, campaigns and donation forms
   ===================================================================== */
(function (global) {
    'use strict';

    const QA = global.QA;
    const html = QA.html;
    const ui = QA.ui;

    let cache = null;

    async function render(main) {
        main.innerHTML = html`
            <div class="page-head">
                <div class="titles">
                    <div class="eyebrow">Reference data</div>
                    <h1>Client Catalogue</h1>
                    <div class="subtitle">Clients, campaigns and donation forms used to pre-fill QA executions.</div>
                </div>
                <div class="actions">
                    <button type="button" class="btn btn-sm" data-add="client">+ Client</button>
                    <button type="button" class="btn btn-sm" data-add="campaign">+ Campaign</button>
                    <button type="button" class="btn btn-primary btn-sm" data-add="form">+ Donation form</button>
                </div>
            </div>

            <div class="tabs" role="tablist">
                <button type="button" class="tab is-active" data-ctab="clients">Clients</button>
                <button type="button" class="tab" data-ctab="campaigns">Campaigns</button>
                <button type="button" class="tab" data-ctab="forms">Donation forms</button>
            </div>

            <div id="catalog-body"><div class="card"><div class="card-body"><div class="skeleton" style="height:220px"></div></div></div></div>
        `;

        main.querySelectorAll('[data-ctab]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                main.querySelectorAll('[data-ctab]').forEach(function (b) { b.classList.remove('is-active'); });
                btn.classList.add('is-active');
                paintTab(main, btn.dataset.ctab);
            });
        });

        main.querySelectorAll('[data-add]').forEach(function (btn) {
            btn.addEventListener('click', function () { openForm(btn.dataset.add, main); });
        });

        await reload(main);
        paintTab(main, 'clients');
    }

    async function reload(main) {
        try {
            cache = await QA.api.catalog();
        } catch (error) {
            ui.toast(error.message, 'error');
        }
    }

    function paintTab(main, tab) {
        const body = main.querySelector('#catalog-body');
        if (!body || !cache) return;

        if (tab === 'campaigns') return paintCampaigns(body, main);
        if (tab === 'forms') return paintForms(body, main);
        return paintClients(body, main);
    }

    function paintClients(body, main) {
        const rows = cache.clients || [];

        if (!rows.length) {
            body.innerHTML = emptyState('No clients yet', 'Add your first client to start building the catalogue.');
            return;
        }

        body.innerHTML = html`
            <div class="card">
                <div class="card-body tight">
                    <div class="table-wrap">
                        <table class="table">
                            <thead><tr><th>Client</th><th>Code</th><th>Account Manager</th><th>Campaigns</th><th>Status</th><th></th></tr></thead>
                            <tbody>
                                ${rows.map(function (row) {
                                    return html`<tr>
                                        <td class="cell-main">${row.name}</td>
                                        <td class="mono muted">${row.code || '—'}</td>
                                        <td class="muted">${row.am_name || '—'}</td>
                                        <td class="num">${row.campaign_count || 0}</td>
                                        <td>${row.is_active
                                            ? html`<span class="badge badge-pass">Active</span>`
                                            : html`<span class="badge badge-mute">Inactive</span>`}</td>
                                        <td class="actions-cell">
                                            <button type="button" class="btn btn-xs" data-edit-client="${row.id}">Edit</button>
                                        </td>
                                    </tr>`;
                                })}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;

        body.querySelectorAll('[data-edit-client]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                const client = rows.filter(function (c) { return String(c.id) === btn.dataset.editClient; })[0];
                openForm('client', main, client);
            });
        });
    }

    function paintCampaigns(body, main) {
        const rows = cache.campaigns || [];

        if (!rows.length) {
            body.innerHTML = emptyState('No campaigns yet', 'Campaigns group donation forms for a client.');
            return;
        }

        body.innerHTML = html`
            <div class="card">
                <div class="card-body tight">
                    <div class="table-wrap">
                        <table class="table">
                            <thead><tr><th>Campaign</th><th>Client</th><th>Code</th><th>Forms</th><th>Status</th><th></th></tr></thead>
                            <tbody>
                                ${rows.map(function (row) {
                                    return html`<tr>
                                        <td class="cell-main">${row.name}</td>
                                        <td class="muted">${row.client_name}</td>
                                        <td class="mono muted">${row.code || '—'}</td>
                                        <td class="num">${row.form_count || 0}</td>
                                        <td>${row.is_active
                                            ? html`<span class="badge badge-pass">Active</span>`
                                            : html`<span class="badge badge-mute">Inactive</span>`}</td>
                                        <td class="actions-cell">
                                            <button type="button" class="btn btn-xs" data-edit-campaign="${row.id}">Edit</button>
                                        </td>
                                    </tr>`;
                                })}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;

        body.querySelectorAll('[data-edit-campaign]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                const campaign = rows.filter(function (c) { return String(c.id) === btn.dataset.editCampaign; })[0];
                openForm('campaign', main, campaign);
            });
        });
    }

    function paintForms(body, main) {
        const rows = cache.forms || [];

        if (!rows.length) {
            body.innerHTML = emptyState('No donation forms yet', 'Saved forms let analysts start a QA run in two clicks.');
            return;
        }

        body.innerHTML = html`
            <div class="card">
                <div class="card-body tight">
                    <div class="table-wrap">
                        <table class="table">
                            <thead><tr><th>Donation form</th><th>Client / campaign</th><th>Environment</th><th>Appeal</th><th>URL</th><th></th></tr></thead>
                            <tbody>
                                ${rows.map(function (row) {
                                    return html`<tr>
                                        <td class="cell-main">${row.name}</td>
                                        <td class="muted">${row.client_name}<div class="cell-sub">${row.campaign_name}</div></td>
                                        <td>${ui.envBadge(row.environment)}</td>
                                        <td class="mono muted">${row.appeal_code || '—'}</td>
                                        <td class="muted truncate" style="max-width:260px" title="${row.url || ''}">${row.url || '—'}</td>
                                        <td class="actions-cell">
                                            <button type="button" class="btn btn-xs" data-edit-form="${row.id}">Edit</button>
                                        </td>
                                    </tr>`;
                                })}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;

        body.querySelectorAll('[data-edit-form]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                const form = rows.filter(function (f) { return String(f.id) === btn.dataset.editForm; })[0];
                openForm('form', main, form);
            });
        });
    }

    function emptyState(title, text) {
        return html`<div class="card"><div class="empty">
            <div class="empty-icon">◫</div><h3>${title}</h3><p>${text}</p>
        </div></div>`;
    }

    function openForm(kind, main, existing) {
        if (!cache) return;
        const isEdit = !!existing;

        const titles = { client: 'client', campaign: 'campaign', form: 'donation form' };
        let bodyHtml = '';

        if (kind === 'client') {
            bodyHtml = html`
                <div class="field">
                    <label for="cf-name">Client name <span class="req">*</span></label>
                    <input type="text" id="cf-name" value="${existing ? existing.name : ''}" maxlength="160" required>
                </div>
                <div class="field-row">
                    <div class="field">
                        <label for="cf-code">Client code</label>
                        <input type="text" id="cf-code" value="${existing ? existing.code || '' : ''}" maxlength="40" placeholder="NWR">
                    </div>
                    <div class="field">
                        <label for="cf-am">Account Manager</label>
                        <input type="text" id="cf-am" value="${existing ? existing.am_name || '' : ''}" maxlength="120">
                    </div>
                </div>
                ${isEdit ? html`<label class="checkbox-row">
                    <input type="checkbox" id="cf-active" ${existing.is_active ? ui.raw('checked') : ''}>
                    <span class="soft">Active</span>
                </label>` : ''}
            `;
        } else if (kind === 'campaign') {
            bodyHtml = html`
                <div class="field">
                    <label for="cf-client">Client <span class="req">*</span></label>
                    <select id="cf-client">
                        ${(cache.clients || []).map(function (c) {
                            const selected = existing ? Number(existing.client_id) === Number(c.id) : false;
                            return html`<option value="${c.id}" ${selected ? ui.raw('selected') : ''}>${c.name}</option>`;
                        })}
                    </select>
                </div>
                <div class="field">
                    <label for="cf-name">Campaign name <span class="req">*</span></label>
                    <input type="text" id="cf-name" value="${existing ? existing.name : ''}" maxlength="160" required>
                </div>
                <div class="field">
                    <label for="cf-code">Campaign code</label>
                    <input type="text" id="cf-code" value="${existing ? existing.code || '' : ''}" maxlength="60">
                </div>
                ${isEdit ? html`<label class="checkbox-row">
                    <input type="checkbox" id="cf-active" ${existing.is_active ? ui.raw('checked') : ''}>
                    <span class="soft">Active</span>
                </label>` : ''}
            `;
        } else {
            bodyHtml = html`
                <div class="field">
                    <label for="cf-campaign">Campaign <span class="req">*</span></label>
                    <select id="cf-campaign">
                        ${(cache.campaigns || []).map(function (c) {
                            const selected = existing ? Number(existing.campaign_id) === Number(c.id) : false;
                            return html`<option value="${c.id}" ${selected ? ui.raw('selected') : ''}>${c.client_name} · ${c.name}</option>`;
                        })}
                    </select>
                </div>
                <div class="field-row">
                    <div class="field">
                        <label for="cf-name">Form name <span class="req">*</span></label>
                        <input type="text" id="cf-name" value="${existing ? existing.name : ''}" maxlength="180" required>
                    </div>
                    <div class="field">
                        <label for="cf-env">Environment</label>
                        <select id="cf-env">
                            ${Object.keys(cache.environments || {}).map(function (key) {
                                const selected = existing ? existing.environment === key : key === 'staging';
                                return html`<option value="${key}" ${selected ? ui.raw('selected') : ''}>${cache.environments[key]}</option>`;
                            })}
                        </select>
                    </div>
                </div>
                <div class="field">
                    <label for="cf-url">Donation form URL</label>
                    <input type="url" id="cf-url" value="${existing ? existing.url || '' : ''}" maxlength="500">
                </div>
                <div class="field">
                    <label for="cf-template">Template URL</label>
                    <input type="url" id="cf-template" value="${existing ? existing.template_url || '' : ''}" maxlength="500">
                </div>
                <div class="field">
                    <label for="cf-appeal">Appeal code</label>
                    <input type="text" id="cf-appeal" value="${existing ? existing.appeal_code || '' : ''}" maxlength="80">
                </div>
                ${isEdit ? html`<label class="checkbox-row">
                    <input type="checkbox" id="cf-active" ${existing.is_active ? ui.raw('checked') : ''}>
                    <span class="soft">Active</span>
                </label>` : ''}
            `;
        }

        ui.modal({
            title: (isEdit ? 'Edit ' : 'New ') + titles[kind],
            body: bodyHtml,
            footer: html`
                <button type="button" class="btn" data-modal-close>Cancel</button>
                <button type="button" class="btn btn-primary" id="cf-save">${isEdit ? 'Save changes' : 'Create'}</button>
            `,
            onMount: function (root) {
                root.querySelector('#cf-save').addEventListener('click', async function (event) {
                    const btn = event.currentTarget;
                    const value = function (sel) { return root.querySelector(sel); };

                    btn.disabled = true;
                    btn.innerHTML = '<span class="spinner"></span> Saving…';

                    try {
                        if (kind === 'client') {
                            const payload = {
                                name: value('#cf-name').value.trim(),
                                code: value('#cf-code').value.trim(),
                                am_name: value('#cf-am').value.trim(),
                                is_active: isEdit ? value('#cf-active').checked : true
                            };
                            if (!payload.name) throw new Error('Client name is required.');
                            if (isEdit) await QA.api.updateClient(existing.id, payload);
                            else await QA.api.createClient(payload);
                        } else if (kind === 'campaign') {
                            const payload = {
                                client_id: Number(value('#cf-client').value),
                                name: value('#cf-name').value.trim(),
                                code: value('#cf-code').value.trim(),
                                is_active: isEdit ? value('#cf-active').checked : true
                            };
                            if (!payload.name) throw new Error('Campaign name is required.');
                            if (isEdit) await QA.api.updateCampaign(existing.id, payload);
                            else await QA.api.createCampaign(payload);
                        } else {
                            const payload = {
                                campaign_id: Number(value('#cf-campaign').value),
                                name: value('#cf-name').value.trim(),
                                environment: value('#cf-env').value,
                                url: value('#cf-url').value.trim(),
                                template_url: value('#cf-template').value.trim(),
                                appeal_code: value('#cf-appeal').value.trim(),
                                is_active: isEdit ? value('#cf-active').checked : true
                            };
                            if (!payload.name) throw new Error('Form name is required.');
                            if (isEdit) await QA.api.updateForm(existing.id, payload);
                            else await QA.api.createForm(payload);
                        }

                        ui.closeModal();
                        ui.toast(titles[kind] + ' saved.', 'success');
                        await reload(main);

                        const activeTab = main.querySelector('[data-ctab].is-active');
                        paintTab(main, activeTab ? activeTab.dataset.ctab
                            : kind === 'client' ? 'clients' : kind === 'campaign' ? 'campaigns' : 'forms');
                    } catch (error) {
                        ui.toast(error.message, 'error');
                        btn.disabled = false;
                        btn.textContent = isEdit ? 'Save changes' : 'Create';
                    }
                });
            }
        });
    }

    QA.views = QA.views || {};
    QA.views.catalog = { render: render };
})(window);
