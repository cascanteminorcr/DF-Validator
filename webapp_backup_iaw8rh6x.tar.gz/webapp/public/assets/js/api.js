/* =====================================================================
   api.js — Fetch API client
   Handles JSON encoding, CSRF headers, 401 redirects and error surfacing.
   ===================================================================== */
(function (global) {
    'use strict';

    const bootstrap = global.__QA_BOOTSTRAP__ || { user: null, csrf: '', meta: {} };

    const state = {
        user: bootstrap.user || null,
        csrf: bootstrap.csrf || '',
        meta: bootstrap.meta || {},
        permissions: { can_approve: false, can_manage_users: false, can_edit_all: false }
    };

    class ApiError extends Error {
        constructor(message, status, payload) {
            super(message);
            this.name = 'ApiError';
            this.status = status;
            this.payload = payload || {};
            this.fields = (payload && payload.fields) || null;
        }
    }

    /** Called by the app shell when a 401 comes back mid-session. */
    let onUnauthenticated = null;

    function setUnauthenticatedHandler(fn) {
        onUnauthenticated = fn;
    }

    function buildUrl(path, query) {
        if (!query) return path;
        const params = new URLSearchParams();
        Object.keys(query).forEach(function (key) {
            const value = query[key];
            if (value === undefined || value === null || value === '') return;
            params.append(key, value);
        });
        const qs = params.toString();
        return qs ? path + '?' + qs : path;
    }

    async function request(method, path, options) {
        options = options || {};

        const init = {
            method: method,
            credentials: 'same-origin',
            headers: Object.assign({ 'Accept': 'application/json' }, options.headers || {})
        };

        if (method !== 'GET' && method !== 'HEAD') {
            init.headers['X-CSRF-Token'] = state.csrf;
            init.headers['X-Requested-With'] = 'XMLHttpRequest';
        }

        if (options.body instanceof FormData) {
            init.body = options.body;
        } else if (options.body !== undefined) {
            init.headers['Content-Type'] = 'application/json';
            init.body = JSON.stringify(options.body);
        }

        let response;
        try {
            response = await fetch(buildUrl(path, options.query), init);
        } catch (error) {
            throw new ApiError('Network error — the server could not be reached.', 0, {});
        }

        let payload = null;
        const contentType = response.headers.get('content-type') || '';

        if (contentType.indexOf('application/json') !== -1) {
            try {
                payload = await response.json();
            } catch (error) {
                payload = null;
            }
        }

        if (response.status === 401) {
            state.user = null;
            if (typeof onUnauthenticated === 'function') onUnauthenticated();
            throw new ApiError((payload && payload.error) || 'Your session has expired. Please sign in again.', 401, payload);
        }

        if (!response.ok) {
            if (response.status === 419 && typeof onUnauthenticated === 'function') {
                // CSRF expired: refresh the shell so a new token is issued.
                onUnauthenticated(true);
            }
            const message = (payload && payload.error)
                || (response.status === 403 ? 'You do not have permission to do that.'
                    : response.status === 404 ? 'That record could not be found.'
                        : 'Request failed (' + response.status + ').');
            throw new ApiError(message, response.status, payload);
        }

        if (payload === null) {
            throw new ApiError('The server returned an unexpected response.', response.status, {});
        }

        if (payload.success === false) {
            throw new ApiError(payload.error || 'The request was rejected.', response.status, payload);
        }

        return payload.data !== undefined ? payload.data : payload;
    }

    const api = {
        state: state,
        setUnauthenticatedHandler: setUnauthenticatedHandler,

        get: function (path, query) {
            return request('GET', path, { query: query });
        },
        post: function (path, body, options) {
            return request('POST', path, Object.assign({ body: body }, options || {}));
        },
        put: function (path, body) {
            return request('PUT', path, { body: body });
        },
        del: function (path) {
            return request('DELETE', path, {});
        },
        upload: function (path, formData) {
            return request('POST', path, { body: formData });
        },

        // ---- domain helpers -------------------------------------------
        me: function () { return api.get('/api/auth/me'); },
        login: function (email, password) { return api.post('/api/auth/login', { email: email, password: password }); },
        logout: function () { return api.post('/api/auth/logout', {}); },

        dashboard: function () { return api.get('/api/dashboard'); },
        meta: function () { return api.get('/api/meta'); },
        catalog: function () { return api.get('/api/catalog'); },

        executions: function (query) { return api.get('/api/executions', query); },
        execution: function (id) { return api.get('/api/executions/' + id); },
        createExecution: function (body) { return api.post('/api/executions', body); },
        updateExecution: function (id, body) { return api.put('/api/executions/' + id, body); },
        duplicateExecution: function (id) { return api.post('/api/executions/' + id + '/duplicate', {}); },
        deleteExecution: function (id) { return api.del('/api/executions/' + id); },

        saveResult: function (id, itemKey, status, comment) {
            return api.post('/api/executions/' + id + '/results/' + encodeURIComponent(itemKey), {
                status: status, comment: comment
            });
        },
        autosave: function (id, draft) {
            return api.post('/api/executions/' + id + '/autosave', { draft: draft });
        },
        submitExecution: function (id) { return api.post('/api/executions/' + id + '/submit', {}); },
        setApproval: function (id, body) { return api.post('/api/executions/' + id + '/approval', body); },
        runAutomation: function (id, url) { return api.post('/api/executions/' + id + '/automation', { url: url }); },

        uploadEvidence: function (id, formData) { return api.upload('/api/executions/' + id + '/evidence', formData); },
        deleteEvidence: function (fileId) { return api.del('/api/evidence/' + fileId); },

        generateReport: function (id) { return api.post('/api/executions/' + id + '/report', {}); },
        pdfUrl: function (id) { return '/api/executions/' + id + '/report/pdf'; },
        csvUrl: function (id) { return '/api/executions/' + id + '/export/csv'; },

        users: function () { return api.get('/api/users'); },
        createUser: function (body) { return api.post('/api/users', body); },
        updateUser: function (id, body) { return api.put('/api/users/' + id, body); },
        deleteUser: function (id) { return api.del('/api/users/' + id); },

        createClient: function (body) { return api.post('/api/clients', body); },
        updateClient: function (id, body) { return api.put('/api/clients/' + id, body); },
        createCampaign: function (body) { return api.post('/api/campaigns', body); },
        updateCampaign: function (id, body) { return api.put('/api/campaigns/' + id, body); },
        createForm: function (body) { return api.post('/api/forms', body); },
        updateForm: function (id, body) { return api.put('/api/forms/' + id, body); },

        setCsrf: function (token) { state.csrf = token || ''; },
        setUser: function (user) { state.user = user; }
    };

    global.QA = global.QA || {};
    global.QA.api = api;
    global.QA.ApiError = ApiError;
})(window);
