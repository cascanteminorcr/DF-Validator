/* =====================================================================
   app.js — hash router, session bootstrap, shell wiring
   ===================================================================== */
(function (global) {
    'use strict';

    const QA = global.QA;
    const api = QA.api;
    const ui = QA.ui;
    const html = QA.html;

    const ROUTES = [
        { pattern: /^\/dashboard$/, view: 'dashboard', title: 'Dashboard' },
        { pattern: /^\/executions$/, view: 'executions', title: 'Executions' },
        { pattern: /^\/executions\/new$/, view: 'executions.new', title: 'New QA Run' },
        { pattern: /^\/executions\/(\d+)\/print$/, view: 'print', title: 'Print Report' },
        { pattern: /^\/executions\/(\d+)$/, view: 'executionDetail', title: 'Execution' },
        { pattern: /^\/catalog$/, view: 'catalog', title: 'Client Catalogue' },
        { pattern: /^\/users$/, view: 'users', title: 'Users' }
    ];

    const NAV_FOR_VIEW = {
        dashboard: 'dashboard',
        executions: 'executions',
        'executions.new': 'new',
        executionDetail: 'executions',
        print: 'executions',
        catalog: 'catalog',
        users: 'users'
    };

    let currentUser = null;

    /* =================================================================
       Boot
       ================================================================= */

    async function boot() {
        const loading = document.getElementById('app-loading');
        const shell = document.getElementById('app');

        api.setUnauthenticatedHandler(function () {
            currentUser = null;
            showAuth();
        });

        document.getElementById('logout-btn').addEventListener('click', doLogout);
        document.getElementById('topbar-new').addEventListener('click', function () {
            global.location.hash = '#/executions/new';
        });
        document.getElementById('sidebar-toggle').addEventListener('click', function (event) {
            const sidebar = document.getElementById('sidebar');
            const open = sidebar.classList.toggle('is-open');
            event.currentTarget.setAttribute('aria-expanded', open ? 'true' : 'false');
        });

        global.addEventListener('hashchange', route);

        try {
            const session = await api.me();
            api.setCsrf(session.csrf_token);
            api.state.permissions = session.permissions || {};

            if (!session.user) {
                // Anonymous: show the sign-in screen (token already stored).
                showAuth();
                if (loading) loading.hidden = true;
                return;
            }

            currentUser = session.user;
            afterSignIn(shell, loading);
        } catch (error) {
            showAuth();
            if (loading) loading.hidden = true;
        }
    }

    function afterSignIn(shell, loading) {
        if (loading) loading.hidden = true;
        shell.hidden = false;
        renderSidebarUser();
        if (!global.location.hash || global.location.hash === '#/') {
            global.location.hash = '#/dashboard';
        }
        route();
    }

    function renderSidebarUser() {
        const slot = document.getElementById('sidebar-user');
        if (!slot || !currentUser) return;

        slot.innerHTML = html`
            <span class="avatar">${ui.initials(currentUser.name)}</span>
            <div class="sidebar-user-meta">
                <strong>${currentUser.name}</strong>
                <span>${ui.titleCase(currentUser.role)}</span>
            </div>
        `;

        const usersNav = document.getElementById('nav-users');
        if (usersNav) usersNav.hidden = !(api.state.permissions && api.state.permissions.can_manage_users);
    }

    function showAuth() {
        const shell = document.getElementById('app');
        const loading = document.getElementById('app-loading');
        const main = document.getElementById('main-content');

        if (shell) shell.hidden = true;
        if (loading) loading.hidden = true;

        // Render the auth screen into the body-level host.
        if (!document.getElementById('auth-host')) {
            const host = document.createElement('div');
            host.id = 'auth-host';
            document.body.appendChild(host);
        }

        const host = document.getElementById('auth-host');
        host.hidden = false;
        QA.views.auth.render(host);

        if (main) main.innerHTML = '';
    }

    function onSignedIn(user) {
        currentUser = user;

        const host = document.getElementById('auth-host');
        if (host) { host.hidden = true; host.innerHTML = ''; }

        const shell = document.getElementById('app');
        shell.hidden = false;

        api.me().then(function (session) {
            api.state.permissions = session.permissions || {};
            renderSidebarUser();
            global.location.hash = '#/dashboard';
            route();
        }).catch(function () {
            renderSidebarUser();
            global.location.hash = '#/dashboard';
            route();
        });

        ui.toast('Signed in as ' + user.name + '.', 'success', 'Welcome back');
    }

    async function doLogout() {
        try {
            await api.logout();
        } catch (error) { /* best effort */ }

        currentUser = null;
        ui.closeModal();
        showAuth();

        const host = document.getElementById('auth-host');
        if (host) QA.views.auth.render(host);
    }

    /* =================================================================
       Routing
       ================================================================= */

    function parseHash() {
        const raw = (global.location.hash || '#/dashboard').replace(/^#/, '');
        const [pathPart, queryPart] = raw.split('?');
        const query = {};

        if (queryPart) {
            new URLSearchParams(queryPart).forEach(function (value, key) { query[key] = value; });
        }

        return { path: pathPart || '/dashboard', query: query };
    }

    async function route() {
        if (!currentUser) return;

        const { path, query } = parseHash();
        const main = document.getElementById('main-content');
        if (!main) return;

        let matched = null;
        let params = {};

        for (let i = 0; i < ROUTES.length; i++) {
            const match = path.match(ROUTES[i].pattern);
            if (match) {
                matched = ROUTES[i];
                if (match[1]) params.id = match[1];
                break;
            }
        }

        if (!matched) {
            main.innerHTML = html`<div class="card"><div class="empty">
                <div class="empty-icon">?</div>
                <h3>Page not found</h3>
                <p>The page “${path}” does not exist.</p>
                <a class="btn btn-sm btn-primary" href="#/dashboard">Go to dashboard</a>
            </div></div>`;
            return;
        }

        params = Object.assign(params, query);

        // Update nav highlight and title.
        const navKey = NAV_FOR_VIEW[matched.view];
        document.querySelectorAll('.nav-link').forEach(function (link) {
            link.classList.toggle('is-active', link.dataset.nav === navKey);
        });

        const titleEl = document.getElementById('topbar-title');
        if (titleEl) titleEl.textContent = matched.title;
        document.title = matched.title + ' · Donation Form QA Validator';

        // Close the mobile drawer after navigation.
        const sidebar = document.getElementById('sidebar');
        if (sidebar && sidebar.classList.contains('is-open') && global.innerWidth <= 940) {
            sidebar.classList.remove('is-open');
        }

        const view = matched.view.split('.');
        const renderer = view.length === 2 ? QA.views[view[0]][view[1]] : QA.views[view[0]];

        if (!renderer || typeof renderer.render !== 'function') {
            main.innerHTML = html`<div class="card"><div class="empty"><h3>View unavailable</h3></div></div>`;
            return;
        }

        try {
            await renderer.render(main, params);
        } catch (error) {
            console.error('[DFQA] render failed', error);
            main.innerHTML = html`<div class="card"><div class="empty">
                <div class="empty-icon">⚠</div>
                <h3>Something went wrong</h3>
                <p>${error && error.message ? error.message : 'Unexpected error.'}</p>
                <button type="button" class="btn btn-sm" onclick="location.reload()">Reload</button>
            </div></div>`;
        }
    }

    /* =================================================================
       Global keyboard shortcuts
       ================================================================= */

    document.addEventListener('keydown', function (event) {
        if (!currentUser) return;

        // "n" for a new run when not typing in a field.
        const tag = (event.target.tagName || '').toLowerCase();
        if (tag === 'input' || tag === 'textarea' || tag === 'select' || event.metaKey || event.ctrlKey) return;

        if (event.key === 'n') {
            event.preventDefault();
            global.location.hash = '#/executions/new';
        }
    });

    QA.app = { boot: boot, onSignedIn: onSignedIn, route: route };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})(window);
