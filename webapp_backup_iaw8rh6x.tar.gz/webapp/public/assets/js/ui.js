/* =====================================================================
   ui.js — shared UI primitives
   Safe DOM construction, toasts, modals, formatting, debounce.
   ===================================================================== */
(function (global) {
    'use strict';

    const QA = global.QA = global.QA || {};

    /* ---------------- escaping & safe HTML ---------------- */

    const ESCAPE_MAP = {
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;', '`': '&#96;'
    };

    function esc(value) {
        if (value === null || value === undefined) return '';
        return String(value).replace(/[&<>"'`]/g, function (ch) { return ESCAPE_MAP[ch]; });
    }

    /** Tagged template that auto-escapes interpolations. */
    function html(strings) {
        const values = Array.prototype.slice.call(arguments, 1);
        let output = strings[0];
        for (let i = 0; i < values.length; i++) {
            const value = values[i];
            output += (value && value.__raw !== undefined ? value.__raw : esc(value));
            output += strings[i + 1];
        }
        return output;
    }

    /** Mark a string as pre-sanitised markup. */
    function raw(markup) {
        return { __raw: String(markup) };
    }

    /* ---------------- formatting ---------------- */

    function fmtDate(value, withTime) {
        if (!value) return '—';
        const normalised = String(value).replace(' ', 'T');
        const date = new Date(normalised);
        if (isNaN(date.getTime())) return String(value);
        const opts = withTime
            ? { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }
            : { day: '2-digit', month: 'short', year: 'numeric' };
        return date.toLocaleDateString('en-GB', opts);
    }

    function relTime(value) {
        if (!value) return '—';
        const date = new Date(String(value).replace(' ', 'T'));
        if (isNaN(date.getTime())) return String(value);
        const diff = Math.round((Date.now() - date.getTime()) / 1000);
        if (diff < 60) return 'just now';
        if (diff < 3600) return Math.floor(diff / 60) + 'm ago';
        if (diff < 86400) return Math.floor(diff / 3600) + 'h ago';
        if (diff < 604800) return Math.floor(diff / 86400) + 'd ago';
        return fmtDate(value);
    }

    function pct(value) {
        const n = Number(value) || 0;
        return (Math.round(n * 10) / 10) + '%';
    }

    function bytes(n) {
        n = Number(n) || 0;
        if (n >= 1048576) return (n / 1048576).toFixed(1) + ' MB';
        if (n >= 1024) return Math.round(n / 1024) + ' KB';
        return n + ' B';
    }

    function initials(name) {
        return String(name || '?')
            .split(/\s+/).filter(Boolean).slice(0, 2)
            .map(function (part) { return part[0].toUpperCase(); })
            .join('') || '?';
    }

    function titleCase(value) {
        return String(value || '')
            .replace(/[_-]+/g, ' ')
            .replace(/\b\w/g, function (c) { return c.toUpperCase(); });
    }

    /* ---------------- badges ---------------- */

    const STATUS_BADGE = {
        pass: 'badge-pass', fail: 'badge-fail', na: 'badge-na', untested: 'badge-mute'
    };

    const EXEC_BADGE = {
        draft: 'badge-mute', in_progress: 'badge-info', submitted: 'badge-accent',
        approved: 'badge-pass', rejected: 'badge-fail'
    };

    const ENV_BADGE = { production: 'badge-fail', staging: 'badge-warn', test: 'badge-info' };

    function statusBadge(status) {
        const label = status === 'untested' ? 'Open' : String(status).toUpperCase();
        return html`<span class="badge ${STATUS_BADGE[status] || 'badge-mute'}">${label}</span>`;
    }

    function execBadge(status) {
        return html`<span class="badge ${EXEC_BADGE[status] || 'badge-mute'}">${titleCase(status)}</span>`;
    }

    function envBadge(env) {
        return html`<span class="badge ${ENV_BADGE[env] || 'badge-mute'}">${titleCase(env)}</span>`;
    }

    /* ---------------- toasts ---------------- */

    const TOAST_ICON = { success: '✓', error: '✕', warn: '!', info: 'i' };

    function toast(message, type, title) {
        const stack = document.getElementById('toast-stack');
        if (!stack) return;

        type = type || 'info';
        const el = document.createElement('div');
        el.className = 'toast toast-' + type;
        el.setAttribute('role', type === 'error' ? 'alert' : 'status');
        el.innerHTML = html`
            <span class="toast-icon" aria-hidden="true">${TOAST_ICON[type] || 'i'}</span>
            <div class="toast-body">
                ${title ? html`<div class="toast-title">${title}</div>` : ''}
                <div class="toast-msg">${message}</div>
            </div>
            <button type="button" class="toast-close" aria-label="Dismiss notification">×</button>
        `;

        const remove = function () {
            el.classList.add('is-leaving');
            setTimeout(function () { el.remove(); }, 180);
        };

        el.querySelector('.toast-close').addEventListener('click', remove);
        stack.appendChild(el);

        const ttl = type === 'error' ? 7000 : 4200;
        setTimeout(remove, ttl);
    }

    /* ---------------- overlay ---------------- */

    let overlayCount = 0;

    function busy(text) {
        const overlay = document.getElementById('overlay');
        const label = document.getElementById('overlay-text');
        if (!overlay) return;
        overlayCount++;
        if (label) label.textContent = text || 'Working…';
        overlay.hidden = false;
    }

    function idle() {
        const overlay = document.getElementById('overlay');
        if (!overlay) return;
        overlayCount = Math.max(0, overlayCount - 1);
        if (overlayCount === 0) overlay.hidden = true;
    }

    /* ---------------- modal ---------------- */

    let activeModal = null;

    function closeModal() {
        const root = document.getElementById('modal-root');
        if (!root) return;
        root.innerHTML = '';
        activeModal = null;
        document.body.style.removeProperty('overflow');
        document.removeEventListener('keydown', onModalKeydown);
    }

    function onModalKeydown(event) {
        if (event.key === 'Escape') closeModal();
    }

    /**
     * options: { title, subtitle, body (html string), footer (html string),
     *            size: 'narrow'|'wide', onMount(rootEl), onSubmit, submitLabel }
     */
    function modal(options) {
        const root = document.getElementById('modal-root');
        if (!root) return null;

        const sizeClass = options.size === 'wide' ? 'modal-wide'
            : options.size === 'narrow' ? 'modal-narrow' : '';

        root.innerHTML = html`
            <div class="modal-backdrop" data-modal-backdrop>
                <div class="modal ${sizeClass}" role="dialog" aria-modal="true" aria-label="${options.title || 'Dialog'}">
                    <header class="modal-head">
                        <div>
                            <h2>${options.title || ''}</h2>
                            ${options.subtitle ? html`<div class="modal-sub">${options.subtitle}</div>` : ''}
                        </div>
                        <button type="button" class="icon-btn" data-modal-close aria-label="Close dialog">×</button>
                    </header>
                    <div class="modal-body" data-modal-body>${raw(options.body || '')}</div>
                    ${options.footer !== null ? html`
                        <footer class="modal-foot" data-modal-foot>${raw(options.footer || '')}</footer>
                    ` : ''}
                </div>
            </div>
        `;

        document.body.style.overflow = 'hidden';
        document.addEventListener('keydown', onModalKeydown);

        const backdrop = root.querySelector('[data-modal-backdrop]');
        backdrop.addEventListener('mousedown', function (event) {
            if (event.target === backdrop) closeModal();
        });
        root.querySelectorAll('[data-modal-close]').forEach(function (btn) {
            btn.addEventListener('click', closeModal);
        });

        activeModal = root.querySelector('.modal');

        if (typeof options.onMount === 'function') {
            options.onMount(activeModal);
        }

        // Focus the first interactive control for keyboard users.
        const focusTarget = activeModal.querySelector('[autofocus], input, select, textarea, button');
        if (focusTarget) setTimeout(function () { focusTarget.focus(); }, 30);

        return activeModal;
    }

    function confirmDialog(opts) {
        return new Promise(function (resolve) {
            const el = modal({
                title: opts.title || 'Confirm',
                size: 'narrow',
                body: html`<p class="mb-0 soft">${opts.message || 'Are you sure?'}</p>`,
                footer: html`
                    <button type="button" class="btn" data-modal-close>Cancel</button>
                    <button type="button" class="btn ${opts.danger ? 'btn-danger' : 'btn-primary'}" data-confirm>${opts.confirmLabel || 'Confirm'}</button>
                `,
                onMount: function (root) {
                    root.querySelector('[data-confirm]').addEventListener('click', function () {
                        closeModal();
                        resolve(true);
                    });
                    root.querySelectorAll('[data-modal-close]').forEach(function (b) {
                        b.addEventListener('click', function () { resolve(false); });
                    });
                }
            });
            if (!el) resolve(false);
        });
    }

    /* ---------------- misc helpers ---------------- */

    function debounce(fn, wait) {
        let timer = null;
        return function () {
            const args = arguments;
            const self = this;
            clearTimeout(timer);
            timer = setTimeout(function () { fn.apply(self, args); }, wait);
        };
    }

    function el(tag, attrs, children) {
        const node = document.createElement(tag);
        if (attrs) {
            Object.keys(attrs).forEach(function (key) {
                if (key === 'class') node.className = attrs[key];
                else if (key === 'text') node.textContent = attrs[key];
                else if (key.indexOf('on') === 0 && typeof attrs[key] === 'function') {
                    node.addEventListener(key.slice(2).toLowerCase(), attrs[key]);
                } else if (attrs[key] !== null && attrs[key] !== undefined) {
                    node.setAttribute(key, attrs[key]);
                }
            });
        }
        (children || []).forEach(function (child) {
            node.appendChild(typeof child === 'string' ? document.createTextNode(child) : child);
        });
        return node;
    }

    function progressBar(pass, fail, na, total) {
        total = total || (pass + fail + na) || 1;
        const p = (pass / total) * 100;
        const f = (fail / total) * 100;
        const n = (na / total) * 100;
        return html`<div class="progress" title="${pass} pass / ${fail} fail / ${na} n/a">
            <span class="seg-pass" style="width:${p.toFixed(2)}%"></span>
            <span class="seg-fail" style="width:${f.toFixed(2)}%"></span>
            <span class="seg-na" style="width:${n.toFixed(2)}%"></span>
        </div>`;
    }

    function rateClass(rate) {
        if (rate >= 95) return '';
        if (rate >= 75) return 'is-mid';
        return 'is-low';
    }

    QA.ui = {
        esc: esc,
        html: html,
        raw: raw,
        fmtDate: fmtDate,
        relTime: relTime,
        pct: pct,
        bytes: bytes,
        initials: initials,
        titleCase: titleCase,
        statusBadge: statusBadge,
        execBadge: execBadge,
        envBadge: envBadge,
        toast: toast,
        busy: busy,
        idle: idle,
        modal: modal,
        closeModal: closeModal,
        confirm: confirmDialog,
        debounce: debounce,
        el: el,
        progressBar: progressBar,
        rateClass: rateClass
    };

    // Convenience shorthands.
    QA.html = html;
    QA.esc = esc;
    QA.toast = toast;
})(window);
