<?php
/**
 * Router for PHP's built-in web server (development only).
 *
 *   php -S 0.0.0.0:3000 -t public public/router.php
 *
 * On Apache/Nginx you do NOT need this file — see docs/INSTALL.md for
 * the rewrite rules that produce the same routing.
 */

$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) ?: '/';

// Serve real static assets directly.
$file = __DIR__ . $uri;

if ($uri !== '/' && is_file($file) && !str_ends_with($uri, '.php')) {
    return false;
}

// API requests all funnel through the API front controller.
if (str_starts_with($uri, '/api/') || $uri === '/api') {
    $_SERVER['SCRIPT_NAME'] = '/api/index.php';
    require __DIR__ . '/api/index.php';

    return true;
}

// Everything else is the SPA shell.
$_SERVER['SCRIPT_NAME'] = '/index.php';
require __DIR__ . '/index.php';

return true;
