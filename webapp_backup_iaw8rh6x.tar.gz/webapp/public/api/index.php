<?php

declare(strict_types=1);

/**
 * API front controller.
 *
 * Every endpoint returns JSON. Authentication is session-based; state-changing
 * requests additionally require the X-CSRF-Token header (see App\Core\Csrf).
 */

use App\Controllers\Api\AuthController;
use App\Controllers\Api\CatalogController;
use App\Controllers\Api\DashboardController;
use App\Controllers\Api\EvidenceController;
use App\Controllers\Api\ExecutionController;
use App\Controllers\Api\ReportController;
use App\Core\Auth;
use App\Core\Csrf;
use App\Core\Request;
use App\Core\Response;
use App\Core\Router;

require_once __DIR__ . '/../../app/bootstrap.php';

$router = new Router();

// ---------------------------------------------------------------------
// Middleware
// ---------------------------------------------------------------------

$auth = static fn (): null => null;
$requireAuth = static function (): void {
    Auth::requireAuth();
};

$csrf = static function (): void {
    Csrf::requireValid();
};

$protected = [$requireAuth];

// ---------------------------------------------------------------------
// Public endpoints
// ---------------------------------------------------------------------

$router->get('/api/health', static function (): void {
    Response::ok(['status' => 'ok', 'time' => date('c'), 'version' => '1.0.0']);
});

$router->post('/api/auth/login', static function () use ($csrf): void {
    $csrf();
    (new AuthController())->login();
}, [$csrf]);

$router->get('/api/auth/me', static function (): void {
    (new AuthController())->me();
});

$router->post('/api/auth/logout', static function (): void {
    (new AuthController())->logout();
}, [$csrf]);

// ---------------------------------------------------------------------
// Dashboard
// ---------------------------------------------------------------------

$router->get('/api/dashboard', static function (): void {
    (new DashboardController())->index();
}, $protected);

// ---------------------------------------------------------------------
// Catalogue (clients / campaigns / forms)
// ---------------------------------------------------------------------

$router->get('/api/catalog', static function (): void {
    (new CatalogController())->index();
}, $protected);

$router->post('/api/clients', static function (): void {
    (new CatalogController())->createClient();
}, array_merge($protected, [$csrf]));

$router->put('/api/clients/{id}', static function (array $p): void {
    (new CatalogController())->updateClient($p);
}, array_merge($protected, [$csrf]));

$router->post('/api/campaigns', static function (): void {
    (new CatalogController())->createCampaign();
}, array_merge($protected, [$csrf]));

$router->put('/api/campaigns/{id}', static function (array $p): void {
    (new CatalogController())->updateCampaign($p);
}, array_merge($protected, [$csrf]));

$router->post('/api/forms', static function (): void {
    (new CatalogController())->createForm();
}, array_merge($protected, [$csrf]));

$router->put('/api/forms/{id}', static function (array $p): void {
    (new CatalogController())->updateForm($p);
}, array_merge($protected, [$csrf]));

// ---------------------------------------------------------------------
// Users (admin)
// ---------------------------------------------------------------------

$router->get('/api/users', static function (): void {
    (new AuthController())->users();
}, $protected);

$router->post('/api/users', static function (): void {
    (new AuthController())->createUser();
}, array_merge($protected, [$csrf]));

$router->put('/api/users/{id}', static function (array $p): void {
    (new AuthController())->updateUser($p);
}, array_merge($protected, [$csrf]));

$router->delete('/api/users/{id}', static function (array $p): void {
    (new AuthController())->deleteUser($p);
}, array_merge($protected, [$csrf]));

// ---------------------------------------------------------------------
// Executions
// ---------------------------------------------------------------------

$router->get('/api/meta', static function (): void {
    (new ExecutionController())->meta();
}, $protected);

$router->get('/api/executions', static function (): void {
    (new ExecutionController())->index();
}, $protected);

$router->post('/api/executions', static function (): void {
    (new ExecutionController())->store();
}, array_merge($protected, [$csrf]));

$router->get('/api/executions/{id}', static function (array $p): void {
    (new ExecutionController())->show($p);
}, $protected);

$router->put('/api/executions/{id}', static function (array $p): void {
    (new ExecutionController())->update($p);
}, array_merge($protected, [$csrf]));

$router->delete('/api/executions/{id}', static function (array $p): void {
    (new ExecutionController())->destroy($p);
}, array_merge($protected, [$csrf]));

$router->post('/api/executions/{id}/duplicate', static function (array $p): void {
    (new ExecutionController())->duplicate($p);
}, array_merge($protected, [$csrf]));

$router->post('/api/executions/{id}/automation', static function (array $p): void {
    (new ExecutionController())->runAutomation($p);
}, array_merge($protected, [$csrf]));

$router->get('/api/executions/{id}/automation', static function (array $p): void {
    (new ExecutionController())->show($p);
}, $protected);

// Checklist results
$router->post('/api/executions/{id}/results/{item}', static function (array $p): void {
    (new ExecutionController())->saveResult($p);
}, array_merge($protected, [$csrf]));

$router->post('/api/executions/{id}/results', static function (array $p): void {
    (new ExecutionController())->bulkSaveResults($p);
}, array_merge($protected, [$csrf]));

$router->post('/api/executions/{id}/autosave', static function (array $p): void {
    (new ExecutionController())->autosave($p);
}, array_merge($protected, [$csrf]));

// Workflow
$router->post('/api/executions/{id}/submit', static function (array $p): void {
    (new ExecutionController())->submit($p);
}, array_merge($protected, [$csrf]));

$router->post('/api/executions/{id}/approval', static function (array $p): void {
    (new ExecutionController())->approval($p);
}, array_merge($protected, [$csrf]));

// ---------------------------------------------------------------------
// Evidence
// ---------------------------------------------------------------------

$router->post('/api/executions/{id}/evidence', static function (array $p): void {
    (new EvidenceController())->upload($p);
}, array_merge($protected, [$csrf]));

$router->get('/api/evidence/{id}/download', static function (array $p): void {
    (new EvidenceController())->download($p);
}, $protected);

$router->get('/api/evidence/{id}/preview', static function (array $p): void {
    (new EvidenceController())->preview($p);
}, $protected);

$router->delete('/api/evidence/{id}', static function (array $p): void {
    (new EvidenceController())->destroy($p);
}, array_merge($protected, [$csrf]));

// ---------------------------------------------------------------------
// Reports
// ---------------------------------------------------------------------

$router->post('/api/executions/{id}/report', static function (array $p): void {
    (new ReportController())->generatePdf($p);
}, array_merge($protected, [$csrf]));

$router->get('/api/executions/{id}/report/pdf', static function (array $p): void {
    (new ReportController())->streamPdf($p);
}, $protected);

$router->get('/api/executions/{id}/export/csv', static function (array $p): void {
    (new ReportController())->exportCsv($p);
}, $protected);

$router->get('/api/reports/{id}/download', static function (array $p): void {
    (new ReportController())->download($p);
}, $protected);

$router->delete('/api/reports/{id}', static function (array $p): void {
    (new ReportController())->destroy($p);
}, array_merge($protected, [$csrf]));

// ---------------------------------------------------------------------
// Dispatch
// ---------------------------------------------------------------------

$router->dispatch(Request::method(), Request::path());
