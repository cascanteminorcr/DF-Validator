-- =====================================================================
-- Donation Form QA Validator — Database Schema
-- MySQL 8.0+ / MariaDB 10.6+
-- =====================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ---------------------------------------------------------------------
-- users
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
  id             INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name           VARCHAR(120) NOT NULL,
  email          VARCHAR(190) NOT NULL,
  password_hash  VARCHAR(255) NOT NULL,
  role           ENUM('admin','qa_lead','qa_analyst') NOT NULL DEFAULT 'qa_analyst',
  is_active      TINYINT(1) NOT NULL DEFAULT 1,
  last_login_at  DATETIME NULL,
  created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_email (email),
  KEY idx_users_role (role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- clients
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS clients (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name        VARCHAR(160) NOT NULL,
  code        VARCHAR(40) NULL,
  am_name     VARCHAR(120) NULL,
  is_active   TINYINT(1) NOT NULL DEFAULT 1,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_clients_name (name),
  KEY idx_clients_code (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- campaigns
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS campaigns (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  client_id   INT UNSIGNED NOT NULL,
  name        VARCHAR(160) NOT NULL,
  code        VARCHAR(60) NULL,
  is_active   TINYINT(1) NOT NULL DEFAULT 1,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_campaigns_client_name (client_id, name),
  KEY idx_campaigns_client (client_id),
  CONSTRAINT fk_campaigns_client FOREIGN KEY (client_id)
    REFERENCES clients (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- donation_forms
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS donation_forms (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  campaign_id   INT UNSIGNED NOT NULL,
  name          VARCHAR(180) NOT NULL,
  environment   ENUM('production','staging','test') NOT NULL DEFAULT 'staging',
  url           VARCHAR(500) NULL,
  template_url  VARCHAR(500) NULL,
  appeal_code   VARCHAR(80) NULL,
  is_active     TINYINT(1) NOT NULL DEFAULT 1,
  created_by    INT UNSIGNED NULL,
  created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_forms_campaign_name (campaign_id, name),
  KEY idx_forms_campaign (campaign_id),
  KEY idx_forms_env (environment),
  CONSTRAINT fk_forms_campaign FOREIGN KEY (campaign_id)
    REFERENCES campaigns (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_forms_created_by FOREIGN KEY (created_by)
    REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- test_executions
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS test_executions (
  id                INT UNSIGNED NOT NULL AUTO_INCREMENT,
  form_id           INT UNSIGNED NULL,
  client_name       VARCHAR(160) NOT NULL,
  campaign_name     VARCHAR(160) NOT NULL,
  form_name         VARCHAR(180) NOT NULL,
  environment       ENUM('production','staging','test') NOT NULL DEFAULT 'staging',
  form_url          VARCHAR(500) NOT NULL,
  template_url      VARCHAR(500) NULL,
  qa_analyst_id     INT UNSIGNED NULL,
  qa_analyst_name   VARCHAR(120) NOT NULL,
  build_timestamp   DATETIME NULL,
  browser_used      VARCHAR(80) NULL,
  test_date         DATE NULL,
  status            ENUM('draft','in_progress','submitted','approved','rejected') NOT NULL DEFAULT 'draft',
  total_items       INT UNSIGNED NOT NULL DEFAULT 0,
  pass_count        INT UNSIGNED NOT NULL DEFAULT 0,
  fail_count        INT UNSIGNED NOT NULL DEFAULT 0,
  na_count          INT UNSIGNED NOT NULL DEFAULT 0,
  untested_count    INT UNSIGNED NOT NULL DEFAULT 0,
  pass_rate         DECIMAL(5,2) NOT NULL DEFAULT 0.00,
  auto_results      JSON NULL,
  am_name           VARCHAR(120) NULL,
  approval_message  TEXT NULL,
  qa_notes          TEXT NULL,
  approval_status   ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  approved_at       DATETIME NULL,
  approved_by       INT UNSIGNED NULL,
  submitted_at      DATETIME NULL,
  created_by        INT UNSIGNED NULL,
  created_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_exec_status (status),
  KEY idx_exec_created (created_at),
  KEY idx_exec_form (form_id),
  KEY idx_exec_analyst (qa_analyst_id),
  KEY idx_exec_env (environment),
  CONSTRAINT fk_exec_form FOREIGN KEY (form_id)
    REFERENCES donation_forms (id) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT fk_exec_analyst FOREIGN KEY (qa_analyst_id)
    REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT fk_exec_approved_by FOREIGN KEY (approved_by)
    REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT fk_exec_created_by FOREIGN KEY (created_by)
    REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- test_results
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS test_results (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  execution_id  INT UNSIGNED NOT NULL,
  section       ENUM('creative','functional') NOT NULL,
  item_key      VARCHAR(80) NOT NULL,
  item_label    VARCHAR(255) NOT NULL,
  status        ENUM('pass','fail','na','untested') NOT NULL DEFAULT 'untested',
  comment       TEXT NULL,
  sort_order    SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  updated_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_result_exec_item (execution_id, item_key),
  KEY idx_result_exec (execution_id),
  KEY idx_result_status (status),
  CONSTRAINT fk_result_exec FOREIGN KEY (execution_id)
    REFERENCES test_executions (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- evidence_files
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS evidence_files (
  id             INT UNSIGNED NOT NULL AUTO_INCREMENT,
  execution_id   INT UNSIGNED NOT NULL,
  result_id      INT UNSIGNED NULL,
  category       ENUM('screenshot','attachment','creative','approval','other') NOT NULL DEFAULT 'screenshot',
  original_name  VARCHAR(255) NOT NULL,
  stored_name    VARCHAR(255) NOT NULL,
  mime_type      VARCHAR(120) NOT NULL,
  extension      VARCHAR(12) NOT NULL,
  file_size      INT UNSIGNED NOT NULL DEFAULT 0,
  uploaded_by    INT UNSIGNED NULL,
  created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_evidence_exec (execution_id),
  KEY idx_evidence_result (result_id),
  CONSTRAINT fk_evidence_exec FOREIGN KEY (execution_id)
    REFERENCES test_executions (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_evidence_result FOREIGN KEY (result_id)
    REFERENCES test_results (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_evidence_user FOREIGN KEY (uploaded_by)
    REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- reports
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS reports (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  execution_id  INT UNSIGNED NOT NULL,
  report_type   ENUM('pdf','csv') NOT NULL DEFAULT 'pdf',
  file_name     VARCHAR(255) NOT NULL,
  file_path     VARCHAR(500) NOT NULL,
  file_size     INT UNSIGNED NOT NULL DEFAULT 0,
  generated_by  INT UNSIGNED NULL,
  created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_reports_exec (execution_id),
  CONSTRAINT fk_reports_exec FOREIGN KEY (execution_id)
    REFERENCES test_executions (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_reports_user FOREIGN KEY (generated_by)
    REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
