-- =====================================================================
-- Demo seed data for Donation Form QA Validator
-- Default password for every demo account: QaValidator!2024
-- (Change immediately after first login in any real deployment.)
-- =====================================================================

SET NAMES utf8mb4;

INSERT INTO users (name, email, password_hash, role)
VALUES
  ('Sarah Whitfield', 'admin@qa.local',   '$2y$12$6MLEEzREtrlwhV1GnSx.IOeAyW/Y6Mi5clfXMjtSWfd2FjHnfMYFG', 'admin'),
  ('Daniel Okafor',  'lead@qa.local',    '$2y$12$6MLEEzREtrlwhV1GnSx.IOeAyW/Y6Mi5clfXMjtSWfd2FjHnfMYFG', 'qa_lead'),
  ('Marina Costa',   'analyst@qa.local', '$2y$12$6MLEEzREtrlwhV1GnSx.IOeAyW/Y6Mi5clfXMjtSWfd2FjHnfMYFG', 'qa_analyst')
ON DUPLICATE KEY UPDATE name = VALUES(name);

INSERT INTO clients (name, code, am_name) VALUES
  ('Northwind Relief',   'NWR', 'Alex Bennett'),
  ('Harbour Children',   'HBC', 'Priya Raman'),
  ('Evergreen Health',   'EVH', 'Tom Delaney')
ON DUPLICATE KEY UPDATE code = VALUES(code);

INSERT INTO campaigns (client_id, name, code)
SELECT c.id, 'Winter Emergency Appeal', 'NWR-WEA24' FROM clients c WHERE c.code = 'NWR'
ON DUPLICATE KEY UPDATE code = VALUES(code);

INSERT INTO campaigns (client_id, name, code)
SELECT c.id, 'Back to School 2024', 'NWR-BTS24' FROM clients c WHERE c.code = 'NWR'
ON DUPLICATE KEY UPDATE code = VALUES(code);

INSERT INTO campaigns (client_id, name, code)
SELECT c.id, 'Clean Water Fund', 'HBC-CWF' FROM clients c WHERE c.code = 'HBC'
ON DUPLICATE KEY UPDATE code = VALUES(code);

INSERT INTO donation_forms (campaign_id, name, environment, url, template_url, appeal_code, created_by)
SELECT cp.id, 'WEA24 - Single Step Donation', 'staging',
       'https://staging.northwind-relief.org/donate/winter-emergency',
       'https://templates.qa.local/df-single-step-v3.html', 'WEA24-SS', 1
FROM campaigns cp WHERE cp.code = 'NWR-WEA24'
ON DUPLICATE KEY UPDATE url = VALUES(url);

INSERT INTO donation_forms (campaign_id, name, environment, url, template_url, appeal_code, created_by)
SELECT cp.id, 'BTS24 - Two Step Donation', 'production',
       'https://www.northwind-relief.org/donate/back-to-school',
       'https://templates.qa.local/df-two-step-v2.html', 'BTS24-TS', 1
FROM campaigns cp WHERE cp.code = 'NWR-BTS24'
ON DUPLICATE KEY UPDATE url = VALUES(url);

INSERT INTO donation_forms (campaign_id, name, environment, url, template_url, appeal_code, created_by)
SELECT cp.id, 'CWF - Recurring Donation', 'test',
       'https://test.harbourchildren.org/give/clean-water',
       'https://templates.qa.local/df-recurring-v1.html', 'CWF-RC', 1
FROM campaigns cp WHERE cp.code = 'HBC-CWF'
ON DUPLICATE KEY UPDATE url = VALUES(url);
