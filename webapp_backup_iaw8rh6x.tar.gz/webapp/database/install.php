<?php
/**
 * CLI installer — creates the database, applies the schema and seeds demo data.
 *
 * Usage:
 *   php database/install.php                       # uses config/config*.php + prompts
 *   php database/install.php --fresh --seed --demo-user-role=admin
 *
 * This is a convenience for local/hosted setup. Production installs can equally
 * import database/schema.sql and database/seed.sql manually via mysql(1).
 */

declare(strict_types=1);

require_once __DIR__ . '/../app/Core/autoload.php';

use App\Core\Config;

$base = require __DIR__ . '/../config/config.php';
$local = __DIR__ . '/../config/config.local.php';

if (is_file($local)) {
    $base = Config::merge(require $local, $base);
}

Config::load($base);

$options = getopt('', ['fresh', 'seed', 'help']);

if (isset($options['help'])) {
    echo "Donation Form QA Validator — installer\n";
    echo "  --fresh   drop and recreate all tables\n";
    echo "  --seed    load demo clients, campaigns and forms\n";
    exit(0);
}

$db = (array) Config::get('db');

$serverDsn = sprintf('mysql:host=%s;port=%d;charset=%s', $db['host'], (int) $db['port'], $db['charset'] ?? 'utf8mb4');

echo "Connecting to MySQL at {$db['host']}:{$db['port']}…\n";

try {
    $pdo = new PDO($serverDsn, $db['username'], $db['password'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    ]);
} catch (PDOException $e) {
    fwrite(STDERR, "Connection failed: {$e->getMessage()}\n");
    fwrite(STDERR, "Check the credentials in config/config.local.php and that the database user exists.\n");
    exit(1);
}

// Create the database if the user has permission.
try {
    $pdo->exec(sprintf(
        'CREATE DATABASE IF NOT EXISTS `%s` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci',
        str_replace('`', '', $db['database'])
    ));
    echo "Database `{$db['database']}` ready.\n";
} catch (PDOException $e) {
    echo "Note: could not create the database ({$e->getMessage()}). Assuming it exists.\n";
}

$pdo->exec('USE `' . str_replace('`', '', $db['database']) . '`');

if (isset($options['fresh'])) {
    echo "Dropping existing tables…\n";
    $pdo->exec('SET FOREIGN_KEY_CHECKS = 0');

    foreach (['reports', 'evidence_files', 'test_results', 'test_executions', 'donation_forms', 'campaigns', 'clients', 'users'] as $table) {
        $pdo->exec("DROP TABLE IF EXISTS `$table`");
    }

    $pdo->exec('SET FOREIGN_KEY_CHECKS = 1');
}

$schema = file_get_contents(__DIR__ . '/schema.sql');

if ($schema === false) {
    fwrite(STDERR, "Could not read schema.sql\n");
    exit(1);
}

$pdo->exec($schema);
echo "Schema applied.\n";

if (isset($options['seed'])) {
    $seed = file_get_contents(__DIR__ . '/seed.sql');

    if ($seed !== false) {
        try {
            $pdo->exec($seed);
            echo "Demo data loaded (3 users, 3 clients, 3 campaigns, 3 forms).\n";
        } catch (PDOException $e) {
            echo "Seed warning: {$e->getMessage()}\n";
        }
    }
}

// Ensure demo accounts exist with a known password, even if the seed hash drifted.
if (isset($options['seed'])) {
    $hash  = password_hash('QaValidator!2024', PASSWORD_DEFAULT);
    $stmt  = $pdo->prepare('UPDATE users SET password_hash = ? WHERE email IN (?, ?, ?)');
    $stmt->execute([$hash, 'admin@qa.local', 'lead@qa.local', 'analyst@qa.local']);
    echo "Demo passwords set to: QaValidator!2024\n";
}

$counts = [];

foreach (['users', 'clients', 'campaigns', 'donation_forms', 'test_executions'] as $table) {
    $counts[$table] = (int) $pdo->query("SELECT COUNT(*) FROM `$table`")->fetchColumn();
}

echo "\nRow counts:\n";

foreach ($counts as $table => $count) {
    printf("  %-18s %d\n", $table, $count);
}

echo "\nInstallation complete.\n";
