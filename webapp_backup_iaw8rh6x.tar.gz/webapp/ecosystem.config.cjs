// PM2 process definition for the Donation Form QA Validator (sandbox / dev).
// Production hosts should use Apache/Nginx + PHP-FPM instead — see docs/INSTALL.md.
module.exports = {
  apps: [
    {
      name: 'webapp',
      script: 'php',
      args: '-S 0.0.0.0:3000 -t public public/router.php',
      cwd: '/home/user/webapp',
      interpreter: 'none',
      watch: false,
      instances: 1,
      exec_mode: 'fork',
      autorestart: true,
      max_restarts: 10,
      env: {
        NODE_ENV: 'development',
        PORT: 3000
      },
      out_file: '/home/user/webapp/storage/tmp/php-server.log',
      error_file: '/home/user/webapp/storage/tmp/php-server.err.log',
      merge_logs: true
    }
  ]
};
