<?php
/**
 * Default application configuration.
 * Do NOT put real credentials here — copy config/config.local.php.example
 * to config/config.local.php and edit that file (it is git-ignored).
 */
return [
    'app' => [
        'name'      => 'Donation Form QA Validator',
        'version'   => '1.0.0',
        'env'       => 'production',           // production | development
        'debug'     => false,
        'timezone'  => 'UTC',
        'base_path' => '',                      // e.g. '/qa-validator' when served from a subdirectory
        'url'       => '',                      // e.g. 'https://qa.example.org' (empty = auto-detect)
    ],

    'db' => [
        'host'     => '127.0.0.1',
        'port'     => 3306,
        'database' => 'donation_qa',
        'username' => 'donation_qa',
        'password' => 'change-me',
        'charset'  => 'utf8mb4',
    ],

    'session' => [
        'name'     => 'dfqa_session',
        'lifetime' => 28800,                    // 8 hours
        'secure'   => null,                     // null = auto (HTTPS only)
        'samesite' => 'Lax',
    ],

    'uploads' => [
        'dir'              => __DIR__ . '/../storage/uploads',
        'max_file_size'    => 10485760,         // 10 MB per file
        'max_files'        => 40,               // per execution
        'allowed'          => [
            'png'  => ['image/png'],
            'jpg'  => ['image/jpeg'],
            'jpeg' => ['image/jpeg'],
            'pdf'  => ['application/pdf'],
            'eml'  => ['message/rfc822', 'application/octet-stream', 'text/plain', 'text/eml'],
            'msg'  => ['application/vnd.ms-outlook', 'application/octet-stream'],
        ],
    ],

    'automation' => [
        'timeout'          => 20,               // seconds per HTTP request
        'max_html_bytes'   => 3145728,          // 3 MB of HTML analysed
        'user_agent'       => 'Mozilla/5.0 (compatible; DonationFormQA/1.0; +https://qa.local)',
        'max_links_checked'=> 60,
    ],

    'reports' => [
        'dir' => __DIR__ . '/../storage/reports',
    ],
];
