<?php
/**
 * Local development overrides (git-ignored).
 */
return [
    'app' => [
        'env'   => 'development',
        'debug' => true,
    ],
    'db' => [
        'host'     => '127.0.0.1',
        'port'     => 3306,
        'database' => 'donation_qa',
        'username' => 'donation_qa',
        'password' => 'qa_local_dev_pw_2024',
    ],
];
