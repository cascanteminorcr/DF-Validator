<?php

declare(strict_types=1);

namespace App\Services;

use App\Core\Config;

/**
 * Automated validation engine.
 *
 * Fetches the donation form and inspects the returned HTML for the four
 * automated QA families:
 *   1. URL / HTTP integrity (status, HTTPS, mixed content, friendly URL, preview mode)
 *   2. Open Graph tags
 *   3. Analytics tags (GTM, GA, Facebook Pixel)
 *   4. Accessibility (alt attributes, button labels, form labels)
 *   5. Links (internal vs external target behaviour, broken links)
 *
 * Every check returns a normalised result:
 *   ['key','group','label','status' => pass|fail|warn|info, 'detail','value' => mixed]
 *
 * The engine is intentionally dependency-free (cURL only) so it runs anywhere
 * PHP does — no Node, no headless browser required.
 */
final class AutomationService
{
    private array $warnings = [];

    /**
     * @return array{
     *   fetched:bool,url:string,final_url:string,http_status:int,
     *   elapsed_ms:int,duration:float,checked_at:string,
     *   groups:array<string,array{label:string,results:array}>,
     *   summary:array{pass:int,fail:int,warn:int,info:int},
     *   error:?string
     * }
     */
    public function analyse(string $url, ?string $templateUrl = null): array
    {
        $started = microtime(true);
        $url     = trim($url);

        $report = [
            'fetched'     => false,
            'url'         => $url,
            'final_url'   => $url,
            'http_status' => 0,
            'elapsed_ms'  => 0,
            'checked_at'  => date('c'),
            'groups'      => [],
            'summary'     => ['pass' => 0, 'fail' => 0, 'warn' => 0, 'info' => 0],
            'error'       => null,
            'meta'        => [],
        ];

        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            $report['error']           = 'The supplied URL is not valid, so automated checks could not run.';
            $report['elapsed_ms']      = (int) round((microtime(true) - $started) * 1000);
            $report['groups']['url']   = [
                'label'   => 'URL Validation',
                'results' => [[
                    'key'    => 'url_reachable',
                    'group'  => 'url',
                    'label'  => 'URL is syntactically valid',
                    'status' => 'fail',
                    'detail' => 'The URL could not be parsed. Fix the Donation Form URL and re-run.',
                    'value'  => $url,
                ]],
            ];
            $this->tally($report);

            return $report;
        }

        $response = $this->fetch($url);

        $report['http_status'] = $response['status'];
        $report['final_url']   = $response['final_url'];
        $report['elapsed_ms']  = $response['elapsed_ms'];
        $report['error']       = $response['error'];

        $html = $response['body'];
        $dom  = $this->parseHtml($html);

        // ---------------------------------------------------------------
        // 1. URL validation
        // ---------------------------------------------------------------
        $urlResults = $this->checkUrl($url, $response, $html);

        $report['groups']['url'] = ['label' => 'URL Validation', 'results' => $urlResults];

        // ---------------------------------------------------------------
        // 2. Open Graph
        // ---------------------------------------------------------------
        $report['groups']['og'] = ['label' => 'Open Graph Validation', 'results' => $this->checkOpenGraph($dom, $html)];

        // ---------------------------------------------------------------
        // 3. Analytics
        // ---------------------------------------------------------------
        $report['groups']['analytics'] = ['label' => 'Analytics Validation', 'results' => $this->checkAnalytics($html)];

        // ---------------------------------------------------------------
        // 4. Accessibility
        // ---------------------------------------------------------------
        $report['groups']['accessibility'] = ['label' => 'Accessibility Validation', 'results' => $this->checkAccessibility($dom, $html)];

        // ---------------------------------------------------------------
        // 5. Links
        // ---------------------------------------------------------------
        $report['groups']['links'] = ['label' => 'Link Validation', 'results' => $this->checkLinks($dom, $response['final_url'])];

        // ---------------------------------------------------------------
        // 6. Template comparison (optional)
        // ---------------------------------------------------------------
        if ($templateUrl !== null && trim($templateUrl) !== '') {
            $report['groups']['template'] = [
                'label'   => 'Template Comparison',
                'results' => $this->compareTemplate($templateUrl, $html),
            ];
        }

        $report['meta'] = [
            'title'        => $this->firstMatch('#<title[^>]*>(.*?)</title>#is', $html),
            'og_image'     => $this->metaContent($dom, 'og:image'),
            'html_bytes'   => strlen($html),
            'content_type' => $response['content_type'],
        ];

        $report['fetched'] = $response['status'] > 0;

        $this->tally($report);
        $report['elapsed_ms'] = (int) round((microtime(true) - $started) * 1000);

        return $report;
    }

    // =====================================================================
    // HTTP
    // =====================================================================

    private function fetch(string $url): array
    {
        $result = [
            'status'       => 0,
            'body'         => '',
            'final_url'    => $url,
            'content_type' => '',
            'elapsed_ms'   => 0,
            'error'        => null,
            'headers'      => [],
        ];

        $started = microtime(true);

        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 8,
            CURLOPT_TIMEOUT        => (int) Config::get('automation.timeout', 20),
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_USERAGENT      => (string) Config::get('automation.user_agent', 'DonationFormQA/1.0'),
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_ENCODING       => '',
            CURLOPT_HEADER         => false,
            CURLOPT_HTTPHEADER     => [
                'Accept: text/html,application/xhtml+xml',
                'Accept-Language: en-US,en;q=0.9',
                'Cache-Control: no-cache',
            ],
        ]);

        $body    = curl_exec($ch);
        $info    = curl_getinfo($ch);
        $curlErr = curl_error($ch);

        if (PHP_VERSION_ID < 80000 && is_resource($ch)) {
            curl_close($ch);
        } elseif (PHP_VERSION_ID >= 80000) {
            // curl_close is a no-op since PHP 8, handle stays garbage collected.
        }

        $result['elapsed_ms'] = (int) round((microtime(true) - $started) * 1000);
        $result['status']     = (int) ($info['http_code'] ?? 0);
        $result['final_url']  = (string) ($info['url'] ?? $url);
        $result['content_type'] = (string) ($info['content_type'] ?? '');
        $result['elapsed_ms'] = (int) round((microtime(true) - $started) * 1000);

        if ($body === false || $body === null) {
            $result['error'] = $curlErr !== '' ? $curlErr : 'The request failed before a response was received.';

            return $result;
        }

        $maxBytes = (int) Config::get('automation.max_html_bytes', 3145728);

        if (strlen($body) > $maxBytes) {
            $body = substr($body, 0, $maxBytes);
        }

        $result['body'] = (string) $body;

        if (stripos($result['content_type'], 'html') === false && $result['body'] === '') {
            $result['error'] = 'The response had no HTML body.';
        }

        return $result;
    }

    // =====================================================================
    // 1. URL / HTTP integrity
    // =====================================================================

    private function checkUrl(string $url, array $response, string $html): array
    {
        $results = [];
        $status  = (int) $response['status'];
        $loaded  = $status >= 200 && $status < 400 && $response['body'] !== '';

        $results[] = $this->result(
            'url_reachable',
            'url',
            'Page loads successfully',
            $loaded ? 'pass' : 'fail',
            $loaded
                ? sprintf('The form responded with HTTP %d in %d ms.', $status, $response['elapsed_ms'])
                : ($response['error'] ?? sprintf('The page did not load (HTTP %d).', $status)),
            ['http_status' => $status, 'bytes' => strlen($response['body'])]
        );

        $is200 = $status === 200;
        $results[] = $this->result(
            'http_200',
            'url',
            'HTTP Status Code = 200',
            $is200 ? 'pass' : ($status > 0 ? 'fail' : 'fail'),
            $status === 200
                ? 'The document is served with a clean 200 OK status.'
                : sprintf('Expected 200 OK but received %d%s.', $status, $status === 0 ? ' (no response)' : ''),
            ['http_status' => $status]
        );

        $scheme      = strtolower((string) parse_url($url, PHP_URL_SCHEME));
        $isHttps     = $scheme === 'https';
        $finalScheme = strtolower((string) parse_url($response['final_url'], PHP_URL_SCHEME));

        $results[] = $this->result(
            'https_enabled',
            'url',
            'HTTPS enabled',
            ($isHttps && $finalScheme === 'https') ? 'pass' : 'fail',
            ($isHttps && $finalScheme === 'https')
                ? 'The form is served over HTTPS with a valid certificate chain.'
                : sprintf('The form is served over %s. Donation forms must use HTTPS.', strtoupper($finalScheme ?: $scheme ?: 'unknown')),
            ['scheme' => $finalScheme ?: $scheme]
        );

        $mixed = $this->findMixedContent($html);
        $results[] = $this->result(
            'no_mixed_content',
            'url',
            'No mixed content',
            $mixed === [] ? 'pass' : 'fail',
            $mixed === []
                ? 'No insecure http:// assets were found in the page source.'
                : sprintf('%d insecure asset(s) found: %s', count($mixed), implode(', ', array_slice($mixed, 0, 5))),
            ['insecure_assets' => $mixed]
        );

        $friendly = $this->checkFriendlyUrl($url);
        $results[] = $this->result(
            'friendly_url',
            'url',
            'Friendly URL format',
            $friendly['ok'] ? 'pass' : 'warn',
            $friendly['detail'],
            ['segment' => $friendly['segment']]
        );

        $previewMarkers = $this->findPreviewMarkers($html, $url);
        $results[] = $this->result(
            'no_preview_mode',
            'url',
            'No preview mode indicators',
            $previewMarkers === [] ? 'pass' : 'fail',
            $previewMarkers === []
                ? 'No preview/token query strings or preview banners detected.'
                : 'Preview indicators detected: ' . implode(', ', $previewMarkers),
            ['markers' => $previewMarkers]
        );

        return $results;
    }

    private function findMixedContent(string $html): array
    {
        $found = [];

        if (preg_match_all('#\bsrc\s*=\s*["\'](http://[^"\']+)["\']#i', $html, $m)) {
            $found = array_merge($found, $m[1]);
        }

        if (preg_match_all('#\bhref\s*=\s*["\'](http://[^"\']+\.(?:css|js|png|jpe?g|gif|svg|webp|woff2?))["\']#i', $html, $m2)) {
            $found = array_merge($found, $m2[1]);
        }

        if (preg_match_all('#@import\s+url\(\s*["\']?(http://[^"\')]+)#i', $html, $m3)) {
            $found = array_merge($found, $m3[1]);
        }

        return array_values(array_unique($found));
    }

    private function checkFriendlyUrl(string $url): array
    {
        $path     = (string) parse_url($url, PHP_URL_PATH);
        $query    = (string) parse_url($url, PHP_URL_QUERY);
        $segments = array_values(array_filter(explode('/', $path), static fn ($s) => $s !== ''));

        $issues = [];

        if ($segments === []) {
            $issues[] = 'The URL resolves to the site root instead of a named form.';
        }

        $last = end($segments) ?: '';

        if (preg_match('#\.(php|html?|aspx?)$#i', $last)) {
            if (!preg_match('#^(donate|give|donation)[\w-]*\.html?$#i', $last)) {
                $issues[] = 'The URL exposes a script/extension filename ("' . $last . '").';
            }
        }

        if (preg_match('/[A-Z]/', $path)) {
            $issues[] = 'The path contains upper-case characters.';
        }

        if (preg_match('/[_%20]/', $path)) {
            $issues[] = 'The path contains underscores, spaces or encoded characters.';
        }

        if ($query !== '' && preg_match('/(token|preview|sess|utm_|fbclid|gclid)/i', $query)) {
            $issues[] = 'Tracking/preview parameters are present in the URL.';
        }

        return [
            'ok'      => $issues === [],
            'detail'  => $issues === []
                ? 'The URL is a clean, lower-case, hyphenated vanity path (/donate/…).'
                : implode(' ', $issues),
            'segment' => '/' . implode('/', $segments),
        ];
    }

    private function findPreviewMarkers(string $html, string $url): array
    {
        $markers = [];
        $query   = (string) parse_url($url, PHP_URL_QUERY);

        if ($query !== '') {
            parse_str($query, $params);

            foreach (array_keys($params) as $key) {
                if (preg_match('/^(preview|previewmode|preview_mode|draft|staging_token|token|access_token)$/i', (string) $key)) {
                    $markers[] = 'query parameter "' . $key . '"';
                }
            }
        }

        $patterns = [
            '/preview\s*mode/i'            => 'preview mode text',
            '/class=["\'][^"\']*preview-banner/i' => 'preview banner element',
            '/you are viewing a preview/i' => 'preview notice copy',
            '/environment\s*:\s*staging/i' => 'staging environment banner',
            '/DRAFT\s*-\s*NOT\s*LIVE/i'    => 'draft watermark',
        ];

        foreach ($patterns as $pattern => $label) {
            if (preg_match($pattern, $html)) {
                $markers[] = $label;
            }
        }

        return $markers;
    }

    // =====================================================================
    // 2. Open Graph
    // =====================================================================

    private function checkOpenGraph(\DOMDocument|null $dom, string $html): array
    {
        $results = [];

        foreach (['og:title' => 'og:title', 'og:image' => 'og:image', 'og:description' => 'og:description'] as $tag => $label) {
            $value = $this->metaContent($dom, $tag);

            if ($value === null || trim($value) === '') {
                $results[] = $this->result(
                    'og_' . str_replace(':', '_', $tag),
                    'og',
                    $label . ' present',
                    'fail',
                    'The ' . $tag . ' tag is missing from the page head.',
                    null
                );
                continue;
            }

            $extra = null;
            $status = 'pass';

            if ($tag === 'og:image') {
                if (!filter_var($value, FILTER_VALIDATE_URL)) {
                    $status = 'fail';
                    $extra  = 'The image URL is not absolute. Open Graph requires a fully-qualified https:// URL.';
                } elseif (str_starts_with(strtolower($value), 'http://')) {
                    $status = 'warn';
                    $extra  = 'The image is served over http:// — social platforms prefer https://.';
                } elseif (!$this->headOk($value)) {
                    $status = 'warn';
                    $extra  = 'The image URL did not respond with a 200 OK image content type.';
                }
            }

            if ($tag === 'og:description' && mb_strlen($value) < 40) {
                $status = 'warn';
                $extra  = sprintf('Description is only %d characters; 110–160 is recommended for previews.', mb_strlen($value));
            }

            if ($tag === 'og:title' && mb_strlen($value) < 10) {
                $status = 'warn';
                $extra  = 'Title is very short and may be truncated oddly in social previews.';
            }

            $results[] = $this->result(
                'og_' . str_replace(':', '_', $tag),
                'og',
                $label . ' present',
                $status,
                $extra ?? ('Found: "' . $this->truncate($value, 160) . '"'),
                ['value' => $value]
            );
        }

        if ($this->metaContent($dom, 'twitter:card') === null) {
            $results[] = $this->result(
                'twitter_card',
                'og',
                'twitter:card fallback',
                'info',
                'No twitter:card tag found. Not mandatory, but improves X/Twitter previews.',
                null
            );
        }

        return $results;
    }

    private function headOk(string $url): bool
    {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => $url,
            CURLOPT_NOBODY         => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT        => 8,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_USERAGENT      => (string) Config::get('automation.user_agent', 'DonationFormQA/1.0'),
        ]);
        curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $type = (string) curl_getinfo($ch, CURLINFO_CONTENT_TYPE);

        return $code >= 200 && $code < 300 && ($type === '' || str_starts_with($type, 'image/'));
    }

    // =====================================================================
    // 3. Analytics
    // =====================================================================

    private function checkAnalytics(string $html): array
    {
        $results = [];

        $gtmIds   = $this->collect('/GTM-[A-Z0-9]{4,}/i', $html);
        $ga4Ids   = $this->collect('/\bG-[A-Z0-9]{6,}\b/', $html);
        $uaIds    = $this->collect('/\bUA-\d{4,}-\d+/', $html);
        $pixelIds = $this->collect('/\bfbq\(\s*[\'"]init[\'"]\s*,\s*[\'"](\d{6,})[\'"]/i', $html, 1);
        $pixelRaw = $this->collect('/\bconnect\.facebook\.net\/[a-z_]+\/(?:fbevents\.js\?id=)?(\d{6,})/i', $html, 1);
        $pixelIds = array_values(array_unique(array_merge($pixelIds, $pixelRaw)));

        $hasGtmScript = (bool) preg_match('/googletagmanager\.com\/gtm\.js|GTM-[A-Z0-9]{4,}/i', $html);
        $results[] = $this->result(
            'gtm',
            'analytics',
            'Google Tag Manager',
            $hasGtmScript ? 'pass' : 'fail',
            $hasGtmScript
                ? ('GTM container detected: ' . ($gtmIds !== [] ? implode(', ', $gtmIds) : 'container reference found'))
                : 'No Google Tag Manager container (GTM-XXXX) was found in the page source.',
            ['ids' => $gtmIds]
        );

        $hasGa = $ga4Ids !== [] || $uaIds !== [] || preg_match('/gtag\(|google-analytics\.com|analytics\.js/i', $html);
        $gaIds = array_merge($ga4Ids, $uaIds);
        $results[] = $this->result(
            'google_analytics',
            'analytics',
            'Google Analytics',
            $hasGa ? 'pass' : 'fail',
            $hasGa
                ? ('Google Analytics detected: ' . ($gaIds !== [] ? implode(', ', $gaIds) : 'gtag()/analytics.js reference found'))
                : 'No Google Analytics (G-XXXX / UA-XXXX / gtag) found in the page source.',
            ['ids' => $gaIds, 'note' => $gaIds === [] && $hasGa ? 'Analytics loaded indirectly (possibly via GTM).' : null]
        );

        $results[] = $this->result(
            'facebook_pixel',
            'analytics',
            'Facebook Pixel',
            $pixelIds !== [] ? 'pass' : 'fail',
            $pixelIds !== []
                ? ('Facebook Pixel detected: ' . implode(', ', $pixelIds))
                : 'No Facebook Pixel (fbq init / connect.facebook.net) found in the page source.',
            ['ids' => $pixelIds]
        );

        if ($gtmIds !== [] && $gaIds === []) {
            $results[] = $this->result(
                'analytics_via_gtm',
                'analytics',
                'Analytics coverage note',
                'info',
                'GTM is present but GA is not inline — confirm the GA tag is published inside the container.',
                null
            );
        }

        return $results;
    }

    // =====================================================================
    // 4. Accessibility
    // =====================================================================

    private function checkAccessibility(\DOMDocument|null $dom, string $html): array
    {
        $results = [];

        if ($dom === null) {
            return [$this->result('a11y_parse', 'accessibility', 'HTML parsable for accessibility audit', 'fail', 'The page HTML could not be parsed.', null)];
        }

        $xp = new \DOMXPath($dom);

        // --- images without alt -------------------------------------------
        $images      = $xp->query('//img');
        $missingAlt  = [];

        foreach ($images as $img) {
            /** @var \DOMElement $img */
            if (!$img->hasAttribute('alt')) {
                $src        = $img->getAttribute('src') ?: $img->getAttribute('data-src') ?: '(inline)';
                $missingAlt[] = $this->truncate($src, 80);
            }
        }

        $imgTotal = $images->length;
        $results[] = $this->result(
            'img_alt',
            'accessibility',
            'Images contain alt attributes',
            $missingAlt === [] ? 'pass' : 'warn',
            $imgTotal === 0
                ? 'No <img> elements found on the page.'
                : ($missingAlt === []
                    ? sprintf('All %d image(s) declare an alt attribute.', $imgTotal)
                    : sprintf('%d of %d image(s) are missing alt text: %s', count($missingAlt), $imgTotal, implode(', ', array_slice($missingAlt, 0, 6)))),
            ['total' => $imgTotal, 'missing' => count($missingAlt), 'samples' => array_slice($missingAlt, 0, 10)]
        );

        // --- buttons without accessible labels ----------------------------
        $buttons     = $xp->query('//button');
        $unlabelled  = [];

        foreach ($buttons as $button) {
            /** @var \DOMElement $button */
            $text  = trim(preg_replace('/\s+/', ' ', $button->textContent ?? ''));
            $aria  = trim($button->getAttribute('aria-label'));
            $title = trim($button->getAttribute('title'));
            $value = trim($button->getAttribute('value'));
            $imgAlt = '';
            $imgNodes = $xp->query('.//img[@alt]', $button);

            if ($imgNodes->length > 0) {
                $imgAlt = trim($imgNodes->item(0)->getAttribute('alt'));
            }

            if ($text === '' && $aria === '' && $title === '' && $value === '' && $imgAlt === '') {
                $unlabelled[] = $button->getAttribute('class') ?: $button->getAttribute('id') ?: $button->getAttribute('type') ?: '(unnamed button)';
            }
        }

        $results[] = $this->result(
            'button_labels',
            'accessibility',
            'Buttons contain labels',
            $unlabelled === [] ? 'pass' : 'warn',
            $buttons->length === 0
                ? 'No <button> elements found on the page.'
                : ($unlabelled === []
                    ? sprintf('All %d button(s) expose an accessible label.', $buttons->length)
                    : sprintf('%d button(s) have no text, aria-label or title: %s', count($unlabelled), implode(', ', array_slice($unlabelled, 0, 6)))),
            ['total' => $buttons->length, 'unlabelled' => count($unlabelled), 'samples' => array_slice($unlabelled, 0, 10)]
        );

        // --- form controls without labels ---------------------------------
        $fields      = $xp->query('//input[not(@type="hidden") and not(@type="submit") and not(@type="button")] | //select | //textarea');
        $unlabelledFields = [];

        foreach ($fields as $field) {
            /** @var \DOMElement $field */
            $id          = $field->getAttribute('id');
            $ariaLabel   = trim($field->getAttribute('aria-label'));
            $ariaBy      = trim($field->getAttribute('aria-labelledby'));
            $placeholder = trim($field->getAttribute('placeholder'));
            $name        = $field->getAttribute('name') ?: $field->getAttribute('type') ?: 'field';
            $hasLabel    = false;

            if ($id !== '') {
                $labelNodes = $xp->query('//label[@for="' . $id . '"]');

                if ($labelNodes->length > 0 && trim($labelNodes->item(0)->textContent) !== '') {
                    $hasLabel = true;
                }
            }

            if (!$hasLabel) {
                // wrapping <label>
                $parent = $field->parentNode;

                while ($parent instanceof \DOMElement) {
                    if (strtolower($parent->nodeName) === 'label' && trim($parent->textContent) !== '') {
                        $hasLabel = true;
                        break;
                    }
                    $parent = $parent->parentNode;
                }
            }

            if (!$hasLabel && ($ariaLabel !== '' || $ariaBy !== '')) {
                $hasLabel = true;
            }

            if (!$hasLabel) {
                $unlabelledFields[] = $name . ($placeholder !== '' ? ' (placeholder only)' : '');
            }
        }

        $results[] = $this->result(
            'field_labels',
            'accessibility',
            'Forms contain field labels',
            $unlabelledFields === [] ? 'pass' : 'warn',
            $fields->length === 0
                ? 'No form controls found on the page.'
                : ($unlabelledFields === []
                    ? sprintf('All %d form control(s) are programmatically labelled.', $fields->length)
                    : sprintf('%d of %d field(s) lack a <label>/aria-label: %s', count($unlabelledFields), $fields->length, implode(', ', array_slice($unlabelledFields, 0, 6)))),
            ['total' => $fields->length, 'unlabelled' => count($unlabelledFields), 'samples' => array_slice($unlabelledFields, 0, 10)]
        );

        // --- language + document title ------------------------------------
        $lang = $xp->query('//html')->item(0)?->getAttribute('lang') ?? '';
        $results[] = $this->result(
            'html_lang',
            'accessibility',
            'Document language declared',
            trim($lang) !== '' ? 'pass' : 'warn',
            trim($lang) !== '' ? 'html lang="' . $lang . '" declared.' : 'The <html> element has no lang attribute (WCAG 3.1.1).',
            ['lang' => $lang]
        );

        return $results;
    }

    // =====================================================================
    // 5. Links
    // =====================================================================

    private function checkLinks(\DOMDocument|null $dom, string $baseUrl): array
    {
        $results = [];

        if ($dom === null) {
            return [$this->result('links_parse', 'links', 'Links analysable', 'fail', 'The page HTML could not be parsed.', null)];
        }

        $xp       = new \DOMXPath($dom);
        $baseHost = strtolower((string) parse_url($baseUrl, PHP_URL_HOST));

        $internalSameTab = 0;
        $internalNewTab  = [];
        $externalNewTab  = 0;
        $externalSameTab = [];
        $targets         = [];
        $noRel           = [];

        foreach ($xp->query('//a[@href]') as $link) {
            /** @var \DOMElement $link */
            $href   = trim($link->getAttribute('href'));
            $target = strtolower(trim($link->getAttribute('target')));
            $rel    = strtolower(trim($link->getAttribute('rel')));

            if ($href === '' || str_starts_with($href, '#') || str_starts_with(strtolower($href), 'javascript:')
                || str_starts_with(strtolower($href), 'mailto:') || str_starts_with(strtolower($href), 'tel:')) {
                continue;
            }

            $host     = strtolower((string) parse_url($href, PHP_URL_HOST));
            $absolute = $host !== '';
            $isInternal = !$absolute || $host === $baseHost || str_ends_with($host, '.' . $baseHost);

            if ($isInternal) {
                if ($target === '_blank') {
                    $internalNewTab[] = $this->truncate($href, 70);
                } else {
                    $internalSameTab++;
                }
            } else {
                if ($target === '_blank') {
                    $externalNewTab++;

                    if (!str_contains($rel, 'noopener') && !str_contains($rel, 'noreferrer')) {
                        $noRel[] = $this->truncate($href, 70);
                    }
                } else {
                    $externalSameTab[] = $this->truncate($href, 70);
                }
            }

            $absoluteUrl = $this->absolutise($href, $baseUrl);

            if ($absoluteUrl !== null && count($targets) < (int) Config::get('automation.max_links_checked', 60)) {
                $targets[$absoluteUrl] = true;
            }
        }

        $results[] = $this->result(
            'internal_same_tab',
            'links',
            'Internal links open in same tab',
            $internalNewTab === [] ? 'pass' : 'warn',
            $internalNewTab === []
                ? sprintf('%d internal link(s) correctly stay in the same tab.', $internalSameTab)
                : sprintf('%d internal link(s) force a new tab: %s', count($internalNewTab), implode(', ', array_slice($internalNewTab, 0, 5))),
            ['samples' => array_slice($internalNewTab, 0, 10)]
        );

        $results[] = $this->result(
            'external_new_tab',
            'links',
            'External links open in new tab',
            $externalSameTab === [] ? 'pass' : 'warn',
            $externalSameTab === []
                ? sprintf('%d external link(s) correctly open in a new tab.', $externalNewTab)
                : sprintf('%d external link(s) open in the same tab: %s', count($externalSameTab), implode(', ', array_slice($externalSameTab, 0, 5))),
            ['samples' => array_slice($externalSameTab, 0, 10)]
        );

        if ($noRel !== []) {
            $results[] = $this->result(
                'external_rel_noopener',
                'links',
                'External new-tab links use rel="noopener"',
                'warn',
                sprintf('%d external link(s) open a new tab without rel="noopener": %s', count($noRel), implode(', ', array_slice($noRel, 0, 5))),
                ['samples' => array_slice($noRel, 0, 10)]
            );
        }

        // --- broken link sweep (HEAD requests, capped) --------------------
        $broken  = [];
        $checked = 0;

        foreach (array_keys($targets) as $candidate) {
            if ($checked >= (int) Config::get('automation.max_links_checked', 60)) {
                break;
            }

            $checked++;
            $code = $this->headStatus($candidate);

            if ($code === 0) {
                $code = $this->getStatus($candidate);
            }

            if ($code === 0 || $code >= 400) {
                $broken[] = $code . ' — ' . $this->truncate($candidate, 90);
            }
        }

        $results[] = $this->result(
            'no_broken_links',
            'links',
            'No broken links',
            $broken === [] ? 'pass' : 'fail',
            $broken === []
                ? sprintf('All %d checked link(s) responded successfully.', $checked)
                : sprintf('%d broken link(s) found: %s', count($broken), implode('; ', array_slice($broken, 0, 5))),
            ['checked' => $checked, 'broken' => array_slice($broken, 0, 20)]
        );

        return $results;
    }

    private function headStatus(string $url): int
    {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => $url,
            CURLOPT_NOBODY         => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 5,
            CURLOPT_TIMEOUT        => 8,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_USERAGENT      => (string) Config::get('automation.user_agent', 'DonationFormQA/1.0'),
        ]);
        curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);

        return $code;
    }

    private function getStatus(string $url): int
    {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 5,
            CURLOPT_TIMEOUT        => 10,
            CURLOPT_RANGE          => '0-2048',
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_USERAGENT      => (string) Config::get('automation.user_agent', 'DonationFormQA/1.0'),
        ]);
        curl_exec($ch);

        return (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    }

    private function absolutise(string $href, string $baseUrl): ?string
    {
        $href = trim(html_entity_decode($href, ENT_QUOTES | ENT_HTML5));

        if ($href === '' || str_starts_with($href, '#')) {
            return null;
        }

        if (preg_match('#^https?://#i', $href)) {
            return $href;
        }

        $parts  = parse_url($baseUrl);
        $scheme = $parts['scheme'] ?? 'https';
        $host   = $parts['host'] ?? '';

        if ($host === '') {
            return null;
        }

        if (str_starts_with($href, '//')) {
            return $scheme . ':' . $href;
        }

        if (str_starts_with($href, '/')) {
            return $scheme . '://' . $host . $href;
        }

        $basePath = $parts['path'] ?? '/';
        $dir      = rtrim(substr($basePath, 0, (int) strrpos($basePath, '/') + 1), '/');

        return $scheme . '://' . $host . '/' . ltrim($dir . '/' . $href, '/');
    }

    // =====================================================================
    // 6. Template comparison (optional)
    // =====================================================================

    private function compareTemplate(string $templateUrl, string $liveHtml): array
    {
        if (!filter_var($templateUrl, FILTER_VALIDATE_URL)) {
            return [$this->result('template_url', 'template', 'Template URL valid', 'fail', 'The template URL is not a valid absolute URL.', null)];
        }

        $template = $this->fetch($templateUrl);

        if ($template['status'] === 0 || $template['body'] === '') {
            return [$this->result('template_reachable', 'template', 'Template loads', 'fail', 'The template URL could not be loaded: ' . ($template['error'] ?? 'no response'), null)];
        }

        $results = [];
        $results[] = $this->result(
            'template_reachable',
            'template',
            'Template loads',
            'pass',
            sprintf('Template fetched with HTTP %d (%d bytes).', $template['status'], strlen($template['body'])),
            ['http_status' => $template['status']]
        );

        $liveDom     = $this->parseHtml($liveHtml);
        $templateDom = $this->parseHtml($template['body']);

        $liveText     = $this->normaliseText($liveDom);
        $templateText = $this->normaliseText($templateDom);

        similar_text($liveText, $templateText, $percent);
        $similarity = round($percent, 1);

        $results[] = $this->result(
            'template_text_similarity',
            'template',
            'Copy similarity to template',
            $similarity >= 85 ? 'pass' : ($similarity >= 60 ? 'warn' : 'fail'),
            sprintf('Visible-text similarity is %.1f%% (threshold: 85%% pass / 60%% review).', $similarity),
            ['similarity' => $similarity]
        );

        // Structural fingerprint: headings + primary CTA labels.
        $liveHeads     = $this->texts($liveDom, '//h1|//h2|//h3');
        $templateHeads = $this->texts($templateDom, '//h1|//h2|//h3');
        $missingHeads  = array_values(array_diff($templateHeads, $liveHeads));

        $results[] = $this->result(
            'template_headings',
            'template',
            'Headings match template',
            $missingHeads === [] ? 'pass' : 'warn',
            $missingHeads === []
                ? 'All template headings are present on the live form.'
                : 'Headings present in the template but missing live: ' . implode(' | ', array_slice($missingHeads, 0, 5)),
            ['missing' => array_slice($missingHeads, 0, 10)]
        );

        $liveCta     = $this->texts($liveDom, '//button|//input[@type="submit"]');
        $templateCta = $this->texts($templateDom, '//button|//input[@type="submit"]');
        $ctaMatch    = array_values(array_intersect($templateCta, $liveCta));

        $results[] = $this->result(
            'template_cta',
            'template',
            'CTA labels match template',
            $templateCta === [] ? 'info' : ($ctaMatch !== [] ? 'pass' : 'warn'),
            $templateCta === []
                ? 'The template declares no buttons to compare against.'
                : ($ctaMatch !== []
                    ? 'Matching CTA label(s): ' . implode(', ', $ctaMatch)
                    : 'No template CTA label found live. Template: ' . implode(', ', array_slice($templateCta, 0, 4))),
            ['live' => $liveCta, 'template' => $templateCta]
        );

        return $results;
    }

    private function normaliseText(?\DOMDocument $dom): string
    {
        if ($dom === null) {
            return '';
        }

        $body = $dom->getElementsByTagName('body')->item(0);
        $text = $body ? $body->textContent : $dom->textContent;

        return trim((string) preg_replace('/\s+/', ' ', (string) $text));
    }

    /** @return array<int,string> */
    private function texts(?\DOMDocument $dom, string $xpath): array
    {
        if ($dom === null) {
            return [];
        }

        $out = [];

        foreach ((new \DOMXPath($dom))->query($xpath) as $node) {
            $value = trim((string) preg_replace('/\s+/', ' ', $node->textContent ?? ''));

            if ($value === '' && $node instanceof \DOMElement) {
                $value = trim($node->getAttribute('value'));
            }

            if ($value !== '') {
                $out[] = $value;
            }
        }

        return array_values(array_unique($out));
    }

    // =====================================================================
    // Helpers
    // =====================================================================

    private function parseHtml(string $html): ?\DOMDocument
    {
        if (trim($html) === '') {
            return null;
        }

        $dom = new \DOMDocument();
        $previous = libxml_use_internal_errors(true);

        $loaded = $dom->loadHTML(
            '<?xml encoding="UTF-8">' . $html,
            LIBXML_NOWARNING | LIBXML_NOERROR | LIBXML_NONET | LIBXML_COMPACT
        );

        libxml_clear_errors();
        libxml_use_internal_errors($previous);

        return $loaded ? $dom : null;
    }

    private function metaContent(?\DOMDocument $dom, string $property): ?string
    {
        if ($dom === null) {
            return null;
        }

        $xp = new \DOMXPath($dom);

        foreach ($xp->query('//meta[@property]') as $node) {
            /** @var \DOMElement $node */
            if (strcasecmp($node->getAttribute('property'), $property) === 0) {
                $value = trim($node->getAttribute('content'));

                return $value === '' ? null : html_entity_decode($value, ENT_QUOTES | ENT_HTML5);
            }
        }

        foreach ($xp->query('//meta[@name]') as $node) {
            /** @var \DOMElement $node */
            if (strcasecmp($node->getAttribute('name'), $property) === 0) {
                $value = trim($node->getAttribute('content'));

                return $value === '' ? null : html_entity_decode($value, ENT_QUOTES | ENT_HTML5);
            }
        }

        return null;
    }

    private function firstMatch(string $pattern, string $subject): ?string
    {
        if (preg_match($pattern, $subject, $m)) {
            return trim(html_entity_decode(strip_tags($m[1]), ENT_QUOTES | ENT_HTML5));
        }

        return null;
    }

    /** @return array<int,string> */
    private function collect(string $pattern, string $subject, int $group = 0): array
    {
        if (!preg_match_all($pattern, $subject, $m)) {
            return [];
        }

        $values = $m[$group] ?? $m[0];

        return array_values(array_unique(array_map('strval', $values)));
    }

    private function result(string $key, string $group, string $label, string $status, string $detail, mixed $value): array
    {
        return [
            'key'    => $key,
            'group'  => $group,
            'label'  => $label,
            'status' => $status,       // pass | fail | warn | info
            'detail' => $detail,
            'value'  => $value,
        ];
    }

    private function tally(array &$report): void
    {
        $summary = ['pass' => 0, 'fail' => 0, 'warn' => 0, 'info' => 0];

        foreach ($report['groups'] as $group) {
            foreach ($group['results'] as $result) {
                $summary[$result['status']] = ($summary[$result['status']] ?? 0) + 1;
            }
        }

        $report['summary'] = $summary;
    }

    private function truncate(string $value, int $length): string
    {
        $value = trim((string) preg_replace('/\s+/', ' ', $value));

        return mb_strlen($value) > $length ? mb_substr($value, 0, $length - 1) . '…' : $value;
    }
}
