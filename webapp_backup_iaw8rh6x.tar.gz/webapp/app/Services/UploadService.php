<?php

declare(strict_types=1);

namespace App\Services;

use App\Core\Config;
use App\Core\Database;

/**
 * Evidence upload handling with strict type/size validation.
 *
 * Files are stored outside the webroot (storage/uploads/<execution>/...) and
 * are only ever served through an authenticated PHP endpoint, never directly.
 */
final class UploadService
{
    private const LABELS = [
        'screenshot' => 'Screenshot',
        'attachment' => 'Attachment',
        'creative'   => 'Creative',
        'approval'   => 'Approval file',
        'other'      => 'Other',
    ];

    /**
     * @param array<string,mixed> $file  Single entry from $_FILES
     * @return array<string,mixed> Inserted evidence row
     */
    public static function store(int $executionId, array $file, string $category, ?int $resultId, ?int $userId): array
    {
        if (!isset($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
            throw new \InvalidArgumentException('No file was received. Please try again.');
        }

        $error = (int) ($file['error'] ?? UPLOAD_ERR_OK);

        if ($error !== UPLOAD_ERR_OK) {
            throw new \InvalidArgumentException(self::uploadErrorMessage($error));
        }

        $maxSize = (int) Config::get('uploads.max_file_size', 10485760);

        if ((int) $file['size'] > $maxSize) {
            throw new \InvalidArgumentException(sprintf(
                'File "%s" exceeds the %s limit.',
                $file['name'],
                self::humanSize($maxSize)
            ));
        }

        $ext      = strtolower(pathinfo((string) $file['name'], PATHINFO_EXTENSION));
        $allowed  = (array) Config::get('uploads.allowed', []);

        if (!isset($allowed[$ext])) {
            throw new \InvalidArgumentException(sprintf(
                'File type ".%s" is not allowed. Allowed: PNG, JPG, PDF, EML, MSG.',
                $ext
            ));
        }

        $detectedMime = self::detectMime($file['tmp_name'], $ext);
        $declaredMime = (string) ($file['type'] ?? '');
        $accepted     = $allowed[$ext];

        if (!in_array($detectedMime, $accepted, true) && !in_array($declaredMime, $accepted, true)) {
            throw new \InvalidArgumentException(sprintf(
                'File "%s" failed content verification (detected %s).',
                $file['name'],
                $detectedMime
            ));
        }

        $execution = Database::instance()->fetch('SELECT id FROM test_executions WHERE id = ?', [$executionId]);

        if ($execution === null) {
            throw new \InvalidArgumentException('Target execution does not exist.');
        }

        $count = (int) Database::instance()->value(
            'SELECT COUNT(*) FROM evidence_files WHERE execution_id = ?',
            [$executionId]
        );

        if ($count >= (int) Config::get('uploads.max_files', 40)) {
            throw new \InvalidArgumentException('This execution has reached the evidence file limit.');
        }

        $root      = rtrim((string) Config::get('uploads.dir'), '/');
        $directory = $root . '/' . $executionId;

        if (!is_dir($directory) && !mkdir($directory, 0775, true) && !is_dir($directory)) {
            throw new \RuntimeException('Unable to create the upload directory.');
        }

        $storedName = sprintf('%s-%s.%s', date('YmdHis'), bin2hex(random_bytes(6)), $ext);
        $target     = $directory . '/' . $storedName;

        if (!move_uploaded_file($file['tmp_name'], $target)) {
            throw new \RuntimeException('Unable to store the uploaded file.');
        }

        @chmod($target, 0640);

        $id = Database::instance()->insert(
            'INSERT INTO evidence_files
                (execution_id, result_id, category, original_name, stored_name, mime_type, extension, file_size, uploaded_by)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [
                $executionId,
                $resultId,
                $category,
                mb_substr((string) $file['name'], 0, 250),
                $storedName,
                $detectedMime !== 'application/octet-stream' ? $detectedMime : ($declaredMime ?: 'application/octet-stream'),
                $ext,
                (int) filesize($target),
                $userId,
            ]
        );

        return self::find($id) ?? [];
    }

    public static function find(int $id): ?array
    {
        return Database::instance()->fetch(
            'SELECT e.*, u.name AS uploaded_by_name
             FROM evidence_files e
             LEFT JOIN users u ON u.id = e.uploaded_by
             WHERE e.id = ?',
            [$id]
        );
    }

    /** @return array<int,array<string,mixed>> */
    public static function forExecution(int $executionId): array
    {
        return Database::instance()->fetchAll(
            'SELECT e.*, u.name AS uploaded_by_name, r.item_label AS result_label
             FROM evidence_files e
             LEFT JOIN users u ON u.id = e.uploaded_by
             LEFT JOIN test_results r ON r.id = e.result_id
             WHERE e.execution_id = ?
             ORDER BY e.created_at DESC, e.id DESC',
            [$executionId]
        );
    }

    /** @return array<int,array<string,mixed>> */
    public static function forResult(int $resultId): array
    {
        return Database::instance()->fetchAll(
            'SELECT e.*, u.name AS uploaded_by_name
             FROM evidence_files e
             LEFT JOIN users u ON u.id = e.uploaded_by
             WHERE e.result_id = ?
             ORDER BY e.created_at ASC',
            [$resultId]
        );
    }

    public static function path(array $file): string
    {
        return rtrim((string) Config::get('uploads.dir'), '/') . '/' . (int) $file['execution_id'] . '/' . $file['stored_name'];
    }

    public static function delete(int $id): bool
    {
        $file = self::find($id);

        if ($file === null) {
            return false;
        }

        $path = self::path($file);

        if (is_file($path)) {
            @unlink($path);
        }

        Database::instance()->run('DELETE FROM evidence_files WHERE id = ?', [$id]);

        return true;
    }

    public static function label(string $category): string
    {
        return self::LABELS[$category] ?? ucfirst($category);
    }

    public static function humanSize(int $bytes): string
    {
        if ($bytes >= 1048576) {
            return number_format($bytes / 1048576, 1) . ' MB';
        }

        if ($bytes >= 1024) {
            return number_format($bytes / 1024, 0) . ' KB';
        }

        return $bytes . ' B';
    }

    public static function isImage(string $ext): bool
    {
        return in_array($ext, ['png', 'jpg', 'jpeg'], true);
    }

    private static function detectMime(string $path, string $ext): string
    {
        // EML/MSG are not reliably sniffed — accept the extension-based family.
        if (in_array($ext, ['eml', 'msg'], true)) {
            $head = (string) file_get_contents($path, false, null, 0, 512);

            if ($ext === 'eml' && (str_contains($head, 'Received:') || str_contains($head, 'MIME-Version') || str_contains($head, 'From:'))) {
                return 'message/rfc822';
            }

            return $ext === 'msg' ? 'application/vnd.ms-outlook' : 'message/rfc822';
        }

        if (function_exists('mime_content_type')) {
            $mime = @mime_content_type($path);

            if (is_string($mime) && $mime !== '') {
                return $mime;
            }
        }

        if (function_exists('finfo_open')) {
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime  = $finfo ? (string) finfo_file($finfo, $path) : '';

            if ($finfo) {
                finfo_close($finfo);
            }

            if ($mime !== '') {
                return $mime;
            }
        }

        return 'application/' . $ext;
    }

    private static function uploadErrorMessage(int $code): string
    {
        return match ($code) {
            UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => 'The file is larger than the server allows.',
            UPLOAD_ERR_PARTIAL   => 'The file was only partially uploaded. Please retry.',
            UPLOAD_ERR_NO_FILE   => 'No file was selected.',
            UPLOAD_ERR_NO_TMP_DIR => 'Server upload directory is missing.',
            UPLOAD_ERR_CANT_WRITE => 'Server could not write the file to disk.',
            UPLOAD_ERR_EXTENSION  => 'A server extension blocked the upload.',
            default              => 'The upload failed (code ' . $code . ').',
        };
    }
}
