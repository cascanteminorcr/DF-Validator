<?php

declare(strict_types=1);

namespace App\Services\Pdf;

/**
 * Minimal, dependency-free PDF writer.
 *
 * Supports exactly what the QA report needs: A4 pages, Helvetica / Helvetica-Bold
 * core fonts, filled rectangles, lines, text and simple word wrapping. Keeping
 * this in-house avoids a Composer install on locked-down hosting and keeps the
 * deployment a straight file copy.
 */
final class PdfDocument
{
    private const PAGE_W = 595.28;   // A4 @ 72dpi
    private const PAGE_H = 841.89;

    /** @var array<int,string> */
    private array $pages = [];

    private string $buffer = '';

    private float $marginLeft = 42.0;
    private float $marginRight = 42.0;
    private float $marginTop = 46.0;
    private float $marginBottom = 52.0;

    private float $y;

    private string $font = 'F1';
    private float $fontSize = 10.0;

    private array $rgb = [0, 0, 0];

    /** Widths (1/1000 em) for Helvetica, ASCII 32-126. */
    private const W_REGULAR = [
        278, 278, 355, 556, 556, 889, 667, 191, 333, 333, 389, 584, 278, 333, 278, 278,
        556, 556, 556, 556, 556, 556, 556, 556, 556, 556, 278, 278, 584, 584, 584, 556,
        1015, 667, 667, 722, 722, 667, 611, 778, 722, 278, 500, 667, 556, 833, 722, 778,
        667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611, 278, 278, 278, 469, 556,
        333, 556, 556, 500, 556, 556, 278, 556, 556, 222, 222, 500, 222, 833, 556, 556,
        556, 556, 333, 500, 278, 556, 500, 722, 500, 500, 500, 334, 260, 334, 584,
    ];

    /** Widths (1/1000 em) for Helvetica-Bold, ASCII 32-126. */
    private const W_BOLD = [
        278, 333, 474, 556, 556, 889, 722, 238, 333, 333, 389, 584, 278, 333, 278, 278,
        556, 556, 556, 556, 556, 556, 556, 556, 556, 556, 333, 333, 584, 584, 584, 611,
        975, 722, 722, 722, 722, 667, 611, 778, 722, 278, 556, 722, 611, 833, 722, 778,
        667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611, 333, 278, 333, 584, 556,
        333, 556, 611, 556, 611, 556, 333, 611, 611, 278, 278, 556, 278, 889, 611, 611,
        611, 611, 389, 556, 333, 611, 556, 778, 556, 556, 500, 389, 280, 389, 584,
    ];

    public function __construct()
    {
        $this->y = self::PAGE_H - $this->marginTop;
        $this->newPage();
    }

    // -----------------------------------------------------------------
    // Layout primitives
    // -----------------------------------------------------------------

    public function newPage(): void
    {
        if ($this->buffer !== '') {
            $this->pages[] = $this->buffer;
        }

        $this->buffer = '';
        $this->y      = self::PAGE_H - $this->marginTop;
    }

    public function contentWidth(): float
    {
        return self::PAGE_W - $this->marginLeft - $this->marginRight;
    }

    public function cursorY(): float
    {
        return $this->y;
    }

    public function setCursorY(float $y): void
    {
        $this->y = $y;
    }

    public function left(): float
    {
        return $this->marginLeft;
    }

    public function right(): float
    {
        return self::PAGE_W - $this->marginRight;
    }

    public function bottomLimit(): float
    {
        return $this->marginBottom;
    }

    public function pageWidth(): float
    {
        return self::PAGE_W;
    }

    public function pageHeight(): float
    {
        return self::PAGE_H;
    }

    public function ensureSpace(float $needed): void
    {
        if ($this->y - $needed < $this->marginBottom) {
            $this->newPage();
        }
    }

    public function space(float $points): void
    {
        $this->y -= $points;
    }

    /** @param array{0:int,1:int,2:int} $rgb */
    public function setColor(array $rgb): void
    {
        $this->rgb = $rgb;
    }

    public function setFont(float $size, bool $bold = false): void
    {
        $this->fontSize = $size;
        $this->font     = $bold ? 'F2' : 'F1';
    }

    public function text(float $x, float $y, string $text): void
    {
        $encoded = $this->encode($text);
        [$r, $g, $b] = $this->rgbToUnit();

        $this->buffer .= sprintf(
            "BT /%s %.2F Tf %.3F %.3F %.3F rg 1 0 0 1 %.2F %.2F Tm (%s) Tj ET\n",
            $this->font,
            $this->fontSize,
            $r,
            $g,
            $b,
            $x,
            $y,
            $encoded
        );
    }

    /** Draw text at the current cursor and move it down. */
    public function line(string $text, float $size = 10.0, bool $bold = false, float $leading = 1.45): void
    {
        $this->setFont($size, $bold);
        $lineHeight = $size * $leading;
        $this->ensureSpace($lineHeight);
        $this->y -= $size;
        $this->text($this->marginLeft, $this->y, $text);
        $this->y -= ($lineHeight - $size);
    }

    /** Word-wrapped paragraph; returns the number of lines drawn. */
    public function paragraph(string $text, float $size = 10.0, bool $bold = false, float $leading = 1.45, ?float $x = null, ?float $width = null): int
    {
        $this->setFont($size, $bold);
        $x       = $x ?? $this->marginLeft;
        $width   = $width ?? $this->contentWidth();
        $lines   = $this->wrap($text, $width, $size, $bold);
        $drawn   = 0;

        foreach ($lines as $line) {
            $lineHeight = $size * $leading;
            $this->ensureSpace($lineHeight);
            $this->y -= $size;
            $this->text($x, $this->y, $line);
            $this->y -= ($lineHeight - $size);
            $drawn++;
        }

        return $drawn;
    }

    public function rect(float $x, float $y, float $w, float $h, array $rgb, bool $fill = true): void
    {
        [$r, $g, $b] = $this->rgbToUnit($rgb);

        if ($fill) {
            $this->buffer .= sprintf("%.3F %.3F %.3F rg %.2F %.2F %.2F %.2F re f\n", $r, $g, $b, $x, $y, $w, $h);
        } else {
            $this->buffer .= sprintf("%.3F %.3F %.3F RG 0.7 w %.2F %.2F %.2F %.2F re S\n", $r, $g, $b, $x, $y, $w, $h);
        }
    }

    public function hline(float $y, array $rgb, float $from = null): void
    {
        [$r, $g, $b] = $this->rgbToUnit($rgb);
        $from ??= $this->marginLeft;
        $this->buffer .= sprintf("%.3F %.3F %.3F RG 0.6 w %.2F %.2F m %.2F %.2F l S\n", $r, $g, $b, $from, $y, $this->right(), $y);
    }

    public function textWidth(string $text, float $size, bool $bold = false): float
    {
        $widths = $bold ? self::W_BOLD : self::W_REGULAR;
        $total  = 0.0;

        foreach ($this->sanitise($text) as $char) {
            $code  = ord($char);
            $total += ($code >= 32 && $code <= 126) ? $widths[$code - 32] : 556;
        }

        return ($total / 1000) * $size;
    }

    /** @return array<int,string> */
    public function wrap(string $text, float $maxWidth, float $size, bool $bold = false): array
    {
        $paragraphs = preg_split('/\r\n|\r|\n/', $text) ?: [''];
        $output     = [];

        foreach ($paragraphs as $paragraph) {
            $words = preg_split('/\s+/', trim($paragraph)) ?: [''];
            $current = '';

            foreach ($words as $word) {
                if ($word === '') {
                    continue;
                }

                // Break absurdly long tokens (URLs) so they never overflow.
                while ($this->textWidth($word, $size, $bold) > $maxWidth) {
                    if ($current !== '') {
                        $output[] = $current;
                        $current  = '';
                    }

                    $cut = max(1, (int) floor(strlen($word) * ($maxWidth / max(1.0, $this->textWidth($word, $size, $bold)))));
                    $output[] = substr($word, 0, $cut);
                    $word     = substr($word, $cut);
                }

                $candidate = $current === '' ? $word : $current . ' ' . $word;

                if ($this->textWidth($candidate, $size, $bold) <= $maxWidth) {
                    $current = $candidate;
                } else {
                    if ($current !== '') {
                        $output[] = $current;
                    }
                    $current = $word;
                }
            }

            $output[] = $current;
        }

        return $output === [] ? [''] : $output;
    }

    // -----------------------------------------------------------------
    // Output
    // -----------------------------------------------------------------

    public function output(): string
    {
        if ($this->buffer !== '' || $this->pages === []) {
            $this->pages[] = $this->buffer;
            $this->buffer  = '';
        }

        $objects = [];

        // 1: Catalog, 2: Pages, 3: F1, 4: F2, then page/content pairs.
        $pageCount   = count($this->pages);
        $firstPageId = 5;
        $kids        = [];

        for ($i = 0; $i < $pageCount; $i++) {
            $kids[] = ($firstPageId + ($i * 2)) . ' 0 R';
        }

        $objects[1] = "<< /Type /Catalog /Pages 2 0 R >>";
        $objects[2] = "<< /Type /Pages /Count $pageCount /Kids [" . implode(' ', $kids) . "] >>";
        $objects[3] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>";
        $objects[4] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>";

        foreach ($this->pages as $index => $content) {
            $pageId    = $firstPageId + ($index * 2);
            $contentId = $pageId + 1;

            $objects[$pageId] = sprintf(
                "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 %.2F %.2F] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents %d 0 R >>",
                self::PAGE_W,
                self::PAGE_H,
                $contentId
            );

            $objects[$contentId] = "<< /Length " . strlen($content) . " >>\nstream\n" . $content . "endstream";
        }

        $pdf     = "%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";
        $offsets = [];

        foreach ($objects as $id => $body) {
            $offsets[$id] = strlen($pdf);
            $pdf .= $id . " 0 obj\n" . $body . "\nendobj\n";
        }

        $xrefOffset = strlen($pdf);
        $maxId      = max(array_keys($objects));

        $pdf .= "xref\n0 " . ($maxId + 1) . "\n";
        $pdf .= "0000000000 65535 f \n";

        for ($id = 1; $id <= $maxId; $id++) {
            $pdf .= isset($offsets[$id])
                ? sprintf("%010d 00000 n \n", $offsets[$id])
                : "0000000000 65535 f \n";
        }

        $pdf .= "trailer\n<< /Size " . ($maxId + 1) . " /Root 1 0 R >>\nstartxref\n" . $xrefOffset . "\n%%EOF";

        return $pdf;
    }

    // -----------------------------------------------------------------
    // Encoding helpers
    // -----------------------------------------------------------------

    /** @return array{0:float,1:float,2:float} */
    private function rgbToUnit(?array $rgb = null): array
    {
        $rgb ??= $this->rgb;

        return [$rgb[0] / 255, $rgb[1] / 255, $rgb[2] / 255];
    }

    /** @return array<int,string> */
    private function sanitise(string $text): array
    {
        $map = [
            '€' => 'EUR', '–' => '-', '—' => '-', '‘' => "'", '’' => "'", '“' => '"', '”' => '"',
            '…' => '...', '•' => '-', '→' => '->', '✓' => 'OK', '✗' => 'X', '≤' => '<=', '≥' => '>=',
            '™' => '(TM)', '®' => '(R)', '©' => '(C)', ' ' => ' ', '×' => 'x',
        ];

        $text = strtr($text, $map);

        // Drop any remaining non-Latin-1 characters.
        $text = (string) preg_replace('/[^\x20-\x7E\xA0-\xFF]/u', '?', $text);

        return $text === '' ? [] : str_split($text);
    }

    private function encode(string $text): string
    {
        $sanitised = implode('', $this->sanitise($text));
        $sanitised = str_replace(['\\', '(', ')', "\r", "\n"], ['\\\\', '\\(', '\\)', ' ', ' '], $sanitised);

        return $sanitised;
    }
}
