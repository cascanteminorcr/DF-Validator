<?php

declare(strict_types=1);

namespace App\Services;

/**
 * Single source of truth for the manual QA checklist.
 *
 * Section keys and item keys are stable identifiers persisted in
 * test_results.item_key, so labels can be reworded without losing history.
 */
final class ChecklistCatalog
{
    public const SECTIONS = [
        'creative'   => 'Creative Section',
        'functional' => 'Functional Section',
    ];

    /** @return array<int,array{key:string,label:string,hint:string}> */
    public static function creative(): array
    {
        return [
            ['key' => 'assets_before_timestamp', 'label' => 'Assets uploaded before developer timestamp', 'hint' => 'Confirm every creative asset was uploaded before the build timestamp recorded in General Information.'],
            ['key' => 'matches_template',        'label' => 'Donation Form matches Template Donation Form', 'hint' => 'Compare the live form against the approved template side by side.'],
            ['key' => 'copy_fidelity',           'label' => 'Copy Fidelity Validation', 'hint' => 'Headline, body copy, legal text and button labels match the copy deck exactly.'],
            ['key' => 'design_fidelity',         'label' => 'Design Fidelity Validation', 'hint' => 'Spacing, typography, colours and imagery match the approved design.'],
            ['key' => 'cloudinary_screenshot',    'label' => 'Cloudinary Screenshot Validation', 'hint' => 'Screenshots hosted on Cloudinary render correctly and are current.'],
            ['key' => 'form_configuration',      'label' => 'Donation Form Configuration Validation', 'hint' => 'Tribute, fees, recurring and amount configuration match the campaign brief.'],
            ['key' => 'vanity_url',              'label' => 'Vanity URL Validation', 'hint' => 'The vanity/short URL resolves to the correct donation form.'],
            ['key' => 'appeal_code',             'label' => 'Appeal Code Validation', 'hint' => 'The appeal code in the page source matches the campaign appeal code.'],
            ['key' => 'page_title',              'label' => 'Page Title Validation', 'hint' => 'Browser tab title follows the client naming convention.'],
            ['key' => 'lambda_test',             'label' => 'Lambda Test Validation', 'hint' => 'Lambda-generated screenshots match the deployed form.'],
            ['key' => 'donation_screenshot',     'label' => 'Donation Test Screenshot Validation', 'hint' => 'Screenshot of the completed donation test is attached.'],
            ['key' => 'og_screenshot',           'label' => 'Open Graph Screenshot Validation', 'hint' => 'Open Graph preview screenshot attached and correct.'],
            ['key' => 'responsive_screenshot',   'label' => 'Responsive Screenshot Validation', 'hint' => 'Mobile, tablet and desktop captures attached.'],
            ['key' => 'embed_code',              'label' => 'Embed Code Validation', 'hint' => 'Generated embed code produces a working form when pasted.'],
            ['key' => 'wordpress_embed',         'label' => 'WordPress Embed Validation', 'hint' => 'Form renders inside the client WordPress page without styling conflicts.'],
            ['key' => 'checklist_attached',      'label' => 'Checklist Attached', 'hint' => 'Completed checklist document is attached to the execution.'],
        ];
    }

    /** @return array<int,array{key:string,label:string,hint:string}> */
    public static function functional(): array
    {
        return [
            ['key' => 'form_functionality',      'label' => 'Donation Form functionality', 'hint' => 'Amount selection, tribute, fees and submit flow all work.'],
            ['key' => 'correct_live_url',        'label' => 'Correct Live URL', 'hint' => 'The URL under test is the intended live form URL.'],
            ['key' => 'url_structure',           'label' => 'URL structure validation', 'hint' => 'URL is lower-case, hyphenated, descriptive and parameter-clean.'],
            ['key' => 'internal_links',          'label' => 'Internal link behavior', 'hint' => 'Internal links open in the same tab.'],
            ['key' => 'external_links',          'label' => 'External link behavior', 'hint' => 'External links open in a new tab with rel="noopener".'],
            ['key' => 'ssl',                     'label' => 'SSL validation', 'hint' => 'Valid certificate, no security warnings, HTTPS enforced.'],
            ['key' => 'client_logo',             'label' => 'Client logo redirects correctly', 'hint' => 'Logo click lands on the correct client homepage.'],
            ['key' => 'destination_links',       'label' => 'Correct destination links', 'hint' => 'All navigation and legal links point to the correct destinations.'],
            ['key' => 'incognito',               'label' => 'Incognito validation', 'hint' => 'Form loads and functions in a private window without cached data.'],
            ['key' => 'tribute',                 'label' => 'Tribute section functionality', 'hint' => 'Tribute/tribute card fields validate and persist to the transaction.'],
            ['key' => 'utm_parameters',          'label' => 'UTM parameter validation', 'hint' => 'UTM parameters persist through the checkout and into analytics.'],
            ['key' => 'alt_text',                'label' => 'Image alt text validation', 'hint' => 'Every content image carries meaningful alt text.'],
            ['key' => 'gtm',                     'label' => 'GTM validation', 'hint' => 'GTM container fires and donation events are captured.'],
            ['key' => 'donate_without_data',     'label' => 'Donate button validation without data', 'hint' => 'Empty submit triggers validation instead of a server error.'],
            ['key' => 'fake_card',               'label' => 'Fake card testing validation', 'hint' => 'Declined/fake cards surface a friendly error and no transaction is created.'],
            ['key' => 'card_length',             'label' => 'Card length validation', 'hint' => 'Short and over-long card numbers are rejected client-side.'],
            ['key' => 'other_amount',            'label' => 'Other Amount validation', 'hint' => 'Custom amount accepts valid values and blocks zero/negative/non-numeric input.'],
            ['key' => 'recurring',               'label' => 'Recurring donation validation', 'hint' => 'Monthly recurring selection persists and creates a recurring schedule.'],
            ['key' => 'donation_fees',           'label' => 'Donation fees validation', 'hint' => 'Fee checkbox recalculates totals correctly.'],
            ['key' => 'amount_reflection',       'label' => 'Amount reflection validation', 'hint' => 'Selected amount is reflected on every subsequent step.'],
            ['key' => 'querystring_amount',      'label' => 'Querystring amount validation', 'hint' => '?amount= pre-fills the form and is validated against allowed ranges.'],
            ['key' => 'one_time_monthly',        'label' => 'One Time / Monthly amount validation', 'hint' => 'Toggling frequency recalculates and reflects the correct amount.'],
            ['key' => 'checkout_amount',         'label' => 'Checkout amount validation', 'hint' => 'Checkout total equals the donated amount plus any selected fees.'],
            ['key' => 'company_card',            'label' => 'Donation test with company card', 'hint' => 'Low-value real donation completes with the company test card.'],
            ['key' => 'transaction_registration', 'label' => 'Transaction registration validation', 'hint' => 'Transaction is registered in the payment gateway and CRM.'],
        ];
    }

    /** @return array<int,array{section:string,key:string,label:string,hint:string}> */
    public static function all(): array
    {
        $items = [];

        foreach (self::creative() as $item) {
            $items[] = ['section' => 'creative'] + $item;
        }

        foreach (self::functional() as $item) {
            $items[] = ['section' => 'functional'] + $item;
        }

        return $items;
    }

    public static function totalItems(): int
    {
        return count(self::creative()) + count(self::functional());
    }

    public static function sectionLabel(string $section): string
    {
        return self::SECTIONS[$section] ?? ucfirst($section);
    }

    /** Items marked as "must have a comment when failing" (all of them, by policy). */
    public static function requiresCommentOnFail(): bool
    {
        return true;
    }
}
