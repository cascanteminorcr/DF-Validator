<?php

declare(strict_types=1);

namespace App\Services;

use App\Core\Config;
use App\Core\Database;
use App\Models\EvidenceFile;
use App\Models\Execution;
use App\Models\TestResult;

/**
 * Builds the PDF QA report and the CSV export from a stored execution.
 */
final class ReportService
{
    private const INK        = [24, 28, 38];
    private const INK_SOFT   = [92, 102, 120];
    private const LINE       = [214, 220, 230];
    private const PASS       = [22, 128, 92];
    private const FAIL       = [190, 45, 60];
    private const WARN       = [176, 116, 20];
    private const NA         = [120, 128, 140];
    private const ACCENT     = [99, 102, 241];
    private const HEADER_BG  = [17, 20, 28];

    /**
     * Generate and store the PDF report for an execution.
     *
     * @return array{path:string,file_name:string,size:int,report_id:int}
     */
    public static function generatePdf(int $executionId, ?int $userId): array
    {
        $execution = self::payload($executionId);

        if ($execution === null) {
            throw new \InvalidArgumentException('Execution not found.');
        }

        $pdf = new Pdf\PdfDocument();

        self::drawCover($pdf, $execution);
        self::drawSummary($pdf, $execution);
        self::drawGeneralInfo($pdf, $execution);
        self::drawAutomation($pdf, $execution);
        self::drawChecklist($pdf, $execution, 'creative');
        self::drawChecklist($pdf, $execution, 'functional');
        self::drawFailures($pdf, $execution);
        self::drawEvidence($pdf, $execution);
        self::drawApproval($pdf, $execution);
        self::stampFooters($pdf);

        $binary = $pdf->output();

        $dir = rtrim((string) Config::get('reports.dir'), '/');

        if (!is_dir($dir) && !mkdir($dir, 0775, true) && !is_dir($dir)) {
            throw new \RuntimeException('Unable to create the reports directory.');
        }

        $fileName = sprintf(
            'QA-Report-%s-%s.pdf',
            preg_replace('/[^A-Za-z0-9]+/', '-', (string) $execution['form_name']),
            date('Ymd-His')
        );
        $fileName = trim(preg_replace('/-+/', '-', $fileName), '-');
        $path     = $dir . '/' . $executionId . '-' . $fileName;

        if (file_put_contents($path, $binary) === false) {
            throw new \RuntimeException('Unable to write the PDF report to disk.');
        }

        @chmod($path, 0644);

        $reportId = Database::instance()->insert(
            'INSERT INTO reports (execution_id, report_type, file_name, file_path, file_size, generated_by)
             VALUES (?, ?, ?, ?, ?, ?)',
            [$executionId, 'pdf', $fileName, $path, strlen($binary), $userId]
        );

        return ['path' => $path, 'file_name' => $fileName, 'size' => strlen($binary), 'report_id' => $reportId];
    }

    /** CSV export of every checklist row plus execution metadata. */
    public static function generateCsv(int $executionId): array
    {
        $execution = self::payload($executionId);

        if ($execution === null) {
            throw new \InvalidArgumentException('Execution not found.');
        }

        $handle = fopen('php://temp', 'r+');

        fputcsv($handle, [
            'Execution ID', 'Client', 'Campaign', 'Donation Form', 'Environment',
            'Form URL', 'QA Analyst', 'Test Date', 'Browser', 'Execution Status',
            'Section', 'Checklist Item', 'Result', 'Comment', 'Evidence Files', 'Last Updated',
        ], ',', '"', '\\');

        foreach ($execution['results'] as $row) {
            fputcsv($handle, [
                $executionId,
                $execution['client_name'],
                $execution['campaign_name'],
                $execution['form_name'],
                ucfirst((string) $execution['environment']),
                $execution['form_url'],
                $execution['qa_analyst_name'],
                (string) $execution['test_date'],
                (string) $execution['browser_used'],
                Execution::STATUSES[$execution['status']] ?? $execution['status'],
                ChecklistCatalog::sectionLabel((string) $row['section']),
                $row['item_label'],
                strtoupper((string) $row['status']),
                (string) $row['comment'],
                (int) ($row['evidence_count'] ?? 0),
                (string) $row['updated_at'],
            ], ',', '"', '\\');
        }

        rewind($handle);
        $csv = (string) stream_get_contents($handle);
        fclose($handle);

        $fileName = sprintf(
            'QA-Export-%s-%s.csv',
            preg_replace('/[^A-Za-z0-9]+/', '-', (string) $execution['form_name']),
            date('Ymd-His')
        );

        return ['csv' => $csv, 'file_name' => trim(preg_replace('/-+/', '-', $fileName), '-')];
    }

    /** Full data payload used by the report, print view and CSV. */
    public static function payload(int $executionId): ?array
    {
        $execution = Execution::find($executionId);

        if ($execution === null) {
            return null;
        }

        $execution['results']  = TestResult::forExecution($executionId);
        $execution['checklist'] = TestResult::checklist($executionId);
        $execution['evidence']  = EvidenceFile::forExecution($executionId);
        $execution['auto']      = json_decode((string) ($execution['auto_results'] ?? ''), true) ?: null;

        return $execution;
    }

    // =================================================================
    // PDF sections
    // =================================================================

    private static function drawCover(Pdf\PdfDocument $pdf, array $e): void
    {
        $pdf->rect(0, $pdf->pageHeight() - 132, $pdf->pageWidth(), 132, self::HEADER_BG);
        $pdf->rect(0, $pdf->pageHeight() - 136, $pdf->pageWidth(), 4, self::ACCENT);

        $pdf->setColor([255, 255, 255]);
        $pdf->setFont(9.5, true);
        $pdf->text($pdf->left(), $pdf->pageHeight() - 48, 'DONATION FORM QA VALIDATOR');

        $pdf->setFont(23, true);
        $pdf->text($pdf->left(), $pdf->pageHeight() - 78, 'QA Execution Report');

        $pdf->setFont(10.5, false);
        $pdf->setColor([176, 184, 200]);
        $pdf->text($pdf->left(), $pdf->pageHeight() - 100, self::clean($e['client_name']) . ' / ' . self::clean($e['campaign_name']));
        $pdf->text($pdf->left(), $pdf->pageHeight() - 116, 'Execution #' . (int) $e['id'] . '  |  ' . ucfirst((string) $e['environment']) . '  |  ' . self::clean((string) $e['form_name']));

        $pdf->setCursorY($pdf->pageHeight() - 168);
        $pdf->setColor(self::INK);

        // Status + score band
        $statusLabel = strtoupper(Execution::STATUSES[$e['status']] ?? (string) $e['status']);
        $scoreText   = number_format((float) $e['pass_rate'], 1) . '% pass rate';

        $pdf->setFont(8.5, true);
        $pdf->setColor(self::INK_SOFT);
        $pdf->text($pdf->left(), $pdf->cursorY(), 'OVERALL RESULT');
        $pdf->text($pdf->left() + 260, $pdf->cursorY(), 'APPROVAL STATUS');
        $pdf->space(18);

        $pdf->setFont(15, true);
        $pdf->setColor($e['fail_count'] > 0 ? self::FAIL : self::PASS);
        $pdf->text($pdf->left(), $pdf->cursorY(), $scoreText);

        $pdf->setColor($e['approval_status'] === 'approved' ? self::PASS : ($e['approval_status'] === 'rejected' ? self::FAIL : self::WARN));
        $pdf->text($pdf->left() + 260, $pdf->cursorY(), ucfirst((string) $e['approval_status']));

        $pdf->space(20);
        $pdf->setColor(self::INK_SOFT);
        $pdf->setFont(8.5);
        $pdf->text($pdf->left(), $pdf->cursorY(), 'WORKFLOW STATE: ' . $statusLabel);
        $pdf->text($pdf->left() + 260, $pdf->cursorY(), 'REPORT GENERATED: ' . gmdate('d M Y H:i') . ' UTC');

        $pdf->space(26);
        $pdf->setColor(self::INK);

        foreach ([
            'QA Analyst'   => $e['qa_analyst_name'],
            'Test Date'    => (string) $e['test_date'],
            'Browser'      => (string) $e['browser_used'],
            'Build'        => (string) ($e['build_timestamp'] ?? 'not recorded'),
        ] as $label => $value) {
            $pdf->setFont(9);
            $pdf->setColor(self::INK_SOFT);
            $pdf->text($pdf->left(), $pdf->cursorY(), strtoupper($label));
            $pdf->setColor(self::INK);
            $pdf->text($pdf->left() + 90, $pdf->cursorY(), self::clean((string) $value));
            $pdf->space(15);
        }
    }

    private static function drawSummary(Pdf\PdfDocument $pdf, array $e): void
    {
        $pdf->ensureSpace(150);
        self::sectionTitle($pdf, 'Execution Summary');

        $items = [
            ['Passed', (string) $e['pass_count'], self::PASS],
            ['Failed', (string) $e['fail_count'], self::FAIL],
            ['N/A', (string) $e['na_count'], self::NA],
            ['Untested', (string) $e['untested_count'], self::WARN],
        ];

        $cardWidth = ($pdf->contentWidth() - 24) / 4;
        $startY    = $pdf->cursorY() - 6;
        $x         = $pdf->left();

        foreach ($items as $item) {
            [$label, $value, $color] = $item;

            $pdf->rect($x, $startY - 52, $cardWidth, 52, [246, 247, 250]);
            $pdf->rect($x, $startY - 52, 3, 52, $color);

            $pdf->setColor($color);
            $pdf->setFont(17, true);
            $pdf->text($x + 12, $startY - 26, $value);

            $pdf->setColor(self::INK_SOFT);
            $pdf->setFont(8);
            $pdf->text($x + 12, $startY - 42, strtoupper($label));

            $x += $cardWidth + 8;
        }

        $pdf->setCursorY($startY - 62);

        $decided  = (int) $e['pass_count'] + (int) $e['fail_count'];
        $coverage = (int) $e['total_items'] > 0
            ? round((((int) $e['total_items'] - (int) $e['untested_count']) / (int) $e['total_items']) * 100, 1)
            : 0.0;

        $pdf->setFont(9);
        $pdf->setColor(self::INK);
        $pdf->paragraph(sprintf(
            'Checklist coverage: %s%% of %d items decided. Pass rate is calculated over %d decided items (pass + fail); N/A and untested items are excluded from the score.',
            number_format($coverage, 1),
            (int) $e['total_items'],
            $decided
        ));
        $pdf->space(6);
    }

    private static function drawGeneralInfo(Pdf\PdfDocument $pdf, array $e): void
    {
        $pdf->ensureSpace(210);
        self::sectionTitle($pdf, 'General Information');

        $rows = [
            ['Client Name', $e['client_name']],
            ['Campaign Name', $e['campaign_name']],
            ['Donation Form Name', $e['form_name']],
            ['Environment', ucfirst((string) $e['environment'])],
            ['Donation Form URL', $e['form_url']],
            ['Template URL', $e['template_url'] ?: 'not supplied'],
            ['QA Analyst', $e['qa_analyst_name']],
            ['Build Timestamp', (string) ($e['build_timestamp'] ?? 'not recorded')],
            ['Browser Used', (string) $e['browser_used']],
            ['Test Date', (string) $e['test_date']],
        ];

        $labelWidth = 132;

        foreach ($rows as [$label, $value]) {
            $value = self::clean((string) $value);
            $lines = $pdf->wrap($value, $pdf->contentWidth() - $labelWidth, 9);

            $pdf->ensureSpace(14 * count($lines) + 4);

            foreach ($lines as $index => $line) {
                $pdf->setFont(8.5, false);
                $pdf->setColor(self::INK_SOFT);

                if ($index === 0) {
                    $pdf->text($pdf->left(), $pdf->cursorY() - 9, $label);
                }

                $pdf->setColor(self::INK);
                $pdf->setFont(9);
                $pdf->text($pdf->left() + $labelWidth, $pdf->cursorY() - 9, $line);
                $pdf->space(13);
            }

            $pdf->hline($pdf->cursorY() + 2, self::LINE);
            $pdf->space(3);
        }

        $pdf->space(4);
    }

    private static function drawAutomation(Pdf\PdfDocument $pdf, array $e): void
    {
        $auto = $e['auto'] ?? null;

        $pdf->ensureSpace(120);
        self::sectionTitle($pdf, 'Automated Validation Results');

        if (!is_array($auto) || empty($auto['groups'])) {
            $pdf->setFont(9);
            $pdf->setColor(self::INK_SOFT);
            $pdf->paragraph('No automated validation snapshot was captured for this execution.');
            $pdf->space(8);

            return;
        }

        $summary = $auto['summary'] ?? [];
        $pdf->setFont(9);
        $pdf->setColor(self::INK);
        $pdf->paragraph(sprintf(
            'Executed %s UTC against %s (HTTP %d, %d ms). %d passed, %d failed, %d warnings.',
            gmdate('d M Y H:i', strtotime((string) ($auto['checked_at'] ?? 'now'))),
            self::clean((string) ($auto['final_url'] ?? $auto['url'] ?? '')),
            (int) ($auto['http_status'] ?? 0),
            (int) ($auto['elapsed_ms'] ?? 0),
            (int) ($summary['pass'] ?? 0),
            (int) ($summary['fail'] ?? 0),
            (int) ($summary['warn'] ?? 0)
        ));
        $pdf->space(4);

        foreach ($auto['groups'] as $group) {
            $pdf->ensureSpace(50);
            $pdf->setFont(9, true);
            $pdf->setColor(self::INK);
            $pdf->text($pdf->left(), $pdf->cursorY() - 10, self::clean((string) ($group['label'] ?? '')));
            $pdf->space(14);

            foreach ($group['results'] as $result) {
                [$label, $color] = self::autoBadge((string) $result['status']);
                $detailLines = $pdf->wrap(self::clean((string) $result['detail']), $pdf->contentWidth() - 150, 8.5);

                $pdf->ensureSpace(13 * count($detailLines) + 4);

                $pdf->setColor($color);
                $pdf->setFont(7.5, true);
                $pdf->text($pdf->left() + 4, $pdf->cursorY() - 9, $label);

                $pdf->setColor(self::INK);
                $pdf->setFont(8.5);
                $pdf->text($pdf->left() + 52, $pdf->cursorY() - 9, self::truncate(self::clean((string) $result['label']), 62));

                $pdf->setColor(self::INK_SOFT);
                $pdf->setFont(8);
                $pdf->text($pdf->left() + 300, $pdf->cursorY() - 9, $detailLines[0] ?? '');
                $pdf->space(12);

                foreach (array_slice($detailLines, 1) as $line) {
                    $pdf->text($pdf->left() + 300, $pdf->cursorY() - 8, $line);
                    $pdf->space(10);
                }
            }

            $pdf->space(4);
        }

        $pdf->space(4);
    }

    private static function drawChecklist(Pdf\PdfDocument $pdf, array $e, string $section): void
    {
        $rows = array_values(array_filter(
            $e['results'],
            static fn (array $row): bool => $row['section'] === $section
        ));

        if ($rows === []) {
            return;
        }

        $pdf->ensureSpace(90);
        self::sectionTitle($pdf, ChecklistCatalog::sectionLabel($section));

        $pass = count(array_filter($rows, static fn ($r) => $r['status'] === 'pass'));
        $fail = count(array_filter($rows, static fn ($r) => $r['status'] === 'fail'));

        $pdf->setFont(8.5);
        $pdf->setColor(self::INK_SOFT);
        $pdf->paragraph(sprintf('%d items — %d passed, %d failed.', count($rows), $pass, $fail));
        $pdf->space(4);

        foreach ($rows as $index => $row) {
            [$label, $color] = self::statusBadge((string) $row['status']);
            $commentLines    = $row['comment'] ? $pdf->wrap(self::clean((string) $row['comment']), $pdf->contentWidth() - 60, 8.5) : [];
            $itemLines       = $pdf->wrap(self::clean((string) $row['item_label']), $pdf->contentWidth() - 130, 9);

            $height = 16 + (max(1, count($itemLines)) - 1) * 11 + count($commentLines) * 11;
            $pdf->ensureSpace($height + 6);

            $top = $pdf->cursorY();

            $pdf->setColor(self::INK_SOFT);
            $pdf->setFont(8);
            $pdf->text($pdf->left(), $top - 10, str_pad((string) ($index + 1), 2, '0', STR_PAD_LEFT));

            $pdf->setColor(self::INK);
            $pdf->setFont(9);
            $textY = $top - 10;

            foreach ($itemLines as $line) {
                $pdf->text($pdf->left() + 22, $textY, $line);
                $textY -= 11;
            }

            $pdf->setColor($color);
            $pdf->setFont(7.5, true);
            $pdf->text($pdf->right() - 46, $top - 10, $label);

            if ($commentLines !== []) {
                $pdf->setColor(self::INK_SOFT);
                $pdf->setFont(8.5);

                foreach ($commentLines as $line) {
                    $pdf->text($pdf->left() + 22, $textY, $line);
                    $textY -= 11;
                }
            }

            $evidenceCount = (int) ($row['evidence_count'] ?? 0);

            if ($evidenceCount > 0) {
                $pdf->setColor(self::ACCENT);
                $pdf->setFont(7.5);
                $pdf->text($pdf->right() - 46, $top - 21, $evidenceCount . ' file(s)');
            }

            $pdf->setCursorY($textY - 1);
            $pdf->hline($pdf->cursorY(), self::LINE);
            $pdf->space(4);
        }

        $pdf->space(6);
    }

    private static function drawFailures(Pdf\PdfDocument $pdf, array $e): void
    {
        $failed = array_values(array_filter($e['results'], static fn ($r) => $r['status'] === 'fail'));

        $pdf->ensureSpace(100);
        self::sectionTitle($pdf, 'Failed Items Detail');

        if ($failed === []) {
            $pdf->setFont(9);
            $pdf->setColor(self::PASS);
            $pdf->paragraph('No checklist items failed in this execution.');
            $pdf->space(8);

            return;
        }

        foreach ($failed as $row) {
            $pdf->ensureSpace(60);

            $pdf->setColor(self::FAIL);
            $pdf->setFont(9.5, true);
            $pdf->paragraph(self::clean((string) $row['item_label']), 9.5, true);

            $pdf->setColor(self::INK_SOFT);
            $pdf->setFont(8);
            $pdf->paragraph(ChecklistCatalog::sectionLabel((string) $row['section']) . '  •  ' . strtoupper((string) $row['status']), 8);
            $pdf->space(2);

            $pdf->setColor(self::INK);
            $pdf->setFont(9);
            $pdf->paragraph('Tester comment: ' . self::clean((string) ($row['comment'] ?: 'no comment recorded')), 9);
            $pdf->space(4);
            $pdf->hline($pdf->cursorY(), self::LINE);
            $pdf->space(8);
        }
    }

    private static function drawEvidence(Pdf\PdfDocument $pdf, array $e): void
    {
        $pdf->ensureSpace(90);
        self::sectionTitle($pdf, 'Evidence References');

        if (empty($e['evidence'])) {
            $pdf->setFont(9);
            $pdf->setColor(self::INK_SOFT);
            $pdf->paragraph('No evidence files were attached to this execution.');
            $pdf->space(8);

            return;
        }

        foreach ($e['evidence'] as $index => $file) {
            $pdf->ensureSpace(18);
            $pdf->setColor(self::INK);
            $pdf->setFont(8.5);
            $line = sprintf(
                '%02d. [%s] %s — %s, %s',
                $index + 1,
                strtoupper((string) $file['extension']),
                self::truncate(self::clean((string) $file['original_name']), 54),
                UploadService::humanSize((int) $file['file_size']),
                UploadService::label((string) $file['category'])
            );
            $pdf->text($pdf->left(), $pdf->cursorY() - 9, $line);
            $pdf->space(13);

            $pdf->setColor(self::INK_SOFT);
            $pdf->setFont(7.5);
            $pdf->text($pdf->left() + 16, $pdf->cursorY() - 7, 'stored as ' . self::clean((string) $file['stored_name']));
            $pdf->space(11);
        }

        $pdf->space(6);
    }

    private static function drawApproval(Pdf\PdfDocument $pdf, array $e): void
    {
        $pdf->ensureSpace(140);
        self::sectionTitle($pdf, 'QA Approval');

        $rows = [
            ['Account Manager', $e['am_name'] ?: 'not recorded'],
            ['Approval Status', ucfirst((string) $e['approval_status'])],
            ['Approved At', $e['approved_at'] ?: '—'],
            ['Approval Message', $e['approval_message'] ?: '—'],
            ['QA Notes', $e['qa_notes'] ?: '—'],
        ];

        foreach ($rows as [$label, $value]) {
            $lines = $pdf->wrap(self::clean((string) $value), $pdf->contentWidth() - 140, 9);
            $pdf->ensureSpace(13 * count($lines) + 4);

            $pdf->setColor(self::INK_SOFT);
            $pdf->setFont(8.5);
            $pdf->text($pdf->left(), $pdf->cursorY() - 9, $label);

            $pdf->setColor(self::INK);
            $pdf->setFont(9);
            foreach ($lines as $line) {
                $pdf->text($pdf->left() + 140, $pdf->cursorY() - 9, $line);
                $pdf->space(13);
            }
        }

        $pdf->space(16);

        // Signature blocks
        $pdf->ensureSpace(60);
        $y = $pdf->cursorY();

        $pdf->setColor(self::LINE);
        $pdf->hline($y, self::LINE, $pdf->left());
        $pdf->hline($y, self::LINE, $pdf->left() + 250);

        $pdf->setColor(self::INK_SOFT);
        $pdf->setFont(8);
        $pdf->text($pdf->left(), $y - 12, 'QA Analyst: ' . self::truncate(self::clean((string) $e['qa_analyst_name']), 40));
        $pdf->text($pdf->left() + 250, $y - 12, 'Approved by: ' . self::truncate(self::clean((string) ($e['am_name'] ?: 'pending')), 40));

        $pdf->space(26);
    }

    private static function stampFooters(Pdf\PdfDocument $pdf): void
    {
        // Footers are stamped by appending text to each page after layout.
        // Re-opening pages is not supported by the writer, so the footer is
        // drawn on the first page only for page numbering context.
        $pdf->setCursorY($pdf->bottomLimit() + 24);
        $pdf->setColor(self::INK_SOFT);
        $pdf->setFont(7.5);
        $pdf->text($pdf->left(), 24, 'Generated by Donation Form QA Validator — ' . gmdate('d M Y H:i') . ' UTC');
        $pdf->text($pdf->right() - 90, 24, 'CONFIDENTIAL — Internal QA');
    }

    private static function sectionTitle(Pdf\PdfDocument $pdf, string $title): void
    {
        $pdf->ensureSpace(40);
        $pdf->space(4);
        $pdf->setColor(self::ACCENT);
        $pdf->setFont(11, true);
        $pdf->text($pdf->left(), $pdf->cursorY() - 12, strtoupper($title));
        $pdf->space(16);
        $pdf->hline($pdf->cursorY() + 4, self::ACCENT);
        $pdf->space(8);
        $pdf->setColor(self::INK);
    }

    /** @return array{0:string,1:array{0:int,1:int,2:int}} */
    private static function statusBadge(string $status): array
    {
        return match ($status) {
            'pass' => ['PASS', self::PASS],
            'fail' => ['FAIL', self::FAIL],
            'na'   => ['N/A', self::NA],
            default => ['OPEN', self::WARN],
        };
    }

    /** @return array{0:string,1:array{0:int,1:int,2:int}} */
    private static function autoBadge(string $status): array
    {
        return match ($status) {
            'pass' => ['PASS', self::PASS],
            'fail' => ['FAIL', self::FAIL],
            'warn' => ['WARN', self::WARN],
            default => ['INFO', self::INK_SOFT],
        };
    }

    private static function clean(string $value): string
    {
        $value = html_entity_decode(strip_tags($value), ENT_QUOTES | ENT_HTML5, 'UTF-8');

        return trim((string) preg_replace('/\s+/', ' ', $value));
    }

    private static function truncate(string $value, int $length): string
    {
        return mb_strlen($value) > $length ? mb_substr($value, 0, $length - 1) . '...' : $value;
    }
}
