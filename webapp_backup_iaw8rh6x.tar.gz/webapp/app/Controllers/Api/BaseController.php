<?php

declare(strict_types=1);

namespace App\Controllers\Api;

use App\Core\Auth;
use App\Core\Response;
use App\Core\Session;

/**
 * Shared helpers for API controllers.
 */
abstract class BaseController
{
    protected function input(): array
    {
        return \App\Core\Request::json();
    }

    /** Load an execution or abort with 404. */
    protected function findExecution(int $id, bool $requireEdit = false): array
    {
        $execution = \App\Models\Execution::find($id);

        if ($execution === null) {
            Response::error('Execution not found.', 404);
        }

        if ($requireEdit && !Auth::canEditExecution($execution)) {
            Response::error('You can only modify executions you own.', 403);
        }

        return $execution;
    }

    protected function audit(string $action, ?int $executionId = null): void
    {
        error_log(sprintf(
            '[DFQA] %s by user#%s (%s) on execution#%s from %s',
            $action,
            Auth::id() ?? 'anon',
            Auth::role() ?? 'guest',
            $executionId ?? '-',
            $_SERVER['REMOTE_ADDR'] ?? 'unknown'
        ));
    }

    protected function csrfToken(): string
    {
        return \App\Core\Csrf::token();
    }
}
