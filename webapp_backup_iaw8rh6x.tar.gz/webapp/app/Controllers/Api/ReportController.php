<?php

declare(strict_types=1);

namespace App\Controllers\Api;

use App\Core\Auth;
use App\Core\Response;
use App\Models\Execution;
use App\Models\Report;
use App\Services\ReportService;

final class ReportController extends BaseController
{
    /** Generate a PDF report and store it. */
    public function generatePdf(array $params): void
    {
        $execution = $this->findExecution((int) $params['id']);

        try {
            $report = ReportService::generatePdf((int) $execution['id'], Auth::id());
        } catch (\Throwable $e) {
            error_log('[DFQA] pdf generation failed: ' . $e->getMessage());
            Response::error('The PDF report could not be generated.', 500);
        }

        $this->audit('report.pdf', (int) $execution['id']);

        Response::ok([
            'report' => [
                'id'        => $report['report_id'],
                'file_name' => $report['file_name'],
                'file_size' => $report['size'],
                'download_url' => '/api/reports/' . $report['report_id'] . '/download',
            ],
        ]);
    }

    /** Generate the PDF on the fly and stream it (no DB record). */
    public function streamPdf(array $params): void
    {
        $execution = $this->findExecution((int) $params['id']);

        try {
            $report = ReportService::generatePdf((int) $execution['id'], Auth::id());
        } catch (\Throwable $e) {
            error_log('[DFQA] pdf stream failed: ' . $e->getMessage());
            Response::error('The PDF report could not be generated.', 500);
        }

        $this->sendFile($report['path'], $report['file_name'], 'application/pdf');
    }

    /** CSV export streamed directly. */
    public function exportCsv(array $params): void
    {
        $execution = $this->findExecution((int) $params['id']);

        try {
            $csv = ReportService::generateCsv((int) $execution['id']);
        } catch (\Throwable $e) {
            error_log('[DFQA] csv export failed: ' . $e->getMessage());
            Response::error('The CSV export could not be generated.', 500);
        }

        $this->audit('report.csv', (int) $execution['id']);

        while (ob_get_level() > 0) {
            ob_end_clean();
        }

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $csv['file_name'] . '"');
        header('Content-Length: ' . strlen($csv['csv']));
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: no-store');

        echo "\xEF\xBB\xBF"; // BOM so Excel opens UTF-8 correctly
        echo $csv['csv'];
        exit;
    }

    /** Download a previously generated report. */
    public function download(array $params): void
    {
        $report = Report::find((int) $params['id']);

        if ($report === null) {
            Response::error('Report not found.', 404);
        }

        $this->findExecution((int) $report['execution_id']);

        if (!is_file($report['file_path'])) {
            Response::error('The stored report file no longer exists. Please regenerate it.', 410);
        }

        $mime = $report['report_type'] === 'csv' ? 'text/csv' : 'application/pdf';

        $this->sendFile($report['file_path'], $report['file_name'], $mime);
    }

    public function destroy(array $params): void
    {
        Auth::requireRole(Auth::ROLE_ADMIN, Auth::ROLE_LEAD);

        $report = Report::find((int) $params['id']);

        if ($report === null) {
            Response::error('Report not found.', 404);
        }

        Report::delete((int) $report['id']);

        Response::ok(['deleted' => true]);
    }

    private function sendFile(string $path, string $fileName, string $mime): never
    {
        if (!is_file($path)) {
            Response::error('File not found.', 404);
        }

        while (ob_get_level() > 0) {
            ob_end_clean();
        }

        header('Content-Type: ' . $mime);
        header('Content-Length: ' . (string) filesize($path));
        header('Content-Disposition: attachment; filename="' . $fileName . '"');
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: no-store');

        readfile($path);
        exit;
    }
}
