<?php

declare(strict_types=1);

namespace App\Controllers\Api;

use App\Core\Auth;
use App\Core\Response;
use App\Core\Security;
use App\Core\Validator;
use App\Models\Catalog;
use App\Models\Execution;

/**
 * Client / campaign / donation-form catalogue used by the execution wizard.
 */
final class CatalogController extends BaseController
{
    public function index(): void
    {
        Response::ok([
            'clients'      => Catalog::clients(),
            'campaigns'    => Catalog::campaigns(),
            'forms'        => Catalog::forms(),
            'environments' => Execution::ENVIRONMENTS,
            'browsers'     => Execution::BROWSERS,
        ]);
    }

    public function createClient(): void
    {
        Auth::requireRole(Auth::ROLE_ADMIN, Auth::ROLE_LEAD);
        $data = $this->input();

        Validator::make($data)
            ->required('name', 'Client name')
            ->maxLength('name', 'Client name', 160)
            ->maxLength('code', 'Client code', 40)
            ->requireValid();

        $id = Catalog::createClient(
            Security::clean((string) $data['name']),
            isset($data['code']) ? Security::clean((string) $data['code']) : null,
            isset($data['am_name']) ? Security::clean((string) $data['am_name']) : null
        );

        Response::ok(['client' => Catalog::client($id)]);
    }

    public function updateClient(array $params): void
    {
        Auth::requireRole(Auth::ROLE_ADMIN, Auth::ROLE_LEAD);
        $id = (int) $params['id'];

        if (Catalog::client($id) === null) {
            Response::error('Client not found.', 404);
        }

        $data = $this->input();

        Validator::make($data)
            ->required('name', 'Client name')
            ->maxLength('name', 'Client name', 160)
            ->requireValid();

        Catalog::updateClient(
            $id,
            Security::clean((string) $data['name']),
            isset($data['code']) ? Security::clean((string) $data['code']) : null,
            isset($data['am_name']) ? Security::clean((string) $data['am_name']) : null,
            !empty($data['is_active'])
        );

        Response::ok(['client' => Catalog::client($id)]);
    }

    public function createCampaign(): void
    {
        Auth::requireRole(Auth::ROLE_ADMIN, Auth::ROLE_LEAD);
        $data = $this->input();

        Validator::make($data)
            ->required('client_id', 'Client')
            ->required('name', 'Campaign name')
            ->maxLength('name', 'Campaign name', 160)
            ->requireValid();

        if (Catalog::client((int) $data['client_id']) === null) {
            Response::error('Select a valid client.', 422);
        }

        $id = Catalog::createCampaign(
            (int) $data['client_id'],
            Security::clean((string) $data['name']),
            isset($data['code']) ? Security::clean((string) $data['code']) : null
        );

        Response::ok(['campaign' => Catalog::campaigns((int) $data['client_id']) ? ['id' => $id] : null]);
    }

    public function updateCampaign(array $params): void
    {
        Auth::requireRole(Auth::ROLE_ADMIN, Auth::ROLE_LEAD);
        $id   = (int) $params['id'];
        $data = $this->input();

        Validator::make($data)
            ->required('client_id', 'Client')
            ->required('name', 'Campaign name')
            ->requireValid();

        Catalog::updateCampaign(
            $id,
            (int) $data['client_id'],
            Security::clean((string) $data['name']),
            isset($data['code']) ? Security::clean((string) $data['code']) : null,
            !empty($data['is_active'])
        );

        Response::ok(['campaigns' => Catalog::campaigns()]);
    }

    public function createForm(): void
    {
        Auth::requireRole(Auth::ROLE_ADMIN, Auth::ROLE_LEAD, Auth::ROLE_ANALYST);
        $data = $this->input();

        Validator::make($data)
            ->required('campaign_id', 'Campaign')
            ->required('name', 'Donation form name')
            ->maxLength('name', 'Donation form name', 180)
            ->in('environment', 'Environment', array_keys(Execution::ENVIRONMENTS))
            ->url('url', 'Donation form URL')
            ->url('template_url', 'Template URL')
            ->requireValid();

        $id = Catalog::createForm(
            (int) $data['campaign_id'],
            Security::clean((string) $data['name']),
            (string) ($data['environment'] ?? 'staging'),
            isset($data['url']) ? Security::clean((string) $data['url']) : null,
            isset($data['template_url']) ? Security::clean((string) $data['template_url']) : null,
            isset($data['appeal_code']) ? Security::clean((string) $data['appeal_code']) : null,
            Auth::id()
        );

        Response::ok(['form' => Catalog::form($id)]);
    }

    public function updateForm(array $params): void
    {
        Auth::requireRole(Auth::ROLE_ADMIN, Auth::ROLE_LEAD);
        $id = (int) $params['id'];

        if (Catalog::form($id) === null) {
            Response::error('Donation form not found.', 404);
        }

        $data = $this->input();

        Validator::make($data)
            ->required('campaign_id', 'Campaign')
            ->required('name', 'Donation form name')
            ->in('environment', 'Environment', array_keys(Execution::ENVIRONMENTS))
            ->url('url', 'Donation form URL')
            ->url('template_url', 'Template URL')
            ->requireValid();

        Catalog::updateForm(
            $id,
            (int) $data['campaign_id'],
            Security::clean((string) $data['name']),
            (string) ($data['environment'] ?? 'staging'),
            isset($data['url']) ? Security::clean((string) $data['url']) : null,
            isset($data['template_url']) ? Security::clean((string) $data['template_url']) : null,
            isset($data['appeal_code']) ? Security::clean((string) $data['appeal_code']) : null,
            !empty($data['is_active'])
        );

        Response::ok(['form' => Catalog::form($id)]);
    }
}
