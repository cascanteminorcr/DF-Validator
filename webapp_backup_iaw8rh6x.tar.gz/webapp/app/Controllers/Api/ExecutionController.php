<?php

declare(strict_types=1);

namespace App\Controllers\Api;

use App\Core\Auth;
use App\Core\Request;
use App\Core\Response;
use App\Core\Security;
use App\Core\Validator;
use App\Models\Catalog;
use App\Models\EvidenceFile;
use App\Models\Execution;
use App\Models\Report;
use App\Models\TestResult;
use App\Services\ChecklistCatalog;

final class ExecutionController extends BaseController
{
    // ==================================================================
    // Listing & CRUD
    // ==================================================================

    public function index(): void
    {
        $query = Request::query();

        $filters = [
            'search'      => Security::clean((string) ($query['search'] ?? '')),
            'status'      => (string) ($query['status'] ?? ''),
            'environment' => (string) ($query['environment'] ?? ''),
            'client'      => (string) ($query['client'] ?? ''),
            'analyst'     => isset($query['analyst']) ? (int) $query['analyst'] : 0,
            'from'        => (string) ($query['from'] ?? ''),
            'to'          => (string) ($query['to'] ?? ''),
        ];

        $page    = max(1, (int) ($query['page'] ?? 1));
        $perPage = min(100, max(5, (int) ($query['per_page'] ?? 15)));

        // Analysts only see their own work unless they explicitly ask for all.
        $scopeAll = Auth::hasRole(Auth::ROLE_ADMIN, Auth::ROLE_LEAD) || !empty($query['scope']) && $query['scope'] === 'all';
        $restrict = $scopeAll ? null : Auth::id();

        $result = Execution::paginate($filters, $page, $perPage, $restrict);

        Response::ok([
            'executions'   => $result['rows'],
            'pagination'   => [
                'total'    => $result['total'],
                'page'     => $result['page'],
                'per_page' => $result['per_page'],
                'pages'    => $result['pages'],
            ],
            'clients'      => Execution::distinctClients(),
            'statuses'     => Execution::STATUSES,
            'environments' => Execution::ENVIRONMENTS,
            'scope'        => $scopeAll ? 'all' : 'mine',
        ]);
    }

    public function show(array $params): void
    {
        $execution = $this->findExecution((int) $params['id']);

        $checklist = TestResult::checklist((int) $execution['id']);

        Response::ok([
            'execution' => $this->serialise($execution),
            'checklist' => $checklist,
            'evidence'  => array_map([$this, 'serialiseEvidence'], EvidenceFile::forExecution((int) $execution['id'])),
            'reports'   => Report::forExecution((int) $execution['id']),
            'can_edit'  => Auth::canEditExecution($execution),
            'can_approve' => Auth::canApprove(),
            'failed_items' => TestResult::failedFor((int) $execution['id']),
        ]);
    }

    public function store(): void
    {
        $data = $this->input();

        $validator = Validator::make($data)
            ->required('client_name', 'Client name')
            ->maxLength('client_name', 'Client name', 160)
            ->required('campaign_name', 'Campaign name')
            ->maxLength('campaign_name', 'Campaign name', 160)
            ->required('form_name', 'Donation form name')
            ->maxLength('form_name', 'Donation form name', 180)
            ->required('environment', 'Environment')
            ->in('environment', 'Environment', array_keys(Execution::ENVIRONMENTS))
            ->required('form_url', 'Donation form URL')
            ->url('form_url', 'Donation form URL', true)
            ->url('template_url', 'Template URL')
            ->maxLength('form_url', 'Donation form URL', 500)
            ->required('qa_analyst_name', 'QA analyst')
            ->maxLength('qa_analyst_name', 'QA analyst', 120)
            ->datetime('build_timestamp', 'Build timestamp')
            ->maxLength('browser_used', 'Browser', 80)
            ->date('test_date', 'Test date');

        $validator->requireValid();

        $formId = isset($data['form_id']) && $data['form_id'] !== '' ? (int) $data['form_id'] : null;

        if ($formId !== null && Catalog::form($formId) === null) {
            $formId = null;
        }

        $buildTs = $this->normaliseDatetime($data['build_timestamp'] ?? null);

        $id = Execution::create([
            'form_id'           => $formId,
            'client_name'       => Security::clean((string) $data['client_name']),
            'campaign_name'     => Security::clean((string) $data['campaign_name']),
            'form_name'         => Security::clean((string) $data['form_name']),
            'environment'       => (string) $data['environment'],
            'form_url'          => Security::clean((string) $data['form_url']),
            'template_url'      => isset($data['template_url']) && $data['template_url'] !== '' ? Security::clean((string) $data['template_url']) : null,
            'qa_analyst_id'     => Auth::id(),
            'qa_analyst_name'   => Security::clean((string) $data['qa_analyst_name']),
            'build_timestamp'   => $buildTs,
            'browser_used'      => isset($data['browser_used']) ? Security::clean((string) $data['browser_used']) : null,
            'test_date'         => $data['test_date'] ?: date('Y-m-d'),
        ], Auth::id());

        $this->audit('execution.create', $id);

        $execution = Execution::find($id);

        Response::ok([
            'execution' => $this->serialise($execution),
            'redirect'  => '/executions/' . $id,
        ]);
    }

    public function update(array $params): void
    {
        $execution = $this->findExecution((int) $params['id'], true);

        if (in_array($execution['status'], ['approved'], true) && !Auth::canApprove()) {
            Response::error('This execution is approved and locked. Ask a QA Lead to reopen it.', 409);
        }

        $data = $this->input();

        Validator::make($data)
            ->required('client_name', 'Client name')
            ->required('campaign_name', 'Campaign name')
            ->required('form_name', 'Donation form name')
            ->required('environment', 'Environment')
            ->in('environment', 'Environment', array_keys(Execution::ENVIRONMENTS))
            ->required('form_url', 'Donation form URL')
            ->url('form_url', 'Donation form URL', true)
            ->url('template_url', 'Template URL')
            ->required('qa_analyst_name', 'QA analyst')
            ->datetime('build_timestamp', 'Build timestamp')
            ->date('test_date', 'Test date')
            ->requireValid();

        $formId = isset($data['form_id']) && $data['form_id'] !== '' ? (int) $data['form_id'] : null;

        Execution::update((int) $execution['id'], [
            'form_id'         => $formId,
            'client_name'     => Security::clean((string) $data['client_name']),
            'campaign_name'   => Security::clean((string) $data['campaign_name']),
            'form_name'       => Security::clean((string) $data['form_name']),
            'environment'     => (string) $data['environment'],
            'form_url'        => Security::clean((string) $data['form_url']),
            'template_url'    => isset($data['template_url']) && $data['template_url'] !== '' ? Security::clean((string) $data['template_url']) : null,
            'qa_analyst_name' => Security::clean((string) $data['qa_analyst_name']),
            'build_timestamp' => $this->normaliseDatetime($data['build_timestamp'] ?? null),
            'browser_used'    => isset($data['browser_used']) ? Security::clean((string) $data['browser_used']) : null,
            'test_date'       => $data['test_date'] ?: null,
        ]);

        $this->audit('execution.update', (int) $execution['id']);

        Response::ok(['execution' => $this->serialise(Execution::find((int) $execution['id']))]);
    }

    public function duplicate(array $params): void
    {
        $source = $this->findExecution((int) $params['id']);

        $id = Execution::create([
            'form_id'         => $source['form_id'],
            'client_name'     => $source['client_name'],
            'campaign_name'   => $source['campaign_name'],
            'form_name'       => $source['form_name'] . ' (copy)',
            'environment'     => $source['environment'],
            'form_url'        => $source['form_url'],
            'template_url'    => $source['template_url'],
            'qa_analyst_id'   => Auth::id(),
            'qa_analyst_name' => Auth::user()['name'] ?? $source['qa_analyst_name'],
            'build_timestamp' => date('Y-m-d H:i:s'),
            'browser_used'    => $source['browser_used'],
            'test_date'       => date('Y-m-d'),
        ], Auth::id());

        $this->audit('execution.duplicate', $id);

        Response::ok([
            'execution' => $this->serialise(Execution::find($id)),
            'redirect'  => '/executions/' . $id,
        ]);
    }

    public function destroy(array $params): void
    {
        $execution = $this->findExecution((int) $params['id'], true);

        if (!Auth::hasRole(Auth::ROLE_ADMIN, Auth::ROLE_LEAD)) {
            Response::error('Only a QA Lead or Admin can delete an execution.', 403);
        }

        // Remove evidence files from disk before the cascading delete.
        foreach (EvidenceFile::forExecution((int) $execution['id']) as $file) {
            $path = EvidenceFile::absolutePath($file);

            if (is_file($path)) {
                @unlink($path);
            }
        }

        Execution::delete((int) $execution['id']);
        $this->audit('execution.delete', (int) $execution['id']);

        Response::ok(['deleted' => true]);
    }

    // ==================================================================
    // Checklist results (autosave endpoint)
    // ==================================================================

    public function saveResult(array $params): void
    {
        $execution = $this->findExecution((int) $params['id'], true);
        $this->assertEditable($execution);

        $data    = $this->input();
        $itemKey = (string) ($params['item'] ?? ($data['item_key'] ?? ''));
        $status  = (string) ($data['status'] ?? 'untested');
        $comment = Security::clean((string) ($data['comment'] ?? ''));

        if (!in_array($status, TestResult::STATUSES, true)) {
            Response::error('Status must be one of: pass, fail, na, untested.', 422);
        }

        try {
            [$row] = TestResult::save((int) $execution['id'], $itemKey, $status, $comment);
        } catch (\InvalidArgumentException $e) {
            Response::error($e->getMessage(), 422);
        }

        $metrics = Execution::recalcMetrics((int) $execution['id']);
        $this->syncStatus((int) $execution['id'], $metrics);

        Response::ok([
            'result'  => $row,
            'metrics' => $metrics,
            'evidence' => array_map([$this, 'serialiseEvidence'], EvidenceFile::forResult((int) $row['id'])),
        ]);
    }

    public function bulkSaveResults(array $params): void
    {
        $execution = $this->findExecution((int) $params['id'], true);
        $this->assertEditable($execution);

        $data  = $this->input();
        $items = $data['items'] ?? [];

        if (!is_array($items) || $items === []) {
            Response::error('No checklist items were supplied.', 422);
        }

        try {
            $saved = TestResult::bulkSave((int) $execution['id'], $items);
        } catch (\InvalidArgumentException $e) {
            Response::error($e->getMessage(), 422);
        }

        $metrics = Execution::recalcMetrics((int) $execution['id']);
        $this->syncStatus((int) $execution['id'], $metrics);

        Response::ok(['saved' => $saved, 'metrics' => $metrics]);
    }

    public function autosave(array $params): void
    {
        $execution = $this->findExecution((int) $params['id'], true);

        $data = $this->input();
        $draft = $data['draft'] ?? [];

        if (!is_array($draft)) {
            Response::error('Invalid autosave payload.', 422);
        }

        // Drafts land in the same result rows but never downgrade a decided
        // item: only untouched items are filled from the draft.
        $saved = 0;

        foreach ($draft as $itemKey => $payload) {
            if (!is_string($itemKey) || !is_array($payload)) {
                continue;
            }

            $status  = (string) ($payload['status'] ?? 'untested');
            $comment = Security::clean((string) ($payload['comment'] ?? ''));

            if ($status === 'untested' && $comment === '') {
                continue;
            }

            if ($status === 'fail' && $comment === '') {
                // Skip an incomplete draft rather than throwing on autosave.
                continue;
            }

            try {
                TestResult::save((int) $execution['id'], $itemKey, $status, $comment);
                $saved++;
            } catch (\Throwable) {
                // Autosave is best-effort; the user's explicit save still wins.
            }
        }

        if ($saved > 0) {
            $metrics = Execution::recalcMetrics((int) $execution['id']);
            $this->syncStatus((int) $execution['id'], $metrics);
        }

        Response::ok(['saved' => $saved, 'saved_at' => date('c')]);
    }

    // ==================================================================
    // Automated validation
    // ==================================================================

    public function runAutomation(array $params): void
    {
        $execution = $this->findExecution((int) $params['id'], true);

        $data = $this->input();
        $url  = Security::clean((string) ($data['url'] ?? $execution['form_url']));
        $templateUrl = $execution['template_url'];

        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            Response::error('A valid Donation Form URL is required before running automated checks.', 422);
        }

        $service = new \App\Services\AutomationService();
        $report  = $service->analyse($url, $templateUrl);

        Execution::saveAutoResults((int) $execution['id'], $report);
        $this->audit('execution.automation', (int) $execution['id']);

        Response::ok(['automation' => $report]);
    }

    public function automation(string $params): void
    {
        // Placeholder for potential cached retrieval.
    }

    // ==================================================================
    // Workflow: submit / approval
    // ==================================================================

    public function submit(array $params): void
    {
        $execution = $this->findExecution((int) $params['id'], true);
        $metrics   = Execution::recalcMetrics((int) $execution['id']);

        if ($metrics['untested'] > 0) {
            Response::error(sprintf(
                '%d checklist item(s) are still untested. Mark each item Pass, Fail or N/A before submitting.',
                $metrics['untested']
            ), 422);
        }

        if ($metrics['fail'] > 0) {
            $missingComments = array_filter(
                TestResult::failedFor((int) $execution['id']),
                static fn (array $row): bool => trim((string) $row['comment']) === ''
            );

            if ($missingComments !== []) {
                Response::error('Every failed item needs a comment describing the defect.', 422);
            }
        }

        Execution::setStatus((int) $execution['id'], 'submitted');
        $this->audit('execution.submit', (int) $execution['id']);

        Response::ok(['status' => 'submitted', 'metrics' => $metrics]);
    }

    public function approval(array $params): void
    {
        Auth::requireRole(Auth::ROLE_ADMIN, Auth::ROLE_LEAD);

        $execution = $this->findExecution((int) $params['id']);
        $data      = $this->input();

        $decision = (string) ($data['decision'] ?? '');

        if (!in_array($decision, ['approved', 'rejected', 'pending'], true)) {
            Response::error('Decision must be approved, rejected or pending.', 422);
        }

        $amName  = Security::clean((string) ($data['am_name'] ?? ''));
        $message = Security::clean((string) ($data['approval_message'] ?? ''));
        $notes   = Security::clean((string) ($data['qa_notes'] ?? ''));

        if ($decision === 'approved' && $amName === '') {
            Response::error('The Account Manager name is required to approve an execution.', 422);
        }

        if ($decision === 'approved' && (int) $execution['fail_count'] > 0) {
            Response::error(sprintf(
                'This execution has %d failed item(s). Resolve them or reject the build before approving.',
                (int) $execution['fail_count']
            ), 422);
        }

        \App\Core\Database::instance()->run(
            'UPDATE test_executions
             SET am_name = ?, approval_message = ?, qa_notes = ?, approval_status = ?,
                 approved_at = ?, approved_by = ?, status = ?
             WHERE id = ?',
            [
                $amName ?: null,
                $message ?: null,
                $notes ?: null,
                $decision,
                $decision === 'approved' ? date('Y-m-d H:i:s') : null,
                $decision === 'approved' ? Auth::id() : null,
                $decision === 'approved' ? 'approved' : ($decision === 'rejected' ? 'rejected' : 'submitted'),
                (int) $execution['id'],
            ]
        );

        $this->audit('execution.approval.' . $decision, (int) $execution['id']);

        Response::ok(['execution' => $this->serialise(Execution::find((int) $execution['id']))]);
    }

    // ==================================================================
    // Public meta
    // ==================================================================

    public function meta(): void
    {
        Response::ok([
            'sections'     => ChecklistCatalog::SECTIONS,
            'statuses'     => Execution::STATUSES,
            'environments' => Execution::ENVIRONMENTS,
            'browsers'     => Execution::BROWSERS,
            'result_statuses' => TestResult::STATUSES,
            'total_items'  => ChecklistCatalog::totalItems(),
            'counts'       => [
                'creative'   => count(ChecklistCatalog::creative()),
                'functional' => count(ChecklistCatalog::functional()),
            ],
            'evidence_categories' => EvidenceFile::CATEGORIES,
        ]);
    }

    // ==================================================================
    // Helpers
    // ==================================================================

    private function assertEditable(array $execution): void
    {
        if ($execution['status'] === 'approved' && !Auth::canApprove()) {
            Response::error('This execution is approved and locked.', 409);
        }

        if ($execution['status'] === 'rejected' && !Auth::hasRole(Auth::ROLE_ADMIN, Auth::ROLE_LEAD)) {
            Response::error('This execution was rejected. Ask a QA Lead to reopen it.', 409);
        }
    }

    private function syncStatus(int $executionId, array $metrics): void
    {
        $execution = Execution::find($executionId);

        if ($execution === null) {
            return;
        }

        if ($execution['status'] === 'draft' && ($metrics['pass'] + $metrics['fail'] + $metrics['na']) > 0) {
            Execution::setStatus($executionId, 'in_progress');
        }
    }

    private function normaliseDatetime(mixed $value): ?string
    {
        $value = trim((string) ($value ?? ''));

        if ($value === '') {
            return null;
        }

        $value = str_replace('T', ' ', $value);

        if (strlen($value) === 16) {
            $value .= ':00';
        }

        return $value;
    }

    private function serialise(?array $execution): ?array
    {
        if ($execution === null) {
            return null;
        }

        $auto = json_decode((string) ($execution['auto_results'] ?? ''), true);

        $execution['auto_results'] = is_array($auto) ? $auto : null;

        return $execution;
    }

    private function serialiseEvidence(array $file): array
    {
        return [
            'id'            => (int) $file['id'],
            'result_id'     => $file['result_id'] !== null ? (int) $file['result_id'] : null,
            'category'      => $file['category'],
            'original_name' => $file['original_name'],
            'extension'     => $file['extension'],
            'mime_type'     => $file['mime_type'],
            'file_size'     => (int) $file['file_size'],
            'file_size_human' => EvidenceFile::humanSize((int) $file['file_size']),
            'is_image'      => EvidenceFile::isImage((string) $file['extension']),
            'uploaded_by_name' => $file['uploaded_by_name'] ?? null,
            'result_label'  => $file['result_label'] ?? null,
            'created_at'    => $file['created_at'],
            'download_url'  => '/api/evidence/' . (int) $file['id'] . '/download',
            'preview_url'   => '/api/evidence/' . (int) $file['id'] . '/preview',
        ];
    }
}
