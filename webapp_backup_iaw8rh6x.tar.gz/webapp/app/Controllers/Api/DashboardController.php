<?php

declare(strict_types=1);

namespace App\Controllers\Api;

use App\Core\Response;
use App\Models\Execution;

final class DashboardController extends BaseController
{
    public function index(): void
    {
        $stats = Execution::dashboardStats();

        Response::ok([
            'stats'   => $stats,
            'clients' => Execution::distinctClients(),
            'statuses' => Execution::STATUSES,
            'environments' => Execution::ENVIRONMENTS,
        ]);
    }
}
