<?php

declare(strict_types=1);

namespace App\Controllers\Api;

use App\Core\Auth;
use App\Core\Csrf;
use App\Core\Response;
use App\Core\Security;
use App\Core\Validator;
use App\Models\User;

final class AuthController extends BaseController
{
    public function login(): void
    {
        $data = $this->input();

        $email    = Security::clean((string) ($data['email'] ?? ''));
        $password = (string) ($data['password'] ?? '');

        $validator = Validator::make($data)
            ->required('email', 'E-mail')
            ->email('email', 'E-mail')
            ->required('password', 'Password');

        $validator->requireValid();

        // Simple throttling: 5 failed attempts per session in 10 minutes.
        $attempts = (int) ($_SESSION['login_attempts'] ?? 0);
        $lastTry  = (int) ($_SESSION['login_last_attempt'] ?? 0);

        if ($attempts >= 5 && (time() - $lastTry) < 600) {
            Response::error('Too many failed attempts. Please wait a few minutes and try again.', 429);
        }

        if (!Auth::attempt($email, $password)) {
            $_SESSION['login_attempts']    = $attempts + 1;
            $_SESSION['login_last_attempt'] = time();

            Response::error('Invalid e-mail or password.', 401);
        }

        unset($_SESSION['login_attempts'], $_SESSION['login_last_attempt']);

        $this->audit('login');

        Response::ok([
            'user'       => Auth::publicUser(),
            'csrf_token' => Csrf::token(),
        ]);
    }

    public function logout(): void
    {
        $this->audit('logout');
        Auth::logout();

        Response::ok(['logged_out' => true]);
    }

    public function me(): void
    {
        $user = Auth::user();

        // Anonymous visitors still receive a CSRF token so the sign-in form
        // can post safely. `user` is null in that case — the client decides.
        if ($user === null) {
            Response::ok([
                'user'       => null,
                'csrf_token' => Csrf::token(),
                'authenticated' => false,
                'permissions' => [
                    'can_approve'      => false,
                    'can_manage_users' => false,
                    'can_edit_all'     => false,
                ],
            ]);
        }

        Response::ok([
            'user'       => Auth::publicUser(),
            'csrf_token' => Csrf::token(),
            'authenticated' => true,
            'permissions' => [
                'can_approve'      => Auth::canApprove(),
                'can_manage_users' => Auth::isAdmin(),
                'can_edit_all'     => Auth::hasRole(Auth::ROLE_ADMIN, Auth::ROLE_LEAD),
            ],
        ]);
    }

    // ------------------------------------------------------------------
    // User administration (admin only)
    // ------------------------------------------------------------------

    public function users(): void
    {
        Auth::requireRole(Auth::ROLE_ADMIN);

        Response::ok(['users' => User::all(), 'roles' => User::ROLES]);
    }

    public function createUser(): void
    {
        Auth::requireRole(Auth::ROLE_ADMIN);
        $data = $this->input();

        Validator::make($data)
            ->required('name', 'Name')
            ->maxLength('name', 'Name', 120)
            ->required('email', 'E-mail')
            ->email('email', 'E-mail')
            ->required('password', 'Password')
            ->minLength('password', 'Password', 10)
            ->required('role', 'Role')
            ->in('role', 'Role', array_keys(User::ROLES))
            ->requireValid();

        if (User::findByEmail((string) $data['email']) !== null) {
            Response::error('A user with that e-mail already exists.', 409);
        }

        $id = User::create(
            Security::clean((string) $data['name']),
            (string) $data['email'],
            (string) $data['password'],
            (string) $data['role']
        );

        $this->audit('user.create#' . $id);

        Response::ok(['user' => User::find($id)], [], 201);
    }

    public function updateUser(array $params): void
    {
        Auth::requireRole(Auth::ROLE_ADMIN);
        $id   = (int) $params['id'];
        $data = $this->input();

        $user = User::find($id);

        if ($user === null) {
            Response::error('User not found.', 404);
        }

        Validator::make($data)
            ->required('name', 'Name')
            ->required('email', 'E-mail')
            ->email('email', 'E-mail')
            ->required('role', 'Role')
            ->in('role', 'Role', array_keys(User::ROLES))
            ->requireValid();

        $active = !empty($data['is_active']);

        // Never let an admin lock themselves out.
        if ($id === Auth::id() && (!$active || (string) $data['role'] !== Auth::ROLE_ADMIN)) {
            Response::error('You cannot remove your own admin access.', 422);
        }

        User::update(
            $id,
            Security::clean((string) $data['name']),
            (string) $data['email'],
            (string) $data['role'],
            $active
        );

        if (!empty($data['password'])) {
            Validator::make($data)->minLength('password', 'Password', 10)->requireValid();
            User::updatePassword($id, (string) $data['password']);
        }

        $this->audit('user.update#' . $id);

        Response::ok(['user' => User::find($id)]);
    }

    public function deleteUser(array $params): void
    {
        Auth::requireRole(Auth::ROLE_ADMIN);
        $id = (int) $params['id'];

        if ($id === Auth::id()) {
            Response::error('You cannot delete your own account.', 422);
        }

        User::delete($id);
        $this->audit('user.delete#' . $id);

        Response::ok(['deleted' => true]);
    }
}
