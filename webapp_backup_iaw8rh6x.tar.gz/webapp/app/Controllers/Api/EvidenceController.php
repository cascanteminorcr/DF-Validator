<?php

declare(strict_types=1);

namespace App\Controllers\Api;

use App\Core\Auth;
use App\Core\Config;
use App\Core\Request;
use App\Core\Response;
use App\Core\Security;
use App\Models\EvidenceFile;
use App\Models\TestResult;
use App\Services\UploadService;

final class EvidenceController extends BaseController
{
    /**
     * Upload one or more files to an execution.
     * Fields: files[] (multipart), result_id (optional), category (optional)
     */
    public function upload(array $params): void
    {
        $execution = $this->findExecution((int) $params['id'], true);

        if ($execution['status'] === 'approved' && !Auth::canApprove()) {
            Response::error('This execution is approved and locked.', 409);
        }

        $resultId = isset($_POST['result_id']) && $_POST['result_id'] !== ''
            ? (int) $_POST['result_id']
            : null;

        $category = (string) ($_POST['category'] ?? 'screenshot');

        if (!isset(EvidenceFile::CATEGORIES[$category])) {
            $category = 'screenshot';
        }

        if ($resultId !== null) {
            $result = TestResult::find($resultId);

            if ($result === null || (int) $result['execution_id'] !== (int) $execution['id']) {
                Response::error('The checklist item does not belong to this execution.', 422);
            }
        }

        $files = $this->normaliseFiles();

        if ($files === []) {
            Response::error('No file was received.', 422);
        }

        $stored  = [];
        $errors  = [];

        foreach ($files as $file) {
            try {
                $stored[] = UploadService::store(
                    (int) $execution['id'],
                    $file,
                    $category,
                    $resultId,
                    Auth::id()
                );
            } catch (\InvalidArgumentException $e) {
                $errors[] = (string) $file['name'] . ': ' . $e->getMessage();
            } catch (\Throwable $e) {
                error_log('[DFQA] upload failed: ' . $e->getMessage());
                $errors[] = (string) $file['name'] . ': the file could not be stored.';
            }
        }

        if ($stored === []) {
            Response::error($errors[0] ?? 'The upload failed.', 422);
        }

        $this->audit('evidence.upload', (int) $execution['id']);

        Response::ok([
            'files'  => array_map(
                static fn (array $f): array => [
                    'id'            => (int) $f['id'],
                    'result_id'     => $f['result_id'] !== null ? (int) $f['result_id'] : null,
                    'category'      => $f['category'],
                    'original_name' => $f['original_name'],
                    'extension'     => $f['extension'],
                    'mime_type'     => $f['mime_type'],
                    'file_size'     => (int) $f['file_size'],
                    'file_size_human' => EvidenceFile::humanSize((int) $f['file_size']),
                    'is_image'      => EvidenceFile::isImage((string) $f['extension']),
                    'created_at'    => $f['created_at'],
                    'download_url'  => '/api/evidence/' . (int) $f['id'] . '/download',
                    'preview_url'   => '/api/evidence/' . (int) $f['id'] . '/preview',
                ],
                $stored
            ),
            'errors' => $errors,
        ]);
    }

    /** Stream a file inline for image previews. */
    public function preview(array $params): void
    {
        $file = $this->authorise((int) $params['id']);

        if (!EvidenceFile::isImage((string) $file['extension'])) {
            Response::error('Inline preview is only available for images.', 415);
        }

        $this->stream($file, true);
    }

    /** Download with an attachment disposition. */
    public function download(array $params): void
    {
        $file = $this->authorise((int) $params['id']);

        $this->stream($file, false);
    }

    public function destroy(array $params): void
    {
        $file = EvidenceFile::find((int) $params['id']);

        if ($file === null) {
            Response::error('File not found.', 404);
        }

        $execution = $this->findExecution((int) $file['execution_id'], true);

        if ($execution['status'] === 'approved' && !Auth::canApprove()) {
            Response::error('This execution is approved and locked.', 409);
        }

        EvidenceFile::delete((int) $file['id']);
        $this->audit('evidence.delete', (int) $file['execution_id']);

        Response::ok(['deleted' => true]);
    }

    // ------------------------------------------------------------------

    private function authorise(int $id): array
    {
        $file = EvidenceFile::find($id);

        if ($file === null) {
            Response::error('File not found.', 404);
        }

        // Any authenticated user who can view the execution may read evidence.
        $execution = $this->findExecution((int) $file['execution_id']);

        if (!Auth::canEditExecution($execution) && !Auth::hasRole(Auth::ROLE_ADMIN, Auth::ROLE_LEAD)) {
            // Analysts may view only their own executions' evidence.
            Response::error('You do not have permission to view this file.', 403);
        }

        return $file;
    }

    private function stream(array $file, bool $inline): never
    {
        $path = EvidenceFile::absolutePath($file);

        if (!is_file($path)) {
            Response::error('The stored file is missing from disk.', 410);
        }

        while (ob_get_level() > 0) {
            ob_end_clean();
        }

        $safeName = preg_replace('/[^A-Za-z0-9._-]/', '_', (string) $file['original_name']) ?: 'evidence.' . $file['extension'];

        http_response_code(200);
        header('Content-Type: ' . $file['mime_type']);
        header('Content-Length: ' . (string) filesize($path));
        header('Content-Disposition: ' . ($inline ? 'inline' : 'attachment') . '; filename="' . $safeName . '"');
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: private, max-age=300');
        header("Content-Security-Policy: default-src 'none'; img-src 'self'; style-src 'unsafe-inline'");

        readfile($path);
        exit;
    }

    /** Convert $_FILES[files] nested arrays into a flat list. */
    private function normaliseFiles(): array
    {
        $field = $_FILES['files'] ?? null;

        if ($field === null) {
            // Fall back to any single file field.
            foreach ($_FILES as $candidate) {
                $field = $candidate;
                break;
            }
        }

        if ($field === null) {
            return [];
        }

        if (!is_array($field['name'])) {
            return [$field];
        }

        $files = [];

        foreach (array_keys($field['name']) as $index) {
            $files[] = [
                'name'     => $field['name'][$index],
                'type'     => $field['type'][$index],
                'tmp_name' => $field['tmp_name'][$index],
                'error'    => $field['error'][$index],
                'size'     => $field['size'][$index],
            ];
        }

        return $files;
    }
}
