<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Database;
use App\Core\Config;

/**
 * Generated report records.
 */
final class Report
{
    /** @return array<int,array<string,mixed>> */
    public static function forExecution(int $executionId): array
    {
        return Database::instance()->fetchAll(
            'SELECT r.*, u.name AS generated_by_name
             FROM reports r
             LEFT JOIN users u ON u.id = r.generated_by
             WHERE r.execution_id = ?
             ORDER BY r.created_at DESC',
            [$executionId]
        );
    }

    public static function find(int $id): ?array
    {
        return Database::instance()->fetch('SELECT * FROM reports WHERE id = ?', [$id]);
    }

    public static function delete(int $id): bool
    {
        $report = self::find($id);

        if ($report === null) {
            return false;
        }

        if (is_file($report['file_path'])) {
            @unlink($report['file_path']);
        }

        Database::instance()->run('DELETE FROM reports WHERE id = ?', [$id]);

        return true;
    }
}
