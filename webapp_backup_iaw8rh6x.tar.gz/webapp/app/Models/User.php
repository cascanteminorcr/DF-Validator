<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Database;

final class User
{
    public const ROLES = ['admin' => 'Admin', 'qa_lead' => 'QA Lead', 'qa_analyst' => 'QA Analyst'];

    public static function find(int $id): ?array
    {
        return Database::instance()->fetch('SELECT * FROM users WHERE id = ?', [$id]);
    }

    public static function findByEmail(string $email): ?array
    {
        return Database::instance()->fetch('SELECT * FROM users WHERE email = ?', [strtolower(trim($email))]);
    }

    /** @return array<int,array<string,mixed>> */
    public static function all(): array
    {
        return Database::instance()->fetchAll(
            'SELECT id, name, email, role, is_active, last_login_at, created_at FROM users ORDER BY name'
        );
    }

    public static function create(string $name, string $email, string $password, string $role): int
    {
        return Database::instance()->insert(
            'INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)',
            [
                $name,
                strtolower(trim($email)),
                password_hash($password, PASSWORD_DEFAULT),
                $role,
            ]
        );
    }

    public static function update(int $id, string $name, string $email, string $role, bool $active): void
    {
        Database::instance()->run(
            'UPDATE users SET name = ?, email = ?, role = ?, is_active = ? WHERE id = ?',
            [$name, strtolower(trim($email)), $role, $active ? 1 : 0, $id]
        );
    }

    public static function updatePassword(int $id, string $password): void
    {
        Database::instance()->run(
            'UPDATE users SET password_hash = ? WHERE id = ?',
            [password_hash($password, PASSWORD_DEFAULT), $id]
        );
    }

    public static function touchLogin(int $id): void
    {
        Database::instance()->run('UPDATE users SET last_login_at = NOW() WHERE id = ?', [$id]);
    }

    public static function delete(int $id): void
    {
        Database::instance()->run('DELETE FROM users WHERE id = ?', [$id]);
    }

    public static function countActive(): int
    {
        return (int) Database::instance()->value('SELECT COUNT(*) FROM users WHERE is_active = 1');
    }
}
