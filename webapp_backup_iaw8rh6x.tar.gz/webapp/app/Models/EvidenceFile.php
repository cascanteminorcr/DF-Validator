<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Config;
use App\Core\Database;

/**
 * Read model for uploaded evidence files.
 * Writing/validation lives in App\Services\UploadService.
 */
final class EvidenceFile
{
    public const CATEGORIES = [
        'screenshot' => 'Screenshot',
        'attachment' => 'Attachment',
        'creative'   => 'Creative',
        'approval'   => 'Approval file',
        'other'      => 'Other',
    ];

    public static function find(int $id): ?array
    {
        return Database::instance()->fetch(
            'SELECT e.*, u.name AS uploaded_by_name, r.item_label AS result_label
             FROM evidence_files e
             LEFT JOIN users u ON u.id = e.uploaded_by
             LEFT JOIN test_results r ON r.id = e.result_id
             WHERE e.id = ?',
            [$id]
        );
    }

    /** @return array<int,array<string,mixed>> */
    public static function forExecution(int $executionId): array
    {
        return Database::instance()->fetchAll(
            'SELECT e.*, u.name AS uploaded_by_name, r.item_label AS result_label
             FROM evidence_files e
             LEFT JOIN users u ON u.id = e.uploaded_by
             LEFT JOIN test_results r ON r.id = e.result_id
             WHERE e.execution_id = ?
             ORDER BY e.created_at DESC, e.id DESC',
            [$executionId]
        );
    }

    /** @return array<int,array<string,mixed>> */
    public static function forResult(int $resultId): array
    {
        return Database::instance()->fetchAll(
            'SELECT e.*, u.name AS uploaded_by_name
             FROM evidence_files e
             LEFT JOIN users u ON u.id = e.uploaded_by
             WHERE e.result_id = ?
             ORDER BY e.created_at ASC',
            [$resultId]
        );
    }

    public static function absolutePath(array $file): string
    {
        return rtrim((string) Config::get('uploads.dir'), '/')
            . '/' . (int) $file['execution_id'] . '/' . $file['stored_name'];
    }

    public static function delete(int $id): bool
    {
        $file = self::find($id);

        if ($file === null) {
            return false;
        }

        $path = self::absolutePath($file);

        if (is_file($path)) {
            @unlink($path);
        }

        Database::instance()->run('DELETE FROM evidence_files WHERE id = ?', [$id]);

        return true;
    }

    public static function count(int $executionId): int
    {
        return (int) Database::instance()->value(
            'SELECT COUNT(*) FROM evidence_files WHERE execution_id = ?',
            [$executionId]
        );
    }

    public static function humanSize(int $bytes): string
    {
        if ($bytes >= 1048576) {
            return number_format($bytes / 1048576, 1) . ' MB';
        }

        if ($bytes >= 1024) {
            return number_format($bytes / 1024, 0) . ' KB';
        }

        return $bytes . ' B';
    }

    public static function isImage(string $ext): bool
    {
        return in_array(strtolower($ext), ['png', 'jpg', 'jpeg'], true);
    }
}
