<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Database;
use App\Services\ChecklistCatalog;

/**
 * Test executions: creation, checklist seeding, metric recalculation and
 * dashboard aggregation.
 */
final class Execution
{
    public const STATUSES = [
        'draft'       => 'Draft',
        'in_progress' => 'In Progress',
        'submitted'   => 'Submitted',
        'approved'    => 'Approved',
        'rejected'    => 'Rejected',
    ];

    public const ENVIRONMENTS = [
        'production' => 'Production',
        'staging'    => 'Staging',
        'test'       => 'Test',
    ];

    public const BROWSERS = [
        'Chrome', 'Firefox', 'Safari', 'Edge', 'Chrome (Incognito)',
        'Safari (iOS)', 'Chrome (Android)', 'Samsung Internet', 'Other',
    ];

    public static function find(int $id): ?array
    {
        return Database::instance()->fetch('SELECT * FROM test_executions WHERE id = ?', [$id]);
    }

    /**
     * Create an execution and seed all checklist rows.
     */
    public static function create(array $data, ?int $userId): int
    {
        $db = Database::instance();

        return $db->transaction(function (Database $db) use ($data, $userId): int {
            $id = $db->insert(
                'INSERT INTO test_executions
                    (form_id, client_name, campaign_name, form_name, environment, form_url, template_url,
                     qa_analyst_id, qa_analyst_name, build_timestamp, browser_used, test_date,
                     status, total_items, created_by)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
                [
                    $data['form_id'] ?? null,
                    $data['client_name'],
                    $data['campaign_name'],
                    $data['form_name'],
                    $data['environment'],
                    $data['form_url'],
                    $data['template_url'] ?? null,
                    $data['qa_analyst_id'] ?? $userId,
                    $data['qa_analyst_name'],
                    $data['build_timestamp'] ?? null,
                    $data['browser_used'] ?? null,
                    $data['test_date'] ?? date('Y-m-d'),
                    'draft',
                    ChecklistCatalog::totalItems(),
                    $userId,
                ]
            );

            self::seedResults($id);

            return $id;
        });
    }

    /** Seed one result row per catalogue item (idempotent). */
    public static function seedResults(int $executionId): void
    {
        $db      = Database::instance();
        $order   = 0;

        foreach (ChecklistCatalog::all() as $item) {
            $order++;
            $db->run(
                'INSERT INTO test_results (execution_id, section, item_key, item_label, status, sort_order)
                 VALUES (?, ?, ?, ?, \'untested\', ?)
                 ON DUPLICATE KEY UPDATE item_label = VALUES(item_label)',
                [$executionId, $item['section'], $item['key'], $item['label'], $order]
            );
        }
    }

    public static function update(int $id, array $data): void
    {
        Database::instance()->run(
            'UPDATE test_executions
             SET form_id = ?, client_name = ?, campaign_name = ?, form_name = ?, environment = ?,
                 form_url = ?, template_url = ?, qa_analyst_name = ?, build_timestamp = ?,
                 browser_used = ?, test_date = ?
             WHERE id = ?',
            [
                $data['form_id'] ?? null,
                $data['client_name'],
                $data['campaign_name'],
                $data['form_name'],
                $data['environment'],
                $data['form_url'],
                $data['template_url'] ?? null,
                $data['qa_analyst_name'],
                $data['build_timestamp'] ?? null,
                $data['browser_used'] ?? null,
                $data['test_date'] ?? null,
                $id,
            ]
        );
    }

    public static function saveAutoResults(int $id, array $autoResults): void
    {
        Database::instance()->run(
            'UPDATE test_executions SET auto_results = ? WHERE id = ?',
            [json_encode($autoResults, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), $id]
        );
    }

    public static function setStatus(int $id, string $status): void
    {
        $submitted = in_array($status, ['submitted', 'approved', 'rejected'], true);
        Database::instance()->run(
            'UPDATE test_executions SET status = ?, submitted_at = COALESCE(submitted_at, ' . ($submitted ? 'NOW()' : 'NULL') . ') WHERE id = ?',
            [$status, $id]
        );
    }

    /**
     * Recompute pass/fail/na/untested counters and pass rate from test_results.
     * Pass rate is computed over decided items only (pass + fail), so N/A and
     * untested rows neither inflate nor deflate the score.
     */
    public static function recalcMetrics(int $id): array
    {
        $db    = Database::instance();
        $counts = ['pass' => 0, 'fail' => 0, 'na' => 0, 'untested' => 0];

        foreach ($db->fetchAll(
            'SELECT status, COUNT(*) AS n FROM test_results WHERE execution_id = ? GROUP BY status',
            [$id]
        ) as $row) {
            $counts[$row['status']] = (int) $row['n'];
        }

        $decided  = $counts['pass'] + $counts['fail'];
        $passRate = $decided > 0 ? round(($counts['pass'] / $decided) * 100, 2) : 0.00;
        $total    = array_sum($counts);

        $db->run(
            'UPDATE test_executions
             SET total_items = ?, pass_count = ?, fail_count = ?, na_count = ?, untested_count = ?, pass_rate = ?
             WHERE id = ?',
            [$total, $counts['pass'], $counts['fail'], $counts['na'], $counts['untested'], $passRate, $id]
        );

        return [
            'total'     => $total,
            'pass'      => $counts['pass'],
            'fail'      => $counts['fail'],
            'na'        => $counts['na'],
            'untested'  => $counts['untested'],
            'pass_rate' => $passRate,
        ];
    }

    /**
     * Paginated, filterable listing.
     *
     * @param array{search?:string,status?:string,environment?:string,client?:string,analyst?:int,from?:string,to?:string} $filters
     * @return array{rows:array<int,array<string,mixed>>,total:int,page:int,per_page:int,pages:int}
     */
    public static function paginate(array $filters, int $page = 1, int $perPage = 15, ?int $restrictToUserId = null): array
    {
        $where  = ['1 = 1'];
        $params = [];

        if (!empty($filters['search'])) {
            $where[]  = '(e.client_name LIKE ? OR e.campaign_name LIKE ? OR e.form_name LIKE ? OR e.form_url LIKE ?)';
            $like     = '%' . $filters['search'] . '%';
            $params   = array_merge($params, [$like, $like, $like, $like]);
        }

        if (!empty($filters['status']) && isset(self::STATUSES[$filters['status']])) {
            $where[]  = 'e.status = ?';
            $params[] = $filters['status'];
        }

        if (!empty($filters['environment']) && isset(self::ENVIRONMENTS[$filters['environment']])) {
            $where[]  = 'e.environment = ?';
            $params[] = $filters['environment'];
        }

        if (!empty($filters['client'])) {
            $where[]  = 'e.client_name = ?';
            $params[] = $filters['client'];
        }

        if (!empty($filters['analyst'])) {
            $where[]  = 'e.qa_analyst_id = ?';
            $params[] = (int) $filters['analyst'];
        }

        if (!empty($filters['from'])) {
            $where[]  = 'DATE(e.created_at) >= ?';
            $params[] = $filters['from'];
        }

        if (!empty($filters['to'])) {
            $where[]  = 'DATE(e.created_at) <= ?';
            $params[] = $filters['to'];
        }

        if ($restrictToUserId !== null) {
            $where[]  = '(e.qa_analyst_id = ? OR e.created_by = ?)';
            $params[] = $restrictToUserId;
            $params[] = $restrictToUserId;
        }

        $whereSql = implode(' AND ', $where);
        $db       = Database::instance();

        $total = (int) $db->value("SELECT COUNT(*) FROM test_executions e WHERE $whereSql", $params);
        $pages = $total > 0 ? (int) ceil($total / $perPage) : 1;
        $page  = max(1, min($page, $pages));
        $offset = ($page - 1) * $perPage;

        $rows = $db->fetchAll(
            "SELECT e.*, u.name AS analyst_account
             FROM test_executions e
             LEFT JOIN users u ON u.id = e.qa_analyst_id
             WHERE $whereSql
             ORDER BY e.updated_at DESC, e.id DESC
             LIMIT $perPage OFFSET $offset",
            $params
        );

        return ['rows' => $rows, 'total' => $total, 'page' => $page, 'per_page' => $perPage, 'pages' => $pages];
    }

    /** Distinct client names for filter dropdowns. */
    public static function distinctClients(): array
    {
        return array_column(
            Database::instance()->fetchAll('SELECT DISTINCT client_name FROM test_executions ORDER BY client_name'),
            'client_name'
        );
    }

    public static function delete(int $id): void
    {
        Database::instance()->run('DELETE FROM test_executions WHERE id = ?', [$id]);
    }

    /**
     * Dashboard statistics.
     */
    public static function dashboardStats(): array
    {
        $db = Database::instance();

        $totals = $db->fetch(
            "SELECT
                COUNT(*) AS total,
                SUM(status IN ('approved')) AS approved,
                SUM(status IN ('submitted')) AS submitted,
                SUM(status IN ('in_progress','draft')) AS in_progress,
                SUM(approval_status = 'pending' AND status IN ('submitted','approved')) AS pending_review,
                SUM(fail_count > 0) AS with_failures,
                ROUND(AVG(NULLIF(pass_rate, 0)), 2) AS avg_pass_rate,
                SUM(pass_count) AS total_pass,
                SUM(fail_count) AS total_fail,
                SUM(na_count) AS total_na
             FROM test_executions"
        ) ?? [];

        $totalPass = (int) ($totals['total_pass'] ?? 0);
        $totalFail = (int) ($totals['total_fail'] ?? 0);
        $decided   = $totalPass + $totalFail;

        $passRate = $decided > 0 ? round(($totalPass / $decided) * 100, 1) : 0.0;
        $failRate = $decided > 0 ? round(($totalFail / $decided) * 100, 1) : 0.0;

        // Most common issues: failed checklist items over the last 90 days.
        $commonIssues = $db->fetchAll(
            "SELECT r.item_label, r.section, COUNT(*) AS occurrences
             FROM test_results r
             JOIN test_executions e ON e.id = r.execution_id
             WHERE r.status = 'fail' AND e.created_at >= DATE_SUB(NOW(), INTERVAL 90 DAY)
             GROUP BY r.item_key, r.item_label, r.section
             ORDER BY occurrences DESC, r.item_label ASC
             LIMIT 8"
        );

        $recent = $db->fetchAll(
            "SELECT e.id, e.client_name, e.campaign_name, e.form_name, e.environment, e.status,
                    e.pass_rate, e.fail_count, e.pass_count, e.total_items, e.qa_analyst_name,
                    e.updated_at, e.created_at
             FROM test_executions e
             ORDER BY e.updated_at DESC
             LIMIT 8"
        );

        // 8-week trend of executions and pass rate.
        $trend = $db->fetchAll(
            "SELECT DATE_FORMAT(created_at, '%Y-%u') AS bucket,
                    MIN(DATE(created_at)) AS week_start,
                    COUNT(*) AS executions,
                    ROUND(AVG(pass_rate), 1) AS avg_pass_rate
             FROM test_executions
             WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 8 WEEK)
             GROUP BY bucket
             ORDER BY bucket"
        );

        $byEnvironment = $db->fetchAll(
            "SELECT environment, COUNT(*) AS n,
                    ROUND(AVG(pass_rate), 1) AS avg_pass_rate
             FROM test_executions GROUP BY environment"
        );

        return [
            'totalTests'     => (int) ($totals['total'] ?? 0),
            'passRate'       => $passRate,
            'failRate'       => $failRate,
            'pendingReviews' => (int) ($totals['pending_review'] ?? 0),
            'approved'       => (int) ($totals['approved'] ?? 0),
            'submitted'      => (int) ($totals['submitted'] ?? 0),
            'inProgress'     => (int) ($totals['in_progress'] ?? 0),
            'withFailures'   => (int) ($totals['with_failures'] ?? 0),
            'avgPassRate'    => (float) ($totals['avg_pass_rate'] ?? 0),
            'itemsPassed'    => $totalPass,
            'itemsFailed'    => $totalFail,
            'itemsNa'        => (int) ($totals['total_na'] ?? 0),
            'commonIssues'   => $commonIssues,
            'recent'         => $recent,
            'trend'          => $trend,
            'byEnvironment'  => $byEnvironment,
            'statusBreakdown'=> [
                'draft'       => (int) $db->value("SELECT COUNT(*) FROM test_executions WHERE status = 'draft'"),
                'in_progress' => (int) $db->value("SELECT COUNT(*) FROM test_executions WHERE status = 'in_progress'"),
                'submitted'   => (int) $db->value("SELECT COUNT(*) FROM test_executions WHERE status = 'submitted'"),
                'approved'    => (int) $db->value("SELECT COUNT(*) FROM test_executions WHERE status = 'approved'"),
                'rejected'    => (int) $db->value("SELECT COUNT(*) FROM test_executions WHERE status = 'rejected'"),
            ],
        ];
    }
}
