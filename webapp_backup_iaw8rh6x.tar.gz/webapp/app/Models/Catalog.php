<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Database;

/**
 * Clients, campaigns and donation forms form the catalogue that executions
 * attach to. Keeping them normalised lets the dashboard group history by
 * client/campaign instead of relying on free-text.
 */
final class Catalog
{
    /** @return array<int,array<string,mixed>> */
    public static function clients(): array
    {
        return Database::instance()->fetchAll(
            'SELECT c.*, COUNT(cp.id) AS campaign_count
             FROM clients c
             LEFT JOIN campaigns cp ON cp.client_id = c.id
             GROUP BY c.id
             ORDER BY c.name'
        );
    }

    public static function client(int $id): ?array
    {
        return Database::instance()->fetch('SELECT * FROM clients WHERE id = ?', [$id]);
    }

    public static function createClient(string $name, ?string $code, ?string $amName): int
    {
        return Database::instance()->insert(
            'INSERT INTO clients (name, code, am_name) VALUES (?, ?, ?)',
            [$name, $code ?: null, $amName ?: null]
        );
    }

    public static function updateClient(int $id, string $name, ?string $code, ?string $amName, bool $active): void
    {
        Database::instance()->run(
            'UPDATE clients SET name = ?, code = ?, am_name = ?, is_active = ? WHERE id = ?',
            [$name, $code ?: null, $amName ?: null, $active ? 1 : 0, $id]
        );
    }

    /** @return array<int,array<string,mixed>> */
    public static function campaigns(?int $clientId = null): array
    {
        $sql = 'SELECT cp.*, c.name AS client_name,
                       (SELECT COUNT(*) FROM donation_forms f WHERE f.campaign_id = cp.id) AS form_count
                FROM campaigns cp
                JOIN clients c ON c.id = cp.client_id';
        $params = [];

        if ($clientId !== null) {
            $sql .= ' WHERE cp.client_id = ?';
            $params[] = $clientId;
        }

        $sql .= ' ORDER BY c.name, cp.name';

        return Database::instance()->fetchAll($sql, $params);
    }

    public static function createCampaign(int $clientId, string $name, ?string $code): int
    {
        return Database::instance()->insert(
            'INSERT INTO campaigns (client_id, name, code) VALUES (?, ?, ?)',
            [$clientId, $name, $code ?: null]
        );
    }

    public static function updateCampaign(int $id, int $clientId, string $name, ?string $code, bool $active): void
    {
        Database::instance()->run(
            'UPDATE campaigns SET client_id = ?, name = ?, code = ?, is_active = ? WHERE id = ?',
            [$clientId, $name, $code ?: null, $active ? 1 : 0, $id]
        );
    }

    /** @return array<int,array<string,mixed>> */
    public static function forms(?int $campaignId = null): array
    {
        $sql = 'SELECT f.*, cp.name AS campaign_name, cp.code AS campaign_code, c.name AS client_name, c.id AS client_id
                FROM donation_forms f
                JOIN campaigns cp ON cp.id = f.campaign_id
                JOIN clients c ON c.id = cp.client_id';
        $params = [];

        if ($campaignId !== null) {
            $sql .= ' WHERE f.campaign_id = ?';
            $params[] = $campaignId;
        }

        $sql .= ' ORDER BY c.name, cp.name, f.name';

        return Database::instance()->fetchAll($sql, $params);
    }

    public static function form(int $id): ?array
    {
        return Database::instance()->fetch(
            'SELECT f.*, cp.name AS campaign_name, cp.id AS campaign_id, c.name AS client_name, c.id AS client_id
             FROM donation_forms f
             JOIN campaigns cp ON cp.id = f.campaign_id
             JOIN clients c ON c.id = cp.client_id
             WHERE f.id = ?',
            [$id]
        );
    }

    public static function createForm(
        int $campaignId,
        string $name,
        string $environment,
        ?string $url,
        ?string $templateUrl,
        ?string $appealCode,
        ?int $userId
    ): int {
        return Database::instance()->insert(
            'INSERT INTO donation_forms (campaign_id, name, environment, url, template_url, appeal_code, created_by)
             VALUES (?, ?, ?, ?, ?, ?, ?)',
            [$campaignId, $name, $environment, $url ?: null, $templateUrl ?: null, $appealCode ?: null, $userId]
        );
    }

    public static function updateForm(
        int $id,
        int $campaignId,
        string $name,
        string $environment,
        ?string $url,
        ?string $templateUrl,
        ?string $appealCode,
        bool $active
    ): void {
        Database::instance()->run(
            'UPDATE donation_forms
             SET campaign_id = ?, name = ?, environment = ?, url = ?, template_url = ?, appeal_code = ?, is_active = ?
             WHERE id = ?',
            [$campaignId, $name, $environment, $url ?: null, $templateUrl ?: null, $appealCode ?: null, $active ? 1 : 0, $id]
        );
    }
}
