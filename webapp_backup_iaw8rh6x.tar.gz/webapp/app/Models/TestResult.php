<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Database;
use App\Services\ChecklistCatalog;

final class TestResult
{
    public const STATUSES = ['pass', 'fail', 'na', 'untested'];

    /** @return array<int,array<string,mixed>> */
    public static function forExecution(int $executionId): array
    {
        return Database::instance()->fetchAll(
            'SELECT r.*,
                    (SELECT COUNT(*) FROM evidence_files ev WHERE ev.result_id = r.id) AS evidence_count
             FROM test_results r
             WHERE r.execution_id = ?
             ORDER BY r.sort_order',
            [$executionId]
        );
    }

    public static function find(int $id): ?array
    {
        return Database::instance()->fetch('SELECT * FROM test_results WHERE id = ?', [$id]);
    }

    /**
     * Merge the stored rows with the catalogue so the UI always shows the
     * complete current checklist (and picks up newly added items).
     */
    public static function checklist(int $executionId): array
    {
        $stored = [];

        foreach (self::forExecution($executionId) as $row) {
            $stored[$row['item_key']] = $row;
        }

        $groups = [];

        foreach (ChecklistCatalog::all() as $index => $item) {
            $row = $stored[$item['key']] ?? null;

            $groups[$item['section']][] = [
                'id'             => $row ? (int) $row['id'] : null,
                'key'            => $item['key'],
                'label'          => $item['label'],
                'hint'           => $item['hint'],
                'status'         => $row['status'] ?? 'untested',
                'comment'        => $row['comment'] ?? '',
                'evidence_count' => (int) ($row['evidence_count'] ?? 0),
                'index'          => $index,
            ];
        }

        return [
            'sections' => array_map(
                static fn (string $key, array $items): array => ['key' => $key, 'label' => ChecklistCatalog::sectionLabel($key), 'items' => $items],
                array_keys($groups),
                array_values($groups)
            ),
        ];
    }

    /**
     * Upsert a single result. Returns [resultRow, changeFlags].
     */
    public static function save(int $executionId, string $itemKey, string $status, string $comment): array
    {
        if (!in_array($status, self::STATUSES, true)) {
            throw new \InvalidArgumentException('Invalid checklist status: ' . $status);
        }

        $db   = Database::instance();
        $item = null;

        foreach (ChecklistCatalog::all() as $candidate) {
            if ($candidate['key'] === $itemKey) {
                $item = $candidate;
                break;
            }
        }

        if ($item === null) {
            throw new \InvalidArgumentException('Unknown checklist item: ' . $itemKey);
        }

        if ($status === 'fail' && trim($comment) === '') {
            throw new \InvalidArgumentException('A comment is required when an item is marked as failed.');
        }

        $existing = $db->fetch(
            'SELECT * FROM test_results WHERE execution_id = ? AND item_key = ?',
            [$executionId, $itemKey]
        );

        if ($existing === null) {
            $db->run(
                'INSERT INTO test_results (execution_id, section, item_key, item_label, status, comment, sort_order)
                 VALUES (?, ?, ?, ?, ?, ?, ?)',
                [$executionId, $item['section'], $itemKey, $item['label'], $status, $comment !== '' ? $comment : null, 0]
            );
        } else {
            $db->run(
                'UPDATE test_results SET status = ?, comment = ? WHERE id = ?',
                [$status, $comment !== '' ? $comment : null, (int) $existing['id']]
            );
        }

        $row = $db->fetch('SELECT * FROM test_results WHERE execution_id = ? AND item_key = ?', [$executionId, $itemKey]);

        return [$row, ['status_changed' => ($existing['status'] ?? null) !== $status]];
    }

    /** Bulk-save a map of itemKey => [status, comment]. */
    public static function bulkSave(int $executionId, array $items): int
    {
        $saved = 0;

        $db = Database::instance();

        $db->transaction(function (Database $db) use ($executionId, $items, &$saved): void {
            foreach ($items as $itemKey => $payload) {
                if (!is_string($itemKey) || !is_array($payload)) {
                    continue;
                }

                self::save(
                    $executionId,
                    $itemKey,
                    (string) ($payload['status'] ?? 'untested'),
                    (string) ($payload['comment'] ?? '')
                );
                $saved++;
            }
        });

        return $saved;
    }

    /** @return array<int,array<string,mixed>> Failed items with evidence counts. */
    public static function failedFor(int $executionId): array
    {
        return Database::instance()->fetchAll(
            "SELECT r.*,
                    (SELECT COUNT(*) FROM evidence_files ev WHERE ev.result_id = r.id) AS evidence_count
             FROM test_results r
             WHERE r.execution_id = ? AND r.status = 'fail'
             ORDER BY r.sort_order",
            [$executionId]
        );
    }
}
