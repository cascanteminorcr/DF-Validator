<?php

declare(strict_types=1);

/**
 * PSR-4 style autoloader for the App\ namespace.
 *
 * App\Core\Foo  ->  <project>/app/Core/Foo.php
 */
spl_autoload_register(static function (string $class): void {
    $prefix = 'App\\';

    if (!str_starts_with($class, $prefix)) {
        return;
    }

    // This file lives in app/Core/, so the namespace root is one level up.
    $baseDir  = dirname(__DIR__) . '/';
    $relative = substr($class, strlen($prefix));
    $file     = $baseDir . str_replace('\\', '/', $relative) . '.php';

    if (is_file($file)) {
        require $file;
    }
});
