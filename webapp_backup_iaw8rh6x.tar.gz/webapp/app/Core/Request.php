<?php

declare(strict_types=1);

namespace App\Core;

/**
 * Request abstraction.
 */
final class Request
{
    public static function method(): string
    {
        return strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
    }

    public static function path(): string
    {
        $uri  = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
        $base = rtrim((string) Config::get('app.base_path', ''), '/');

        if ($base !== '' && str_starts_with($uri, $base)) {
            $uri = substr($uri, strlen($base));
        }

        // When the app is served by the PHP built-in server under /public.
        if (str_starts_with($uri, '/index.php')) {
            $uri = substr($uri, strlen('/index.php')) ?: '/';
        }
        if (str_starts_with($uri, '/api/index.php')) {
            $uri = '/api' . substr($uri, strlen('/api/index.php'));
        }

        return '/' . trim($uri, '/');
    }

    /** @return array<string,mixed> */
    public static function query(): array
    {
        return $_GET ?? [];
    }

    public static function queryParam(string $key, mixed $default = null): mixed
    {
        return $_GET[$key] ?? $default;
    }

    /** @return array<string,mixed> */
    public static function json(): array
    {
        static $cache = null;

        if ($cache !== null) {
            return $cache;
        }

        $raw = file_get_contents('php://input') ?: '';

        if ($raw === '') {
            $cache = $_POST ?: [];

            return $cache;
        }

        $decoded = json_decode($raw, true);

        if (is_array($decoded)) {
            $cache = $decoded;

            return $cache;
        }

        // Fallback for urlencoded form submissions.
        parse_str($raw, $parsed);
        $cache = is_array($parsed) ? $parsed : [];

        return $cache;
    }

    /** @return array<string,mixed> */
    public static function files(): array
    {
        return $_FILES ?? [];
    }

    public static function header(string $key): ?string
    {
        $normalised = 'HTTP_' . strtoupper(str_replace('-', '_', $key));

        return $_SERVER[$normalised] ?? null;
    }

    public static function isAjax(): bool
    {
        return strtolower((string) self::header('X-Requested-With')) === 'xmlhttprequest';
    }
}
