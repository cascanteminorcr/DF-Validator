<?php

declare(strict_types=1);

namespace App\Core;

use App\Models\User;

/**
 * Session-backed authentication with role-based access control.
 *
 * Roles:
 *   admin      – everything, including user management and forced approvals
 *   qa_lead    – approve/reject executions, view all executions, reports
 *   qa_analyst – create and edit their own executions
 */
final class Auth
{
    public const ROLE_ADMIN   = 'admin';
    public const ROLE_LEAD    = 'qa_lead';
    public const ROLE_ANALYST = 'qa_analyst';

    private static ?array $cachedUser = null;

    public static function attempt(string $email, string $password): bool
    {
        $user = User::findByEmail($email);

        if ($user === null || !(int) $user['is_active']) {
            return false;
        }

        if (!password_verify($password, $user['password_hash'])) {
            return false;
        }

        if (password_needs_rehash($user['password_hash'], PASSWORD_DEFAULT)) {
            User::updatePassword((int) $user['id'], $password);
        }

        Session::regenerate();
        Session::set('user_id', (int) $user['id']);
        Session::set('user_role', $user['role']);
        User::touchLogin((int) $user['id']);
        self::$cachedUser = null;

        return true;
    }

    public static function check(): bool
    {
        return Session::get('user_id') !== null;
    }

    public static function user(): ?array
    {
        if (self::$cachedUser !== null) {
            return self::$cachedUser;
        }

        $id = Session::get('user_id');

        if ($id === null) {
            return null;
        }

        $user = User::find((int) $id);

        if ($user === null || !(int) $user['is_active']) {
            self::logout();

            return null;
        }

        self::$cachedUser = $user;

        return $user;
    }

    public static function id(): ?int
    {
        $user = self::user();

        return $user === null ? null : (int) $user['id'];
    }

    public static function role(): ?string
    {
        return self::user()['role'] ?? null;
    }

    public static function hasRole(string ...$roles): bool
    {
        $role = self::role();

        return $role !== null && in_array($role, $roles, true);
    }

    public static function isAdmin(): bool
    {
        return self::hasRole(self::ROLE_ADMIN);
    }

    /** Admin and QA Lead may approve executions. */
    public static function canApprove(): bool
    {
        return self::hasRole(self::ROLE_ADMIN, self::ROLE_LEAD);
    }

    public static function logout(): void
    {
        Session::destroy();
        self::$cachedUser = null;
    }

    /** Middleware: reject unauthenticated API calls with 401. */
    public static function requireAuth(): void
    {
        if (!self::check()) {
            Response::json(['success' => false, 'error' => 'Authentication required.', 'code' => 'unauthenticated'], 401);
        }
    }

    /** Middleware: require one of the given roles. */
    public static function requireRole(string ...$roles): void
    {
        self::requireAuth();

        if (!self::hasRole(...$roles)) {
            Response::json(['success' => false, 'error' => 'You do not have permission to perform this action.', 'code' => 'forbidden'], 403);
        }
    }

    /**
     * Ownership check for executions: analysts may only touch their own work;
     * leads and admins may touch anything.
     */
    public static function canEditExecution(array $execution): bool
    {
        if (self::hasRole(self::ROLE_ADMIN, self::ROLE_LEAD)) {
            return true;
        }

        return (int) ($execution['qa_analyst_id'] ?? 0) === self::id()
            || (int) ($execution['created_by'] ?? 0) === self::id();
    }

    public static function publicUser(): ?array
    {
        $user = self::user();

        if ($user === null) {
            return null;
        }

        return [
            'id'    => (int) $user['id'],
            'name'  => $user['name'],
            'email' => $user['email'],
            'role'  => $user['role'],
        ];
    }
}
