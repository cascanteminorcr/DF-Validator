<?php

declare(strict_types=1);

namespace App\Core;

/**
 * Simple fluent validator producing field-level error messages.
 */
final class Validator
{
    /** @var array<string,string> */
    private array $errors = [];

    private function __construct(private array $data)
    {
    }

    public static function make(array $data): self
    {
        return new self($data);
    }

    public function required(string $field, string $label): self
    {
        $value = $this->data[$field] ?? null;

        if (is_array($value) ? count($value) === 0 : trim((string) ($value ?? '')) === '') {
            $this->errors[$field] = $label . ' is required.';
        }

        return $this;
    }

    public function email(string $field, string $label): self
    {
        $value = trim((string) ($this->data[$field] ?? ''));

        if ($value !== '' && !filter_var($value, FILTER_VALIDATE_EMAIL)) {
            $this->errors[$field] = $label . ' must be a valid e-mail address.';
        }

        return $this;
    }

    public function url(string $field, string $label, bool $required = false): self
    {
        $value = trim((string) ($this->data[$field] ?? ''));

        if ($value === '') {
            if ($required) {
                $this->errors[$field] = $label . ' is required.';
            }

            return $this;
        }

        if (!filter_var($value, FILTER_VALIDATE_URL)) {
            $this->errors[$field] = $label . ' must be a valid URL.';

            return $this;
        }

        $scheme = strtolower((string) parse_url($value, PHP_URL_SCHEME));

        if (!in_array($scheme, ['http', 'https'], true)) {
            $this->errors[$field] = $label . ' must use http:// or https://.';
        }

        return $this;
    }

    public function minLength(string $field, string $label, int $min): self
    {
        $value = (string) ($this->data[$field] ?? '');

        if ($value !== '' && mb_strlen($value) < $min) {
            $this->errors[$field] = sprintf('%s must be at least %d characters.', $label, $min);
        }

        return $this;
    }

    public function maxLength(string $field, string $label, int $max): self
    {
        $value = (string) ($this->data[$field] ?? '');

        if (mb_strlen($value) > $max) {
            $this->errors[$field] = sprintf('%s may not exceed %d characters.', $label, $max);
        }

        return $this;
    }

    public function in(string $field, string $label, array $allowed): self
    {
        $value = $this->data[$field] ?? null;

        if ($value !== null && $value !== '' && !in_array($value, $allowed, true)) {
            $this->errors[$field] = $label . ' has an invalid value.';
        }

        return $this;
    }

    public function date(string $field, string $label): self
    {
        $value = trim((string) ($this->data[$field] ?? ''));

        if ($value === '') {
            return $this;
        }

        $dt = \DateTime::createFromFormat('Y-m-d', $value);

        if (!$dt || $dt->format('Y-m-d') !== $value) {
            $this->errors[$field] = $label . ' must use the YYYY-MM-DD format.';
        }

        return $this;
    }

    public function datetime(string $field, string $label): self
    {
        $value = trim((string) ($this->data[$field] ?? ''));

        if ($value === '') {
            return $this;
        }

        $normalised = str_replace('T', ' ', $value);
        $value      = strlen($normalised) === 16 ? $normalised . ':00' : $normalised;
        $dt         = \DateTime::createFromFormat('Y-m-d H:i:s', $value);

        if (!$dt) {
            $this->errors[$field] = $label . ' must be a valid date and time.';
        }

        return $this;
    }

    public function fails(): bool
    {
        return $this->errors !== [];
    }

    /** @return array<string,string> */
    public function errors(): array
    {
        return $this->errors;
    }

    public function firstError(): ?string
    {
        return $this->errors === [] ? null : reset($this->errors);
    }

    public function requireValid(): void
    {
        if ($this->fails()) {
            Response::error((string) $this->firstError(), 422, ['fields' => $this->errors]);
        }
    }
}
