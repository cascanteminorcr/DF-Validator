<?php

declare(strict_types=1);

namespace App\Core;

/**
 * Immutable configuration repository (dot-notation access).
 */
final class Config
{
    private static array $data = [];

    public static function load(array $data): void
    {
        self::$data = $data;
    }

    public static function get(string $key, mixed $default = null): mixed
    {
        $segments = explode('.', $key);
        $value    = self::$data;

        foreach ($segments as $segment) {
            if (!is_array($value) || !array_key_exists($segment, $value)) {
                return $default;
            }
            $value = $value[$segment];
        }

        return $value;
    }

    public static function merge(array $override, array $base = null): array
    {
        $base ??= self::$data;

        foreach ($override as $key => $value) {
            if (is_array($value) && isset($base[$key]) && is_array($base[$key])) {
                $base[$key] = self::merge($value, $base[$key]);
            } else {
                $base[$key] = $value;
            }
        }

        return $base;
    }
}
