<?php

declare(strict_types=1);

namespace App\Core;

/**
 * Synchroniser-token CSRF protection. The token is issued per session and
 * required (header X-CSRF-Token or body field _csrf) on every state change.
 */
final class Csrf
{
    public const SESSION_KEY = '_csrf_token';

    public static function token(): string
    {
        if (empty($_SESSION[self::SESSION_KEY])) {
            $_SESSION[self::SESSION_KEY] = bin2hex(random_bytes(32));
        }

        return $_SESSION[self::SESSION_KEY];
    }

    public static function validate(?string $token): bool
    {
        $expected = $_SESSION[self::SESSION_KEY] ?? null;

        return is_string($expected) && is_string($token) && $token !== ''
            && hash_equals($expected, $token);
    }

    public static function requireValid(): void
    {
        $method = Request::method();

        if (in_array($method, ['GET', 'HEAD', 'OPTIONS'], true)) {
            return;
        }

        $token = Request::header('X-CSRF-Token');

        if ($token === null) {
            $body = Request::json();
            $token = $body['_csrf'] ?? null;
        }

        if (!self::validate(is_string($token) ? $token : null)) {
            Response::error('Invalid or expired CSRF token. Please refresh the page and try again.', 419);
        }
    }
}
