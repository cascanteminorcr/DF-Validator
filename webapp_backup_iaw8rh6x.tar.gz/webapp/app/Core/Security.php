<?php

declare(strict_types=1);

namespace App\Core;

/**
 * XSS-safe output helpers.
 */
final class Security
{
    /** Escape for HTML text/attribute context. */
    public static function e(mixed $value): string
    {
        return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }

    /** Escape for inclusion inside a <script> JSON blob. */
    public static function json(mixed $value): string
    {
        return (string) json_encode(
            $value,
            JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_SLASHES
        );
    }

    /** Strip control characters and trim. */
    public static function clean(?string $value): string
    {
        return trim((string) preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', (string) $value));
    }
}
