<?php

declare(strict_types=1);

use App\Core\Config;
use App\Core\Database;
use App\Core\Session;

require_once __DIR__ . '/Core/autoload.php';

/*
|--------------------------------------------------------------------------
| Bootstrap
|--------------------------------------------------------------------------
| Loads configuration (base + optional local override), starts the secure
| session and connects to MySQL. Both public/index.php and public/api/index.php
| include this file.
*/

$base = require __DIR__ . '/../config/config.php';

$localFile = __DIR__ . '/../config/config.local.php';
if (is_file($localFile)) {
    $base = Config::merge(require $localFile, $base);
}

Config::load($base);

date_default_timezone_set((string) Config::get('app.timezone', 'UTC'));

if ((bool) Config::get('app.debug', false)) {
    error_reporting(E_ALL);
    ini_set('display_errors', '0');   // never leak errors into JSON/HTML responses
} else {
    error_reporting(E_ALL & ~E_DEPRECATED);
    ini_set('display_errors', '0');
}

// Consistent JSON/HTML error handling instead of PHP notices in output.
set_exception_handler(static function (Throwable $e): void {
    error_log('[DFQA] ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());

    if (!headers_sent()) {
        http_response_code(500);
        header('Content-Type: application/json; charset=utf-8');
    }

    $payload = ['success' => false, 'error' => 'Server error'];

    if ((bool) Config::get('app.debug', false)) {
        $payload['debug'] = [
            'message' => $e->getMessage(),
            'file'    => $e->getFile(),
            'line'    => $e->getLine(),
        ];
    }

    echo json_encode($payload);
});

Database::init((array) Config::get('db'));

Session::start();
